package com.injective_explorer_rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * ExplorerAPI implements explorer data API for e.g. Blockchain Explorer
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.61.0)",
    comments = "Source: exchange/injective_explorer_rpc.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class InjectiveExplorerRPCGrpc {

  private InjectiveExplorerRPCGrpc() {}

  public static final java.lang.String SERVICE_NAME = "injective_explorer_rpc.InjectiveExplorerRPC";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetAccountTxsRequest,
      com.injective_explorer_rpc.GetAccountTxsResponse> getGetAccountTxsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetAccountTxs",
      requestType = com.injective_explorer_rpc.GetAccountTxsRequest.class,
      responseType = com.injective_explorer_rpc.GetAccountTxsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetAccountTxsRequest,
      com.injective_explorer_rpc.GetAccountTxsResponse> getGetAccountTxsMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetAccountTxsRequest, com.injective_explorer_rpc.GetAccountTxsResponse> getGetAccountTxsMethod;
    if ((getGetAccountTxsMethod = InjectiveExplorerRPCGrpc.getGetAccountTxsMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetAccountTxsMethod = InjectiveExplorerRPCGrpc.getGetAccountTxsMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetAccountTxsMethod = getGetAccountTxsMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetAccountTxsRequest, com.injective_explorer_rpc.GetAccountTxsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetAccountTxs"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetAccountTxsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetAccountTxsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetAccountTxs"))
              .build();
        }
      }
    }
    return getGetAccountTxsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetContractTxsRequest,
      com.injective_explorer_rpc.GetContractTxsResponse> getGetContractTxsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetContractTxs",
      requestType = com.injective_explorer_rpc.GetContractTxsRequest.class,
      responseType = com.injective_explorer_rpc.GetContractTxsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetContractTxsRequest,
      com.injective_explorer_rpc.GetContractTxsResponse> getGetContractTxsMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetContractTxsRequest, com.injective_explorer_rpc.GetContractTxsResponse> getGetContractTxsMethod;
    if ((getGetContractTxsMethod = InjectiveExplorerRPCGrpc.getGetContractTxsMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetContractTxsMethod = InjectiveExplorerRPCGrpc.getGetContractTxsMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetContractTxsMethod = getGetContractTxsMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetContractTxsRequest, com.injective_explorer_rpc.GetContractTxsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetContractTxs"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetContractTxsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetContractTxsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetContractTxs"))
              .build();
        }
      }
    }
    return getGetContractTxsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetBlocksRequest,
      com.injective_explorer_rpc.GetBlocksResponse> getGetBlocksMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetBlocks",
      requestType = com.injective_explorer_rpc.GetBlocksRequest.class,
      responseType = com.injective_explorer_rpc.GetBlocksResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetBlocksRequest,
      com.injective_explorer_rpc.GetBlocksResponse> getGetBlocksMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetBlocksRequest, com.injective_explorer_rpc.GetBlocksResponse> getGetBlocksMethod;
    if ((getGetBlocksMethod = InjectiveExplorerRPCGrpc.getGetBlocksMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetBlocksMethod = InjectiveExplorerRPCGrpc.getGetBlocksMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetBlocksMethod = getGetBlocksMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetBlocksRequest, com.injective_explorer_rpc.GetBlocksResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetBlocks"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetBlocksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetBlocksResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetBlocks"))
              .build();
        }
      }
    }
    return getGetBlocksMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetBlockRequest,
      com.injective_explorer_rpc.GetBlockResponse> getGetBlockMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetBlock",
      requestType = com.injective_explorer_rpc.GetBlockRequest.class,
      responseType = com.injective_explorer_rpc.GetBlockResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetBlockRequest,
      com.injective_explorer_rpc.GetBlockResponse> getGetBlockMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetBlockRequest, com.injective_explorer_rpc.GetBlockResponse> getGetBlockMethod;
    if ((getGetBlockMethod = InjectiveExplorerRPCGrpc.getGetBlockMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetBlockMethod = InjectiveExplorerRPCGrpc.getGetBlockMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetBlockMethod = getGetBlockMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetBlockRequest, com.injective_explorer_rpc.GetBlockResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetBlock"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetBlockRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetBlockResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetBlock"))
              .build();
        }
      }
    }
    return getGetBlockMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetValidatorsRequest,
      com.injective_explorer_rpc.GetValidatorsResponse> getGetValidatorsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetValidators",
      requestType = com.injective_explorer_rpc.GetValidatorsRequest.class,
      responseType = com.injective_explorer_rpc.GetValidatorsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetValidatorsRequest,
      com.injective_explorer_rpc.GetValidatorsResponse> getGetValidatorsMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetValidatorsRequest, com.injective_explorer_rpc.GetValidatorsResponse> getGetValidatorsMethod;
    if ((getGetValidatorsMethod = InjectiveExplorerRPCGrpc.getGetValidatorsMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetValidatorsMethod = InjectiveExplorerRPCGrpc.getGetValidatorsMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetValidatorsMethod = getGetValidatorsMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetValidatorsRequest, com.injective_explorer_rpc.GetValidatorsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetValidators"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetValidatorsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetValidatorsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetValidators"))
              .build();
        }
      }
    }
    return getGetValidatorsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetValidatorRequest,
      com.injective_explorer_rpc.GetValidatorResponse> getGetValidatorMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetValidator",
      requestType = com.injective_explorer_rpc.GetValidatorRequest.class,
      responseType = com.injective_explorer_rpc.GetValidatorResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetValidatorRequest,
      com.injective_explorer_rpc.GetValidatorResponse> getGetValidatorMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetValidatorRequest, com.injective_explorer_rpc.GetValidatorResponse> getGetValidatorMethod;
    if ((getGetValidatorMethod = InjectiveExplorerRPCGrpc.getGetValidatorMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetValidatorMethod = InjectiveExplorerRPCGrpc.getGetValidatorMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetValidatorMethod = getGetValidatorMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetValidatorRequest, com.injective_explorer_rpc.GetValidatorResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetValidator"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetValidatorRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetValidatorResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetValidator"))
              .build();
        }
      }
    }
    return getGetValidatorMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetValidatorUptimeRequest,
      com.injective_explorer_rpc.GetValidatorUptimeResponse> getGetValidatorUptimeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetValidatorUptime",
      requestType = com.injective_explorer_rpc.GetValidatorUptimeRequest.class,
      responseType = com.injective_explorer_rpc.GetValidatorUptimeResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetValidatorUptimeRequest,
      com.injective_explorer_rpc.GetValidatorUptimeResponse> getGetValidatorUptimeMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetValidatorUptimeRequest, com.injective_explorer_rpc.GetValidatorUptimeResponse> getGetValidatorUptimeMethod;
    if ((getGetValidatorUptimeMethod = InjectiveExplorerRPCGrpc.getGetValidatorUptimeMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetValidatorUptimeMethod = InjectiveExplorerRPCGrpc.getGetValidatorUptimeMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetValidatorUptimeMethod = getGetValidatorUptimeMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetValidatorUptimeRequest, com.injective_explorer_rpc.GetValidatorUptimeResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetValidatorUptime"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetValidatorUptimeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetValidatorUptimeResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetValidatorUptime"))
              .build();
        }
      }
    }
    return getGetValidatorUptimeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetTxsRequest,
      com.injective_explorer_rpc.GetTxsResponse> getGetTxsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetTxs",
      requestType = com.injective_explorer_rpc.GetTxsRequest.class,
      responseType = com.injective_explorer_rpc.GetTxsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetTxsRequest,
      com.injective_explorer_rpc.GetTxsResponse> getGetTxsMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetTxsRequest, com.injective_explorer_rpc.GetTxsResponse> getGetTxsMethod;
    if ((getGetTxsMethod = InjectiveExplorerRPCGrpc.getGetTxsMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetTxsMethod = InjectiveExplorerRPCGrpc.getGetTxsMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetTxsMethod = getGetTxsMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetTxsRequest, com.injective_explorer_rpc.GetTxsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetTxs"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetTxsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetTxsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetTxs"))
              .build();
        }
      }
    }
    return getGetTxsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetTxByTxHashRequest,
      com.injective_explorer_rpc.GetTxByTxHashResponse> getGetTxByTxHashMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetTxByTxHash",
      requestType = com.injective_explorer_rpc.GetTxByTxHashRequest.class,
      responseType = com.injective_explorer_rpc.GetTxByTxHashResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetTxByTxHashRequest,
      com.injective_explorer_rpc.GetTxByTxHashResponse> getGetTxByTxHashMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetTxByTxHashRequest, com.injective_explorer_rpc.GetTxByTxHashResponse> getGetTxByTxHashMethod;
    if ((getGetTxByTxHashMethod = InjectiveExplorerRPCGrpc.getGetTxByTxHashMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetTxByTxHashMethod = InjectiveExplorerRPCGrpc.getGetTxByTxHashMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetTxByTxHashMethod = getGetTxByTxHashMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetTxByTxHashRequest, com.injective_explorer_rpc.GetTxByTxHashResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetTxByTxHash"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetTxByTxHashRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetTxByTxHashResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetTxByTxHash"))
              .build();
        }
      }
    }
    return getGetTxByTxHashMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetPeggyDepositTxsRequest,
      com.injective_explorer_rpc.GetPeggyDepositTxsResponse> getGetPeggyDepositTxsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetPeggyDepositTxs",
      requestType = com.injective_explorer_rpc.GetPeggyDepositTxsRequest.class,
      responseType = com.injective_explorer_rpc.GetPeggyDepositTxsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetPeggyDepositTxsRequest,
      com.injective_explorer_rpc.GetPeggyDepositTxsResponse> getGetPeggyDepositTxsMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetPeggyDepositTxsRequest, com.injective_explorer_rpc.GetPeggyDepositTxsResponse> getGetPeggyDepositTxsMethod;
    if ((getGetPeggyDepositTxsMethod = InjectiveExplorerRPCGrpc.getGetPeggyDepositTxsMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetPeggyDepositTxsMethod = InjectiveExplorerRPCGrpc.getGetPeggyDepositTxsMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetPeggyDepositTxsMethod = getGetPeggyDepositTxsMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetPeggyDepositTxsRequest, com.injective_explorer_rpc.GetPeggyDepositTxsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetPeggyDepositTxs"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetPeggyDepositTxsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetPeggyDepositTxsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetPeggyDepositTxs"))
              .build();
        }
      }
    }
    return getGetPeggyDepositTxsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest,
      com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse> getGetPeggyWithdrawalTxsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetPeggyWithdrawalTxs",
      requestType = com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest.class,
      responseType = com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest,
      com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse> getGetPeggyWithdrawalTxsMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest, com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse> getGetPeggyWithdrawalTxsMethod;
    if ((getGetPeggyWithdrawalTxsMethod = InjectiveExplorerRPCGrpc.getGetPeggyWithdrawalTxsMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetPeggyWithdrawalTxsMethod = InjectiveExplorerRPCGrpc.getGetPeggyWithdrawalTxsMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetPeggyWithdrawalTxsMethod = getGetPeggyWithdrawalTxsMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest, com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetPeggyWithdrawalTxs"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetPeggyWithdrawalTxs"))
              .build();
        }
      }
    }
    return getGetPeggyWithdrawalTxsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetIBCTransferTxsRequest,
      com.injective_explorer_rpc.GetIBCTransferTxsResponse> getGetIBCTransferTxsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetIBCTransferTxs",
      requestType = com.injective_explorer_rpc.GetIBCTransferTxsRequest.class,
      responseType = com.injective_explorer_rpc.GetIBCTransferTxsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetIBCTransferTxsRequest,
      com.injective_explorer_rpc.GetIBCTransferTxsResponse> getGetIBCTransferTxsMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetIBCTransferTxsRequest, com.injective_explorer_rpc.GetIBCTransferTxsResponse> getGetIBCTransferTxsMethod;
    if ((getGetIBCTransferTxsMethod = InjectiveExplorerRPCGrpc.getGetIBCTransferTxsMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetIBCTransferTxsMethod = InjectiveExplorerRPCGrpc.getGetIBCTransferTxsMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetIBCTransferTxsMethod = getGetIBCTransferTxsMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetIBCTransferTxsRequest, com.injective_explorer_rpc.GetIBCTransferTxsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetIBCTransferTxs"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetIBCTransferTxsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetIBCTransferTxsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetIBCTransferTxs"))
              .build();
        }
      }
    }
    return getGetIBCTransferTxsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmCodesRequest,
      com.injective_explorer_rpc.GetWasmCodesResponse> getGetWasmCodesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetWasmCodes",
      requestType = com.injective_explorer_rpc.GetWasmCodesRequest.class,
      responseType = com.injective_explorer_rpc.GetWasmCodesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmCodesRequest,
      com.injective_explorer_rpc.GetWasmCodesResponse> getGetWasmCodesMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmCodesRequest, com.injective_explorer_rpc.GetWasmCodesResponse> getGetWasmCodesMethod;
    if ((getGetWasmCodesMethod = InjectiveExplorerRPCGrpc.getGetWasmCodesMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetWasmCodesMethod = InjectiveExplorerRPCGrpc.getGetWasmCodesMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetWasmCodesMethod = getGetWasmCodesMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetWasmCodesRequest, com.injective_explorer_rpc.GetWasmCodesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetWasmCodes"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetWasmCodesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetWasmCodesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetWasmCodes"))
              .build();
        }
      }
    }
    return getGetWasmCodesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmCodeByIDRequest,
      com.injective_explorer_rpc.GetWasmCodeByIDResponse> getGetWasmCodeByIDMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetWasmCodeByID",
      requestType = com.injective_explorer_rpc.GetWasmCodeByIDRequest.class,
      responseType = com.injective_explorer_rpc.GetWasmCodeByIDResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmCodeByIDRequest,
      com.injective_explorer_rpc.GetWasmCodeByIDResponse> getGetWasmCodeByIDMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmCodeByIDRequest, com.injective_explorer_rpc.GetWasmCodeByIDResponse> getGetWasmCodeByIDMethod;
    if ((getGetWasmCodeByIDMethod = InjectiveExplorerRPCGrpc.getGetWasmCodeByIDMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetWasmCodeByIDMethod = InjectiveExplorerRPCGrpc.getGetWasmCodeByIDMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetWasmCodeByIDMethod = getGetWasmCodeByIDMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetWasmCodeByIDRequest, com.injective_explorer_rpc.GetWasmCodeByIDResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetWasmCodeByID"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetWasmCodeByIDRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetWasmCodeByIDResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetWasmCodeByID"))
              .build();
        }
      }
    }
    return getGetWasmCodeByIDMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmContractsRequest,
      com.injective_explorer_rpc.GetWasmContractsResponse> getGetWasmContractsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetWasmContracts",
      requestType = com.injective_explorer_rpc.GetWasmContractsRequest.class,
      responseType = com.injective_explorer_rpc.GetWasmContractsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmContractsRequest,
      com.injective_explorer_rpc.GetWasmContractsResponse> getGetWasmContractsMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmContractsRequest, com.injective_explorer_rpc.GetWasmContractsResponse> getGetWasmContractsMethod;
    if ((getGetWasmContractsMethod = InjectiveExplorerRPCGrpc.getGetWasmContractsMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetWasmContractsMethod = InjectiveExplorerRPCGrpc.getGetWasmContractsMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetWasmContractsMethod = getGetWasmContractsMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetWasmContractsRequest, com.injective_explorer_rpc.GetWasmContractsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetWasmContracts"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetWasmContractsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetWasmContractsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetWasmContracts"))
              .build();
        }
      }
    }
    return getGetWasmContractsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmContractByAddressRequest,
      com.injective_explorer_rpc.GetWasmContractByAddressResponse> getGetWasmContractByAddressMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetWasmContractByAddress",
      requestType = com.injective_explorer_rpc.GetWasmContractByAddressRequest.class,
      responseType = com.injective_explorer_rpc.GetWasmContractByAddressResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmContractByAddressRequest,
      com.injective_explorer_rpc.GetWasmContractByAddressResponse> getGetWasmContractByAddressMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetWasmContractByAddressRequest, com.injective_explorer_rpc.GetWasmContractByAddressResponse> getGetWasmContractByAddressMethod;
    if ((getGetWasmContractByAddressMethod = InjectiveExplorerRPCGrpc.getGetWasmContractByAddressMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetWasmContractByAddressMethod = InjectiveExplorerRPCGrpc.getGetWasmContractByAddressMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetWasmContractByAddressMethod = getGetWasmContractByAddressMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetWasmContractByAddressRequest, com.injective_explorer_rpc.GetWasmContractByAddressResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetWasmContractByAddress"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetWasmContractByAddressRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetWasmContractByAddressResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetWasmContractByAddress"))
              .build();
        }
      }
    }
    return getGetWasmContractByAddressMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetCw20BalanceRequest,
      com.injective_explorer_rpc.GetCw20BalanceResponse> getGetCw20BalanceMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCw20Balance",
      requestType = com.injective_explorer_rpc.GetCw20BalanceRequest.class,
      responseType = com.injective_explorer_rpc.GetCw20BalanceResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetCw20BalanceRequest,
      com.injective_explorer_rpc.GetCw20BalanceResponse> getGetCw20BalanceMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetCw20BalanceRequest, com.injective_explorer_rpc.GetCw20BalanceResponse> getGetCw20BalanceMethod;
    if ((getGetCw20BalanceMethod = InjectiveExplorerRPCGrpc.getGetCw20BalanceMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetCw20BalanceMethod = InjectiveExplorerRPCGrpc.getGetCw20BalanceMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetCw20BalanceMethod = getGetCw20BalanceMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetCw20BalanceRequest, com.injective_explorer_rpc.GetCw20BalanceResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetCw20Balance"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetCw20BalanceRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetCw20BalanceResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetCw20Balance"))
              .build();
        }
      }
    }
    return getGetCw20BalanceMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.RelayersRequest,
      com.injective_explorer_rpc.RelayersResponse> getRelayersMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Relayers",
      requestType = com.injective_explorer_rpc.RelayersRequest.class,
      responseType = com.injective_explorer_rpc.RelayersResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.RelayersRequest,
      com.injective_explorer_rpc.RelayersResponse> getRelayersMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.RelayersRequest, com.injective_explorer_rpc.RelayersResponse> getRelayersMethod;
    if ((getRelayersMethod = InjectiveExplorerRPCGrpc.getRelayersMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getRelayersMethod = InjectiveExplorerRPCGrpc.getRelayersMethod) == null) {
          InjectiveExplorerRPCGrpc.getRelayersMethod = getRelayersMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.RelayersRequest, com.injective_explorer_rpc.RelayersResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Relayers"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.RelayersRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.RelayersResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("Relayers"))
              .build();
        }
      }
    }
    return getRelayersMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetBankTransfersRequest,
      com.injective_explorer_rpc.GetBankTransfersResponse> getGetBankTransfersMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetBankTransfers",
      requestType = com.injective_explorer_rpc.GetBankTransfersRequest.class,
      responseType = com.injective_explorer_rpc.GetBankTransfersResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetBankTransfersRequest,
      com.injective_explorer_rpc.GetBankTransfersResponse> getGetBankTransfersMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.GetBankTransfersRequest, com.injective_explorer_rpc.GetBankTransfersResponse> getGetBankTransfersMethod;
    if ((getGetBankTransfersMethod = InjectiveExplorerRPCGrpc.getGetBankTransfersMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getGetBankTransfersMethod = InjectiveExplorerRPCGrpc.getGetBankTransfersMethod) == null) {
          InjectiveExplorerRPCGrpc.getGetBankTransfersMethod = getGetBankTransfersMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.GetBankTransfersRequest, com.injective_explorer_rpc.GetBankTransfersResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetBankTransfers"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetBankTransfersRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.GetBankTransfersResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("GetBankTransfers"))
              .build();
        }
      }
    }
    return getGetBankTransfersMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.StreamTxsRequest,
      com.injective_explorer_rpc.StreamTxsResponse> getStreamTxsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamTxs",
      requestType = com.injective_explorer_rpc.StreamTxsRequest.class,
      responseType = com.injective_explorer_rpc.StreamTxsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.StreamTxsRequest,
      com.injective_explorer_rpc.StreamTxsResponse> getStreamTxsMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.StreamTxsRequest, com.injective_explorer_rpc.StreamTxsResponse> getStreamTxsMethod;
    if ((getStreamTxsMethod = InjectiveExplorerRPCGrpc.getStreamTxsMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getStreamTxsMethod = InjectiveExplorerRPCGrpc.getStreamTxsMethod) == null) {
          InjectiveExplorerRPCGrpc.getStreamTxsMethod = getStreamTxsMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.StreamTxsRequest, com.injective_explorer_rpc.StreamTxsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StreamTxs"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.StreamTxsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.StreamTxsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("StreamTxs"))
              .build();
        }
      }
    }
    return getStreamTxsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_explorer_rpc.StreamBlocksRequest,
      com.injective_explorer_rpc.StreamBlocksResponse> getStreamBlocksMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamBlocks",
      requestType = com.injective_explorer_rpc.StreamBlocksRequest.class,
      responseType = com.injective_explorer_rpc.StreamBlocksResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.injective_explorer_rpc.StreamBlocksRequest,
      com.injective_explorer_rpc.StreamBlocksResponse> getStreamBlocksMethod() {
    io.grpc.MethodDescriptor<com.injective_explorer_rpc.StreamBlocksRequest, com.injective_explorer_rpc.StreamBlocksResponse> getStreamBlocksMethod;
    if ((getStreamBlocksMethod = InjectiveExplorerRPCGrpc.getStreamBlocksMethod) == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        if ((getStreamBlocksMethod = InjectiveExplorerRPCGrpc.getStreamBlocksMethod) == null) {
          InjectiveExplorerRPCGrpc.getStreamBlocksMethod = getStreamBlocksMethod =
              io.grpc.MethodDescriptor.<com.injective_explorer_rpc.StreamBlocksRequest, com.injective_explorer_rpc.StreamBlocksResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StreamBlocks"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.StreamBlocksRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_explorer_rpc.StreamBlocksResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExplorerRPCMethodDescriptorSupplier("StreamBlocks"))
              .build();
        }
      }
    }
    return getStreamBlocksMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static InjectiveExplorerRPCStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveExplorerRPCStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveExplorerRPCStub>() {
        @java.lang.Override
        public InjectiveExplorerRPCStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveExplorerRPCStub(channel, callOptions);
        }
      };
    return InjectiveExplorerRPCStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static InjectiveExplorerRPCBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveExplorerRPCBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveExplorerRPCBlockingStub>() {
        @java.lang.Override
        public InjectiveExplorerRPCBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveExplorerRPCBlockingStub(channel, callOptions);
        }
      };
    return InjectiveExplorerRPCBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static InjectiveExplorerRPCFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveExplorerRPCFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveExplorerRPCFutureStub>() {
        @java.lang.Override
        public InjectiveExplorerRPCFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveExplorerRPCFutureStub(channel, callOptions);
        }
      };
    return InjectiveExplorerRPCFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * ExplorerAPI implements explorer data API for e.g. Blockchain Explorer
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * GetAccountTxs returns tranctions involving in an account based upon params.
     * </pre>
     */
    default void getAccountTxs(com.injective_explorer_rpc.GetAccountTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetAccountTxsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetAccountTxsMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetContractTxs returns contract-related transactions
     * </pre>
     */
    default void getContractTxs(com.injective_explorer_rpc.GetContractTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetContractTxsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetContractTxsMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetBlocks returns blocks based upon the request params
     * </pre>
     */
    default void getBlocks(com.injective_explorer_rpc.GetBlocksRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetBlocksResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetBlocksMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetBlock returns block based upon the height or hash
     * </pre>
     */
    default void getBlock(com.injective_explorer_rpc.GetBlockRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetBlockResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetBlockMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetValidators returns validators on the active chain
     * </pre>
     */
    default void getValidators(com.injective_explorer_rpc.GetValidatorsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetValidatorsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetValidatorsMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetValidator returns validator information on the active chain
     * </pre>
     */
    default void getValidator(com.injective_explorer_rpc.GetValidatorRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetValidatorResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetValidatorMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetValidatorUptime returns validator uptime information on the active chain
     * </pre>
     */
    default void getValidatorUptime(com.injective_explorer_rpc.GetValidatorUptimeRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetValidatorUptimeResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetValidatorUptimeMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetTxs returns transactions based upon the request params
     * </pre>
     */
    default void getTxs(com.injective_explorer_rpc.GetTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetTxsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetTxsMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetTxByTxHash returns certain transaction information by its tx hash.
     * </pre>
     */
    default void getTxByTxHash(com.injective_explorer_rpc.GetTxByTxHashRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetTxByTxHashResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetTxByTxHashMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetPeggyDepositTxs returns the peggy deposit transactions based upon the
     * request params
     * </pre>
     */
    default void getPeggyDepositTxs(com.injective_explorer_rpc.GetPeggyDepositTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetPeggyDepositTxsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetPeggyDepositTxsMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetPeggyWithdrawalTxs returns the peggy withdrawal transactions based upon
     * the request params
     * </pre>
     */
    default void getPeggyWithdrawalTxs(com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetPeggyWithdrawalTxsMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetIBCTransferTxs returns the ibc transfer transactions based upon the
     * request params
     * </pre>
     */
    default void getIBCTransferTxs(com.injective_explorer_rpc.GetIBCTransferTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetIBCTransferTxsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetIBCTransferTxsMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetWasmCodes lists all stored code
     * </pre>
     */
    default void getWasmCodes(com.injective_explorer_rpc.GetWasmCodesRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmCodesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetWasmCodesMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetWasmCodeById list cosmwasm code infor by ID
     * </pre>
     */
    default void getWasmCodeByID(com.injective_explorer_rpc.GetWasmCodeByIDRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmCodeByIDResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetWasmCodeByIDMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetWasmContracts lists all contracts
     * </pre>
     */
    default void getWasmContracts(com.injective_explorer_rpc.GetWasmContractsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmContractsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetWasmContractsMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetWasmContractByAddress list cosmwasm contract info by its address
     * </pre>
     */
    default void getWasmContractByAddress(com.injective_explorer_rpc.GetWasmContractByAddressRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmContractByAddressResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetWasmContractByAddressMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetCw20Balance lists all cw20 balances of an injective account
     * </pre>
     */
    default void getCw20Balance(com.injective_explorer_rpc.GetCw20BalanceRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetCw20BalanceResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetCw20BalanceMethod(), responseObserver);
    }

    /**
     * <pre>
     * Request relayers infos by marketIDs. If no ids are provided, all market with
     * associated relayers are returned
     * </pre>
     */
    default void relayers(com.injective_explorer_rpc.RelayersRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.RelayersResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRelayersMethod(), responseObserver);
    }

    /**
     * <pre>
     * GetBankTransfers returns bank transfers.
     * </pre>
     */
    default void getBankTransfers(com.injective_explorer_rpc.GetBankTransfersRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetBankTransfersResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetBankTransfersMethod(), responseObserver);
    }

    /**
     * <pre>
     * StreamTxs returns transactions based upon the request params
     * </pre>
     */
    default void streamTxs(com.injective_explorer_rpc.StreamTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.StreamTxsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStreamTxsMethod(), responseObserver);
    }

    /**
     * <pre>
     * StreamBlocks returns the latest blocks
     * </pre>
     */
    default void streamBlocks(com.injective_explorer_rpc.StreamBlocksRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.StreamBlocksResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStreamBlocksMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service InjectiveExplorerRPC.
   * <pre>
   * ExplorerAPI implements explorer data API for e.g. Blockchain Explorer
   * </pre>
   */
  public static abstract class InjectiveExplorerRPCImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return InjectiveExplorerRPCGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service InjectiveExplorerRPC.
   * <pre>
   * ExplorerAPI implements explorer data API for e.g. Blockchain Explorer
   * </pre>
   */
  public static final class InjectiveExplorerRPCStub
      extends io.grpc.stub.AbstractAsyncStub<InjectiveExplorerRPCStub> {
    private InjectiveExplorerRPCStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveExplorerRPCStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveExplorerRPCStub(channel, callOptions);
    }

    /**
     * <pre>
     * GetAccountTxs returns tranctions involving in an account based upon params.
     * </pre>
     */
    public void getAccountTxs(com.injective_explorer_rpc.GetAccountTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetAccountTxsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetAccountTxsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetContractTxs returns contract-related transactions
     * </pre>
     */
    public void getContractTxs(com.injective_explorer_rpc.GetContractTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetContractTxsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetContractTxsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetBlocks returns blocks based upon the request params
     * </pre>
     */
    public void getBlocks(com.injective_explorer_rpc.GetBlocksRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetBlocksResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetBlocksMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetBlock returns block based upon the height or hash
     * </pre>
     */
    public void getBlock(com.injective_explorer_rpc.GetBlockRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetBlockResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetBlockMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetValidators returns validators on the active chain
     * </pre>
     */
    public void getValidators(com.injective_explorer_rpc.GetValidatorsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetValidatorsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetValidatorsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetValidator returns validator information on the active chain
     * </pre>
     */
    public void getValidator(com.injective_explorer_rpc.GetValidatorRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetValidatorResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetValidatorMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetValidatorUptime returns validator uptime information on the active chain
     * </pre>
     */
    public void getValidatorUptime(com.injective_explorer_rpc.GetValidatorUptimeRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetValidatorUptimeResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetValidatorUptimeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetTxs returns transactions based upon the request params
     * </pre>
     */
    public void getTxs(com.injective_explorer_rpc.GetTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetTxsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetTxsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetTxByTxHash returns certain transaction information by its tx hash.
     * </pre>
     */
    public void getTxByTxHash(com.injective_explorer_rpc.GetTxByTxHashRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetTxByTxHashResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetTxByTxHashMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetPeggyDepositTxs returns the peggy deposit transactions based upon the
     * request params
     * </pre>
     */
    public void getPeggyDepositTxs(com.injective_explorer_rpc.GetPeggyDepositTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetPeggyDepositTxsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetPeggyDepositTxsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetPeggyWithdrawalTxs returns the peggy withdrawal transactions based upon
     * the request params
     * </pre>
     */
    public void getPeggyWithdrawalTxs(com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetPeggyWithdrawalTxsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetIBCTransferTxs returns the ibc transfer transactions based upon the
     * request params
     * </pre>
     */
    public void getIBCTransferTxs(com.injective_explorer_rpc.GetIBCTransferTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetIBCTransferTxsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetIBCTransferTxsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetWasmCodes lists all stored code
     * </pre>
     */
    public void getWasmCodes(com.injective_explorer_rpc.GetWasmCodesRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmCodesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetWasmCodesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetWasmCodeById list cosmwasm code infor by ID
     * </pre>
     */
    public void getWasmCodeByID(com.injective_explorer_rpc.GetWasmCodeByIDRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmCodeByIDResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetWasmCodeByIDMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetWasmContracts lists all contracts
     * </pre>
     */
    public void getWasmContracts(com.injective_explorer_rpc.GetWasmContractsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmContractsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetWasmContractsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetWasmContractByAddress list cosmwasm contract info by its address
     * </pre>
     */
    public void getWasmContractByAddress(com.injective_explorer_rpc.GetWasmContractByAddressRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmContractByAddressResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetWasmContractByAddressMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetCw20Balance lists all cw20 balances of an injective account
     * </pre>
     */
    public void getCw20Balance(com.injective_explorer_rpc.GetCw20BalanceRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetCw20BalanceResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetCw20BalanceMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Request relayers infos by marketIDs. If no ids are provided, all market with
     * associated relayers are returned
     * </pre>
     */
    public void relayers(com.injective_explorer_rpc.RelayersRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.RelayersResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRelayersMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * GetBankTransfers returns bank transfers.
     * </pre>
     */
    public void getBankTransfers(com.injective_explorer_rpc.GetBankTransfersRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetBankTransfersResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetBankTransfersMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * StreamTxs returns transactions based upon the request params
     * </pre>
     */
    public void streamTxs(com.injective_explorer_rpc.StreamTxsRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.StreamTxsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getStreamTxsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * StreamBlocks returns the latest blocks
     * </pre>
     */
    public void streamBlocks(com.injective_explorer_rpc.StreamBlocksRequest request,
        io.grpc.stub.StreamObserver<com.injective_explorer_rpc.StreamBlocksResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getStreamBlocksMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service InjectiveExplorerRPC.
   * <pre>
   * ExplorerAPI implements explorer data API for e.g. Blockchain Explorer
   * </pre>
   */
  public static final class InjectiveExplorerRPCBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<InjectiveExplorerRPCBlockingStub> {
    private InjectiveExplorerRPCBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveExplorerRPCBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveExplorerRPCBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * GetAccountTxs returns tranctions involving in an account based upon params.
     * </pre>
     */
    public com.injective_explorer_rpc.GetAccountTxsResponse getAccountTxs(com.injective_explorer_rpc.GetAccountTxsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetAccountTxsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetContractTxs returns contract-related transactions
     * </pre>
     */
    public com.injective_explorer_rpc.GetContractTxsResponse getContractTxs(com.injective_explorer_rpc.GetContractTxsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetContractTxsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetBlocks returns blocks based upon the request params
     * </pre>
     */
    public com.injective_explorer_rpc.GetBlocksResponse getBlocks(com.injective_explorer_rpc.GetBlocksRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetBlocksMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetBlock returns block based upon the height or hash
     * </pre>
     */
    public com.injective_explorer_rpc.GetBlockResponse getBlock(com.injective_explorer_rpc.GetBlockRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetBlockMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetValidators returns validators on the active chain
     * </pre>
     */
    public com.injective_explorer_rpc.GetValidatorsResponse getValidators(com.injective_explorer_rpc.GetValidatorsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetValidatorsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetValidator returns validator information on the active chain
     * </pre>
     */
    public com.injective_explorer_rpc.GetValidatorResponse getValidator(com.injective_explorer_rpc.GetValidatorRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetValidatorMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetValidatorUptime returns validator uptime information on the active chain
     * </pre>
     */
    public com.injective_explorer_rpc.GetValidatorUptimeResponse getValidatorUptime(com.injective_explorer_rpc.GetValidatorUptimeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetValidatorUptimeMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetTxs returns transactions based upon the request params
     * </pre>
     */
    public com.injective_explorer_rpc.GetTxsResponse getTxs(com.injective_explorer_rpc.GetTxsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetTxsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetTxByTxHash returns certain transaction information by its tx hash.
     * </pre>
     */
    public com.injective_explorer_rpc.GetTxByTxHashResponse getTxByTxHash(com.injective_explorer_rpc.GetTxByTxHashRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetTxByTxHashMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetPeggyDepositTxs returns the peggy deposit transactions based upon the
     * request params
     * </pre>
     */
    public com.injective_explorer_rpc.GetPeggyDepositTxsResponse getPeggyDepositTxs(com.injective_explorer_rpc.GetPeggyDepositTxsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetPeggyDepositTxsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetPeggyWithdrawalTxs returns the peggy withdrawal transactions based upon
     * the request params
     * </pre>
     */
    public com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse getPeggyWithdrawalTxs(com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetPeggyWithdrawalTxsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetIBCTransferTxs returns the ibc transfer transactions based upon the
     * request params
     * </pre>
     */
    public com.injective_explorer_rpc.GetIBCTransferTxsResponse getIBCTransferTxs(com.injective_explorer_rpc.GetIBCTransferTxsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetIBCTransferTxsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetWasmCodes lists all stored code
     * </pre>
     */
    public com.injective_explorer_rpc.GetWasmCodesResponse getWasmCodes(com.injective_explorer_rpc.GetWasmCodesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetWasmCodesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetWasmCodeById list cosmwasm code infor by ID
     * </pre>
     */
    public com.injective_explorer_rpc.GetWasmCodeByIDResponse getWasmCodeByID(com.injective_explorer_rpc.GetWasmCodeByIDRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetWasmCodeByIDMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetWasmContracts lists all contracts
     * </pre>
     */
    public com.injective_explorer_rpc.GetWasmContractsResponse getWasmContracts(com.injective_explorer_rpc.GetWasmContractsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetWasmContractsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetWasmContractByAddress list cosmwasm contract info by its address
     * </pre>
     */
    public com.injective_explorer_rpc.GetWasmContractByAddressResponse getWasmContractByAddress(com.injective_explorer_rpc.GetWasmContractByAddressRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetWasmContractByAddressMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetCw20Balance lists all cw20 balances of an injective account
     * </pre>
     */
    public com.injective_explorer_rpc.GetCw20BalanceResponse getCw20Balance(com.injective_explorer_rpc.GetCw20BalanceRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCw20BalanceMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Request relayers infos by marketIDs. If no ids are provided, all market with
     * associated relayers are returned
     * </pre>
     */
    public com.injective_explorer_rpc.RelayersResponse relayers(com.injective_explorer_rpc.RelayersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRelayersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * GetBankTransfers returns bank transfers.
     * </pre>
     */
    public com.injective_explorer_rpc.GetBankTransfersResponse getBankTransfers(com.injective_explorer_rpc.GetBankTransfersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetBankTransfersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * StreamTxs returns transactions based upon the request params
     * </pre>
     */
    public java.util.Iterator<com.injective_explorer_rpc.StreamTxsResponse> streamTxs(
        com.injective_explorer_rpc.StreamTxsRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getStreamTxsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * StreamBlocks returns the latest blocks
     * </pre>
     */
    public java.util.Iterator<com.injective_explorer_rpc.StreamBlocksResponse> streamBlocks(
        com.injective_explorer_rpc.StreamBlocksRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getStreamBlocksMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service InjectiveExplorerRPC.
   * <pre>
   * ExplorerAPI implements explorer data API for e.g. Blockchain Explorer
   * </pre>
   */
  public static final class InjectiveExplorerRPCFutureStub
      extends io.grpc.stub.AbstractFutureStub<InjectiveExplorerRPCFutureStub> {
    private InjectiveExplorerRPCFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveExplorerRPCFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveExplorerRPCFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * GetAccountTxs returns tranctions involving in an account based upon params.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetAccountTxsResponse> getAccountTxs(
        com.injective_explorer_rpc.GetAccountTxsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetAccountTxsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetContractTxs returns contract-related transactions
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetContractTxsResponse> getContractTxs(
        com.injective_explorer_rpc.GetContractTxsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetContractTxsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetBlocks returns blocks based upon the request params
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetBlocksResponse> getBlocks(
        com.injective_explorer_rpc.GetBlocksRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetBlocksMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetBlock returns block based upon the height or hash
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetBlockResponse> getBlock(
        com.injective_explorer_rpc.GetBlockRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetBlockMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetValidators returns validators on the active chain
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetValidatorsResponse> getValidators(
        com.injective_explorer_rpc.GetValidatorsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetValidatorsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetValidator returns validator information on the active chain
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetValidatorResponse> getValidator(
        com.injective_explorer_rpc.GetValidatorRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetValidatorMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetValidatorUptime returns validator uptime information on the active chain
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetValidatorUptimeResponse> getValidatorUptime(
        com.injective_explorer_rpc.GetValidatorUptimeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetValidatorUptimeMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetTxs returns transactions based upon the request params
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetTxsResponse> getTxs(
        com.injective_explorer_rpc.GetTxsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetTxsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetTxByTxHash returns certain transaction information by its tx hash.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetTxByTxHashResponse> getTxByTxHash(
        com.injective_explorer_rpc.GetTxByTxHashRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetTxByTxHashMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetPeggyDepositTxs returns the peggy deposit transactions based upon the
     * request params
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetPeggyDepositTxsResponse> getPeggyDepositTxs(
        com.injective_explorer_rpc.GetPeggyDepositTxsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetPeggyDepositTxsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetPeggyWithdrawalTxs returns the peggy withdrawal transactions based upon
     * the request params
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse> getPeggyWithdrawalTxs(
        com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetPeggyWithdrawalTxsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetIBCTransferTxs returns the ibc transfer transactions based upon the
     * request params
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetIBCTransferTxsResponse> getIBCTransferTxs(
        com.injective_explorer_rpc.GetIBCTransferTxsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetIBCTransferTxsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetWasmCodes lists all stored code
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetWasmCodesResponse> getWasmCodes(
        com.injective_explorer_rpc.GetWasmCodesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetWasmCodesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetWasmCodeById list cosmwasm code infor by ID
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetWasmCodeByIDResponse> getWasmCodeByID(
        com.injective_explorer_rpc.GetWasmCodeByIDRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetWasmCodeByIDMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetWasmContracts lists all contracts
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetWasmContractsResponse> getWasmContracts(
        com.injective_explorer_rpc.GetWasmContractsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetWasmContractsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetWasmContractByAddress list cosmwasm contract info by its address
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetWasmContractByAddressResponse> getWasmContractByAddress(
        com.injective_explorer_rpc.GetWasmContractByAddressRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetWasmContractByAddressMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetCw20Balance lists all cw20 balances of an injective account
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetCw20BalanceResponse> getCw20Balance(
        com.injective_explorer_rpc.GetCw20BalanceRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetCw20BalanceMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Request relayers infos by marketIDs. If no ids are provided, all market with
     * associated relayers are returned
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.RelayersResponse> relayers(
        com.injective_explorer_rpc.RelayersRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRelayersMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * GetBankTransfers returns bank transfers.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_explorer_rpc.GetBankTransfersResponse> getBankTransfers(
        com.injective_explorer_rpc.GetBankTransfersRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetBankTransfersMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_ACCOUNT_TXS = 0;
  private static final int METHODID_GET_CONTRACT_TXS = 1;
  private static final int METHODID_GET_BLOCKS = 2;
  private static final int METHODID_GET_BLOCK = 3;
  private static final int METHODID_GET_VALIDATORS = 4;
  private static final int METHODID_GET_VALIDATOR = 5;
  private static final int METHODID_GET_VALIDATOR_UPTIME = 6;
  private static final int METHODID_GET_TXS = 7;
  private static final int METHODID_GET_TX_BY_TX_HASH = 8;
  private static final int METHODID_GET_PEGGY_DEPOSIT_TXS = 9;
  private static final int METHODID_GET_PEGGY_WITHDRAWAL_TXS = 10;
  private static final int METHODID_GET_IBCTRANSFER_TXS = 11;
  private static final int METHODID_GET_WASM_CODES = 12;
  private static final int METHODID_GET_WASM_CODE_BY_ID = 13;
  private static final int METHODID_GET_WASM_CONTRACTS = 14;
  private static final int METHODID_GET_WASM_CONTRACT_BY_ADDRESS = 15;
  private static final int METHODID_GET_CW20BALANCE = 16;
  private static final int METHODID_RELAYERS = 17;
  private static final int METHODID_GET_BANK_TRANSFERS = 18;
  private static final int METHODID_STREAM_TXS = 19;
  private static final int METHODID_STREAM_BLOCKS = 20;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_ACCOUNT_TXS:
          serviceImpl.getAccountTxs((com.injective_explorer_rpc.GetAccountTxsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetAccountTxsResponse>) responseObserver);
          break;
        case METHODID_GET_CONTRACT_TXS:
          serviceImpl.getContractTxs((com.injective_explorer_rpc.GetContractTxsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetContractTxsResponse>) responseObserver);
          break;
        case METHODID_GET_BLOCKS:
          serviceImpl.getBlocks((com.injective_explorer_rpc.GetBlocksRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetBlocksResponse>) responseObserver);
          break;
        case METHODID_GET_BLOCK:
          serviceImpl.getBlock((com.injective_explorer_rpc.GetBlockRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetBlockResponse>) responseObserver);
          break;
        case METHODID_GET_VALIDATORS:
          serviceImpl.getValidators((com.injective_explorer_rpc.GetValidatorsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetValidatorsResponse>) responseObserver);
          break;
        case METHODID_GET_VALIDATOR:
          serviceImpl.getValidator((com.injective_explorer_rpc.GetValidatorRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetValidatorResponse>) responseObserver);
          break;
        case METHODID_GET_VALIDATOR_UPTIME:
          serviceImpl.getValidatorUptime((com.injective_explorer_rpc.GetValidatorUptimeRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetValidatorUptimeResponse>) responseObserver);
          break;
        case METHODID_GET_TXS:
          serviceImpl.getTxs((com.injective_explorer_rpc.GetTxsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetTxsResponse>) responseObserver);
          break;
        case METHODID_GET_TX_BY_TX_HASH:
          serviceImpl.getTxByTxHash((com.injective_explorer_rpc.GetTxByTxHashRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetTxByTxHashResponse>) responseObserver);
          break;
        case METHODID_GET_PEGGY_DEPOSIT_TXS:
          serviceImpl.getPeggyDepositTxs((com.injective_explorer_rpc.GetPeggyDepositTxsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetPeggyDepositTxsResponse>) responseObserver);
          break;
        case METHODID_GET_PEGGY_WITHDRAWAL_TXS:
          serviceImpl.getPeggyWithdrawalTxs((com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse>) responseObserver);
          break;
        case METHODID_GET_IBCTRANSFER_TXS:
          serviceImpl.getIBCTransferTxs((com.injective_explorer_rpc.GetIBCTransferTxsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetIBCTransferTxsResponse>) responseObserver);
          break;
        case METHODID_GET_WASM_CODES:
          serviceImpl.getWasmCodes((com.injective_explorer_rpc.GetWasmCodesRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmCodesResponse>) responseObserver);
          break;
        case METHODID_GET_WASM_CODE_BY_ID:
          serviceImpl.getWasmCodeByID((com.injective_explorer_rpc.GetWasmCodeByIDRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmCodeByIDResponse>) responseObserver);
          break;
        case METHODID_GET_WASM_CONTRACTS:
          serviceImpl.getWasmContracts((com.injective_explorer_rpc.GetWasmContractsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmContractsResponse>) responseObserver);
          break;
        case METHODID_GET_WASM_CONTRACT_BY_ADDRESS:
          serviceImpl.getWasmContractByAddress((com.injective_explorer_rpc.GetWasmContractByAddressRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetWasmContractByAddressResponse>) responseObserver);
          break;
        case METHODID_GET_CW20BALANCE:
          serviceImpl.getCw20Balance((com.injective_explorer_rpc.GetCw20BalanceRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetCw20BalanceResponse>) responseObserver);
          break;
        case METHODID_RELAYERS:
          serviceImpl.relayers((com.injective_explorer_rpc.RelayersRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.RelayersResponse>) responseObserver);
          break;
        case METHODID_GET_BANK_TRANSFERS:
          serviceImpl.getBankTransfers((com.injective_explorer_rpc.GetBankTransfersRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.GetBankTransfersResponse>) responseObserver);
          break;
        case METHODID_STREAM_TXS:
          serviceImpl.streamTxs((com.injective_explorer_rpc.StreamTxsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.StreamTxsResponse>) responseObserver);
          break;
        case METHODID_STREAM_BLOCKS:
          serviceImpl.streamBlocks((com.injective_explorer_rpc.StreamBlocksRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_explorer_rpc.StreamBlocksResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getGetAccountTxsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetAccountTxsRequest,
              com.injective_explorer_rpc.GetAccountTxsResponse>(
                service, METHODID_GET_ACCOUNT_TXS)))
        .addMethod(
          getGetContractTxsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetContractTxsRequest,
              com.injective_explorer_rpc.GetContractTxsResponse>(
                service, METHODID_GET_CONTRACT_TXS)))
        .addMethod(
          getGetBlocksMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetBlocksRequest,
              com.injective_explorer_rpc.GetBlocksResponse>(
                service, METHODID_GET_BLOCKS)))
        .addMethod(
          getGetBlockMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetBlockRequest,
              com.injective_explorer_rpc.GetBlockResponse>(
                service, METHODID_GET_BLOCK)))
        .addMethod(
          getGetValidatorsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetValidatorsRequest,
              com.injective_explorer_rpc.GetValidatorsResponse>(
                service, METHODID_GET_VALIDATORS)))
        .addMethod(
          getGetValidatorMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetValidatorRequest,
              com.injective_explorer_rpc.GetValidatorResponse>(
                service, METHODID_GET_VALIDATOR)))
        .addMethod(
          getGetValidatorUptimeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetValidatorUptimeRequest,
              com.injective_explorer_rpc.GetValidatorUptimeResponse>(
                service, METHODID_GET_VALIDATOR_UPTIME)))
        .addMethod(
          getGetTxsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetTxsRequest,
              com.injective_explorer_rpc.GetTxsResponse>(
                service, METHODID_GET_TXS)))
        .addMethod(
          getGetTxByTxHashMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetTxByTxHashRequest,
              com.injective_explorer_rpc.GetTxByTxHashResponse>(
                service, METHODID_GET_TX_BY_TX_HASH)))
        .addMethod(
          getGetPeggyDepositTxsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetPeggyDepositTxsRequest,
              com.injective_explorer_rpc.GetPeggyDepositTxsResponse>(
                service, METHODID_GET_PEGGY_DEPOSIT_TXS)))
        .addMethod(
          getGetPeggyWithdrawalTxsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetPeggyWithdrawalTxsRequest,
              com.injective_explorer_rpc.GetPeggyWithdrawalTxsResponse>(
                service, METHODID_GET_PEGGY_WITHDRAWAL_TXS)))
        .addMethod(
          getGetIBCTransferTxsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetIBCTransferTxsRequest,
              com.injective_explorer_rpc.GetIBCTransferTxsResponse>(
                service, METHODID_GET_IBCTRANSFER_TXS)))
        .addMethod(
          getGetWasmCodesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetWasmCodesRequest,
              com.injective_explorer_rpc.GetWasmCodesResponse>(
                service, METHODID_GET_WASM_CODES)))
        .addMethod(
          getGetWasmCodeByIDMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetWasmCodeByIDRequest,
              com.injective_explorer_rpc.GetWasmCodeByIDResponse>(
                service, METHODID_GET_WASM_CODE_BY_ID)))
        .addMethod(
          getGetWasmContractsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetWasmContractsRequest,
              com.injective_explorer_rpc.GetWasmContractsResponse>(
                service, METHODID_GET_WASM_CONTRACTS)))
        .addMethod(
          getGetWasmContractByAddressMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetWasmContractByAddressRequest,
              com.injective_explorer_rpc.GetWasmContractByAddressResponse>(
                service, METHODID_GET_WASM_CONTRACT_BY_ADDRESS)))
        .addMethod(
          getGetCw20BalanceMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetCw20BalanceRequest,
              com.injective_explorer_rpc.GetCw20BalanceResponse>(
                service, METHODID_GET_CW20BALANCE)))
        .addMethod(
          getRelayersMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.RelayersRequest,
              com.injective_explorer_rpc.RelayersResponse>(
                service, METHODID_RELAYERS)))
        .addMethod(
          getGetBankTransfersMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_explorer_rpc.GetBankTransfersRequest,
              com.injective_explorer_rpc.GetBankTransfersResponse>(
                service, METHODID_GET_BANK_TRANSFERS)))
        .addMethod(
          getStreamTxsMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.injective_explorer_rpc.StreamTxsRequest,
              com.injective_explorer_rpc.StreamTxsResponse>(
                service, METHODID_STREAM_TXS)))
        .addMethod(
          getStreamBlocksMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.injective_explorer_rpc.StreamBlocksRequest,
              com.injective_explorer_rpc.StreamBlocksResponse>(
                service, METHODID_STREAM_BLOCKS)))
        .build();
  }

  private static abstract class InjectiveExplorerRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    InjectiveExplorerRPCBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.injective_explorer_rpc.InjectiveExplorerRpcProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("InjectiveExplorerRPC");
    }
  }

  private static final class InjectiveExplorerRPCFileDescriptorSupplier
      extends InjectiveExplorerRPCBaseDescriptorSupplier {
    InjectiveExplorerRPCFileDescriptorSupplier() {}
  }

  private static final class InjectiveExplorerRPCMethodDescriptorSupplier
      extends InjectiveExplorerRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    InjectiveExplorerRPCMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (InjectiveExplorerRPCGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new InjectiveExplorerRPCFileDescriptorSupplier())
              .addMethod(getGetAccountTxsMethod())
              .addMethod(getGetContractTxsMethod())
              .addMethod(getGetBlocksMethod())
              .addMethod(getGetBlockMethod())
              .addMethod(getGetValidatorsMethod())
              .addMethod(getGetValidatorMethod())
              .addMethod(getGetValidatorUptimeMethod())
              .addMethod(getGetTxsMethod())
              .addMethod(getGetTxByTxHashMethod())
              .addMethod(getGetPeggyDepositTxsMethod())
              .addMethod(getGetPeggyWithdrawalTxsMethod())
              .addMethod(getGetIBCTransferTxsMethod())
              .addMethod(getGetWasmCodesMethod())
              .addMethod(getGetWasmCodeByIDMethod())
              .addMethod(getGetWasmContractsMethod())
              .addMethod(getGetWasmContractByAddressMethod())
              .addMethod(getGetCw20BalanceMethod())
              .addMethod(getRelayersMethod())
              .addMethod(getGetBankTransfersMethod())
              .addMethod(getStreamTxsMethod())
              .addMethod(getStreamBlocksMethod())
              .build();
        }
      }
    }
    return result;
  }
}

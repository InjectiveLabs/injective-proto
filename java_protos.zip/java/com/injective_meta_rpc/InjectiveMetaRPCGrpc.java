package com.injective_meta_rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * InjectiveMetaRPC is a special API subset to get info about server.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.60.1)",
    comments = "Source: exchange/injective_meta_rpc.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class InjectiveMetaRPCGrpc {

  private InjectiveMetaRPCGrpc() {}

  public static final java.lang.String SERVICE_NAME = "injective_meta_rpc.InjectiveMetaRPC";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.injective_meta_rpc.PingRequest,
      com.injective_meta_rpc.PingResponse> getPingMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Ping",
      requestType = com.injective_meta_rpc.PingRequest.class,
      responseType = com.injective_meta_rpc.PingResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_meta_rpc.PingRequest,
      com.injective_meta_rpc.PingResponse> getPingMethod() {
    io.grpc.MethodDescriptor<com.injective_meta_rpc.PingRequest, com.injective_meta_rpc.PingResponse> getPingMethod;
    if ((getPingMethod = InjectiveMetaRPCGrpc.getPingMethod) == null) {
      synchronized (InjectiveMetaRPCGrpc.class) {
        if ((getPingMethod = InjectiveMetaRPCGrpc.getPingMethod) == null) {
          InjectiveMetaRPCGrpc.getPingMethod = getPingMethod =
              io.grpc.MethodDescriptor.<com.injective_meta_rpc.PingRequest, com.injective_meta_rpc.PingResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Ping"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.PingRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.PingResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveMetaRPCMethodDescriptorSupplier("Ping"))
              .build();
        }
      }
    }
    return getPingMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_meta_rpc.VersionRequest,
      com.injective_meta_rpc.VersionResponse> getVersionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Version",
      requestType = com.injective_meta_rpc.VersionRequest.class,
      responseType = com.injective_meta_rpc.VersionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_meta_rpc.VersionRequest,
      com.injective_meta_rpc.VersionResponse> getVersionMethod() {
    io.grpc.MethodDescriptor<com.injective_meta_rpc.VersionRequest, com.injective_meta_rpc.VersionResponse> getVersionMethod;
    if ((getVersionMethod = InjectiveMetaRPCGrpc.getVersionMethod) == null) {
      synchronized (InjectiveMetaRPCGrpc.class) {
        if ((getVersionMethod = InjectiveMetaRPCGrpc.getVersionMethod) == null) {
          InjectiveMetaRPCGrpc.getVersionMethod = getVersionMethod =
              io.grpc.MethodDescriptor.<com.injective_meta_rpc.VersionRequest, com.injective_meta_rpc.VersionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Version"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.VersionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.VersionResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveMetaRPCMethodDescriptorSupplier("Version"))
              .build();
        }
      }
    }
    return getVersionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_meta_rpc.InfoRequest,
      com.injective_meta_rpc.InfoResponse> getInfoMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Info",
      requestType = com.injective_meta_rpc.InfoRequest.class,
      responseType = com.injective_meta_rpc.InfoResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_meta_rpc.InfoRequest,
      com.injective_meta_rpc.InfoResponse> getInfoMethod() {
    io.grpc.MethodDescriptor<com.injective_meta_rpc.InfoRequest, com.injective_meta_rpc.InfoResponse> getInfoMethod;
    if ((getInfoMethod = InjectiveMetaRPCGrpc.getInfoMethod) == null) {
      synchronized (InjectiveMetaRPCGrpc.class) {
        if ((getInfoMethod = InjectiveMetaRPCGrpc.getInfoMethod) == null) {
          InjectiveMetaRPCGrpc.getInfoMethod = getInfoMethod =
              io.grpc.MethodDescriptor.<com.injective_meta_rpc.InfoRequest, com.injective_meta_rpc.InfoResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Info"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.InfoRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.InfoResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveMetaRPCMethodDescriptorSupplier("Info"))
              .build();
        }
      }
    }
    return getInfoMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_meta_rpc.StreamKeepaliveRequest,
      com.injective_meta_rpc.StreamKeepaliveResponse> getStreamKeepaliveMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamKeepalive",
      requestType = com.injective_meta_rpc.StreamKeepaliveRequest.class,
      responseType = com.injective_meta_rpc.StreamKeepaliveResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.injective_meta_rpc.StreamKeepaliveRequest,
      com.injective_meta_rpc.StreamKeepaliveResponse> getStreamKeepaliveMethod() {
    io.grpc.MethodDescriptor<com.injective_meta_rpc.StreamKeepaliveRequest, com.injective_meta_rpc.StreamKeepaliveResponse> getStreamKeepaliveMethod;
    if ((getStreamKeepaliveMethod = InjectiveMetaRPCGrpc.getStreamKeepaliveMethod) == null) {
      synchronized (InjectiveMetaRPCGrpc.class) {
        if ((getStreamKeepaliveMethod = InjectiveMetaRPCGrpc.getStreamKeepaliveMethod) == null) {
          InjectiveMetaRPCGrpc.getStreamKeepaliveMethod = getStreamKeepaliveMethod =
              io.grpc.MethodDescriptor.<com.injective_meta_rpc.StreamKeepaliveRequest, com.injective_meta_rpc.StreamKeepaliveResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StreamKeepalive"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.StreamKeepaliveRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.StreamKeepaliveResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveMetaRPCMethodDescriptorSupplier("StreamKeepalive"))
              .build();
        }
      }
    }
    return getStreamKeepaliveMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_meta_rpc.TokenMetadataRequest,
      com.injective_meta_rpc.TokenMetadataResponse> getTokenMetadataMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TokenMetadata",
      requestType = com.injective_meta_rpc.TokenMetadataRequest.class,
      responseType = com.injective_meta_rpc.TokenMetadataResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_meta_rpc.TokenMetadataRequest,
      com.injective_meta_rpc.TokenMetadataResponse> getTokenMetadataMethod() {
    io.grpc.MethodDescriptor<com.injective_meta_rpc.TokenMetadataRequest, com.injective_meta_rpc.TokenMetadataResponse> getTokenMetadataMethod;
    if ((getTokenMetadataMethod = InjectiveMetaRPCGrpc.getTokenMetadataMethod) == null) {
      synchronized (InjectiveMetaRPCGrpc.class) {
        if ((getTokenMetadataMethod = InjectiveMetaRPCGrpc.getTokenMetadataMethod) == null) {
          InjectiveMetaRPCGrpc.getTokenMetadataMethod = getTokenMetadataMethod =
              io.grpc.MethodDescriptor.<com.injective_meta_rpc.TokenMetadataRequest, com.injective_meta_rpc.TokenMetadataResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "TokenMetadata"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.TokenMetadataRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_meta_rpc.TokenMetadataResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveMetaRPCMethodDescriptorSupplier("TokenMetadata"))
              .build();
        }
      }
    }
    return getTokenMetadataMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static InjectiveMetaRPCStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveMetaRPCStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveMetaRPCStub>() {
        @java.lang.Override
        public InjectiveMetaRPCStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveMetaRPCStub(channel, callOptions);
        }
      };
    return InjectiveMetaRPCStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static InjectiveMetaRPCBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveMetaRPCBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveMetaRPCBlockingStub>() {
        @java.lang.Override
        public InjectiveMetaRPCBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveMetaRPCBlockingStub(channel, callOptions);
        }
      };
    return InjectiveMetaRPCBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static InjectiveMetaRPCFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveMetaRPCFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveMetaRPCFutureStub>() {
        @java.lang.Override
        public InjectiveMetaRPCFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveMetaRPCFutureStub(channel, callOptions);
        }
      };
    return InjectiveMetaRPCFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * InjectiveMetaRPC is a special API subset to get info about server.
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Endpoint for checking server health.
     * </pre>
     */
    default void ping(com.injective_meta_rpc.PingRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.PingResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPingMethod(), responseObserver);
    }

    /**
     * <pre>
     * Returns injective-exchange version.
     * </pre>
     */
    default void version(com.injective_meta_rpc.VersionRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.VersionResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getVersionMethod(), responseObserver);
    }

    /**
     * <pre>
     * Gets connection info
     * </pre>
     */
    default void info(com.injective_meta_rpc.InfoRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.InfoResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getInfoMethod(), responseObserver);
    }

    /**
     * <pre>
     * Stream keepalive, if server exits, a shutdown event will be sent over this
     * channel.
     * </pre>
     */
    default void streamKeepalive(com.injective_meta_rpc.StreamKeepaliveRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.StreamKeepaliveResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStreamKeepaliveMethod(), responseObserver);
    }

    /**
     * <pre>
     * Get tokens metadata. Can be filtered by denom
     * </pre>
     */
    default void tokenMetadata(com.injective_meta_rpc.TokenMetadataRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.TokenMetadataResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getTokenMetadataMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service InjectiveMetaRPC.
   * <pre>
   * InjectiveMetaRPC is a special API subset to get info about server.
   * </pre>
   */
  public static abstract class InjectiveMetaRPCImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return InjectiveMetaRPCGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service InjectiveMetaRPC.
   * <pre>
   * InjectiveMetaRPC is a special API subset to get info about server.
   * </pre>
   */
  public static final class InjectiveMetaRPCStub
      extends io.grpc.stub.AbstractAsyncStub<InjectiveMetaRPCStub> {
    private InjectiveMetaRPCStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveMetaRPCStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveMetaRPCStub(channel, callOptions);
    }

    /**
     * <pre>
     * Endpoint for checking server health.
     * </pre>
     */
    public void ping(com.injective_meta_rpc.PingRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.PingResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPingMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Returns injective-exchange version.
     * </pre>
     */
    public void version(com.injective_meta_rpc.VersionRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.VersionResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getVersionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Gets connection info
     * </pre>
     */
    public void info(com.injective_meta_rpc.InfoRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.InfoResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getInfoMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Stream keepalive, if server exits, a shutdown event will be sent over this
     * channel.
     * </pre>
     */
    public void streamKeepalive(com.injective_meta_rpc.StreamKeepaliveRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.StreamKeepaliveResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getStreamKeepaliveMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Get tokens metadata. Can be filtered by denom
     * </pre>
     */
    public void tokenMetadata(com.injective_meta_rpc.TokenMetadataRequest request,
        io.grpc.stub.StreamObserver<com.injective_meta_rpc.TokenMetadataResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getTokenMetadataMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service InjectiveMetaRPC.
   * <pre>
   * InjectiveMetaRPC is a special API subset to get info about server.
   * </pre>
   */
  public static final class InjectiveMetaRPCBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<InjectiveMetaRPCBlockingStub> {
    private InjectiveMetaRPCBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveMetaRPCBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveMetaRPCBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Endpoint for checking server health.
     * </pre>
     */
    public com.injective_meta_rpc.PingResponse ping(com.injective_meta_rpc.PingRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPingMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns injective-exchange version.
     * </pre>
     */
    public com.injective_meta_rpc.VersionResponse version(com.injective_meta_rpc.VersionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getVersionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Gets connection info
     * </pre>
     */
    public com.injective_meta_rpc.InfoResponse info(com.injective_meta_rpc.InfoRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInfoMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Stream keepalive, if server exits, a shutdown event will be sent over this
     * channel.
     * </pre>
     */
    public java.util.Iterator<com.injective_meta_rpc.StreamKeepaliveResponse> streamKeepalive(
        com.injective_meta_rpc.StreamKeepaliveRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getStreamKeepaliveMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Get tokens metadata. Can be filtered by denom
     * </pre>
     */
    public com.injective_meta_rpc.TokenMetadataResponse tokenMetadata(com.injective_meta_rpc.TokenMetadataRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getTokenMetadataMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service InjectiveMetaRPC.
   * <pre>
   * InjectiveMetaRPC is a special API subset to get info about server.
   * </pre>
   */
  public static final class InjectiveMetaRPCFutureStub
      extends io.grpc.stub.AbstractFutureStub<InjectiveMetaRPCFutureStub> {
    private InjectiveMetaRPCFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveMetaRPCFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveMetaRPCFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Endpoint for checking server health.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_meta_rpc.PingResponse> ping(
        com.injective_meta_rpc.PingRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPingMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Returns injective-exchange version.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_meta_rpc.VersionResponse> version(
        com.injective_meta_rpc.VersionRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getVersionMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Gets connection info
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_meta_rpc.InfoResponse> info(
        com.injective_meta_rpc.InfoRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getInfoMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Get tokens metadata. Can be filtered by denom
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_meta_rpc.TokenMetadataResponse> tokenMetadata(
        com.injective_meta_rpc.TokenMetadataRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getTokenMetadataMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_PING = 0;
  private static final int METHODID_VERSION = 1;
  private static final int METHODID_INFO = 2;
  private static final int METHODID_STREAM_KEEPALIVE = 3;
  private static final int METHODID_TOKEN_METADATA = 4;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_PING:
          serviceImpl.ping((com.injective_meta_rpc.PingRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_meta_rpc.PingResponse>) responseObserver);
          break;
        case METHODID_VERSION:
          serviceImpl.version((com.injective_meta_rpc.VersionRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_meta_rpc.VersionResponse>) responseObserver);
          break;
        case METHODID_INFO:
          serviceImpl.info((com.injective_meta_rpc.InfoRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_meta_rpc.InfoResponse>) responseObserver);
          break;
        case METHODID_STREAM_KEEPALIVE:
          serviceImpl.streamKeepalive((com.injective_meta_rpc.StreamKeepaliveRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_meta_rpc.StreamKeepaliveResponse>) responseObserver);
          break;
        case METHODID_TOKEN_METADATA:
          serviceImpl.tokenMetadata((com.injective_meta_rpc.TokenMetadataRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_meta_rpc.TokenMetadataResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getPingMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_meta_rpc.PingRequest,
              com.injective_meta_rpc.PingResponse>(
                service, METHODID_PING)))
        .addMethod(
          getVersionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_meta_rpc.VersionRequest,
              com.injective_meta_rpc.VersionResponse>(
                service, METHODID_VERSION)))
        .addMethod(
          getInfoMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_meta_rpc.InfoRequest,
              com.injective_meta_rpc.InfoResponse>(
                service, METHODID_INFO)))
        .addMethod(
          getStreamKeepaliveMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.injective_meta_rpc.StreamKeepaliveRequest,
              com.injective_meta_rpc.StreamKeepaliveResponse>(
                service, METHODID_STREAM_KEEPALIVE)))
        .addMethod(
          getTokenMetadataMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_meta_rpc.TokenMetadataRequest,
              com.injective_meta_rpc.TokenMetadataResponse>(
                service, METHODID_TOKEN_METADATA)))
        .build();
  }

  private static abstract class InjectiveMetaRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    InjectiveMetaRPCBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.injective_meta_rpc.InjectiveMetaRpcProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("InjectiveMetaRPC");
    }
  }

  private static final class InjectiveMetaRPCFileDescriptorSupplier
      extends InjectiveMetaRPCBaseDescriptorSupplier {
    InjectiveMetaRPCFileDescriptorSupplier() {}
  }

  private static final class InjectiveMetaRPCMethodDescriptorSupplier
      extends InjectiveMetaRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    InjectiveMetaRPCMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (InjectiveMetaRPCGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new InjectiveMetaRPCFileDescriptorSupplier())
              .addMethod(getPingMethod())
              .addMethod(getVersionMethod())
              .addMethod(getInfoMethod())
              .addMethod(getStreamKeepaliveMethod())
              .addMethod(getTokenMetadataMethod())
              .build();
        }
      }
    }
    return result;
  }
}

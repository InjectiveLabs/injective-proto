package com.injective_rfq_rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * InjectiveRfqRPC defines gRPC API of the RFQ (Request for Quote) API.
 * </pre>
 */
@io.grpc.stub.annotations.GrpcGenerated
public final class InjectiveRfqRPCGrpc {

  private InjectiveRfqRPCGrpc() {}

  public static final java.lang.String SERVICE_NAME = "injective_rfq_rpc.InjectiveRfqRPC";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.RequestRequest,
      com.injective_rfq_rpc.RequestResponse> getRequestMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Request",
      requestType = com.injective_rfq_rpc.RequestRequest.class,
      responseType = com.injective_rfq_rpc.RequestResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.RequestRequest,
      com.injective_rfq_rpc.RequestResponse> getRequestMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.RequestRequest, com.injective_rfq_rpc.RequestResponse> getRequestMethod;
    if ((getRequestMethod = InjectiveRfqRPCGrpc.getRequestMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getRequestMethod = InjectiveRfqRPCGrpc.getRequestMethod) == null) {
          InjectiveRfqRPCGrpc.getRequestMethod = getRequestMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.RequestRequest, com.injective_rfq_rpc.RequestResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Request"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.RequestRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.RequestResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("Request"))
              .build();
        }
      }
    }
    return getRequestMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.StreamRequestRequest,
      com.injective_rfq_rpc.StreamRequestResponse> getStreamRequestMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamRequest",
      requestType = com.injective_rfq_rpc.StreamRequestRequest.class,
      responseType = com.injective_rfq_rpc.StreamRequestResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.StreamRequestRequest,
      com.injective_rfq_rpc.StreamRequestResponse> getStreamRequestMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.StreamRequestRequest, com.injective_rfq_rpc.StreamRequestResponse> getStreamRequestMethod;
    if ((getStreamRequestMethod = InjectiveRfqRPCGrpc.getStreamRequestMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getStreamRequestMethod = InjectiveRfqRPCGrpc.getStreamRequestMethod) == null) {
          InjectiveRfqRPCGrpc.getStreamRequestMethod = getStreamRequestMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.StreamRequestRequest, com.injective_rfq_rpc.StreamRequestResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StreamRequest"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.StreamRequestRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.StreamRequestResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("StreamRequest"))
              .build();
        }
      }
    }
    return getStreamRequestMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.QuoteRequest,
      com.injective_rfq_rpc.QuoteResponse> getQuoteMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Quote",
      requestType = com.injective_rfq_rpc.QuoteRequest.class,
      responseType = com.injective_rfq_rpc.QuoteResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.QuoteRequest,
      com.injective_rfq_rpc.QuoteResponse> getQuoteMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.QuoteRequest, com.injective_rfq_rpc.QuoteResponse> getQuoteMethod;
    if ((getQuoteMethod = InjectiveRfqRPCGrpc.getQuoteMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getQuoteMethod = InjectiveRfqRPCGrpc.getQuoteMethod) == null) {
          InjectiveRfqRPCGrpc.getQuoteMethod = getQuoteMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.QuoteRequest, com.injective_rfq_rpc.QuoteResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Quote"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.QuoteRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.QuoteResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("Quote"))
              .build();
        }
      }
    }
    return getQuoteMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.StreamQuoteRequest,
      com.injective_rfq_rpc.StreamQuoteResponse> getStreamQuoteMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamQuote",
      requestType = com.injective_rfq_rpc.StreamQuoteRequest.class,
      responseType = com.injective_rfq_rpc.StreamQuoteResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.StreamQuoteRequest,
      com.injective_rfq_rpc.StreamQuoteResponse> getStreamQuoteMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.StreamQuoteRequest, com.injective_rfq_rpc.StreamQuoteResponse> getStreamQuoteMethod;
    if ((getStreamQuoteMethod = InjectiveRfqRPCGrpc.getStreamQuoteMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getStreamQuoteMethod = InjectiveRfqRPCGrpc.getStreamQuoteMethod) == null) {
          InjectiveRfqRPCGrpc.getStreamQuoteMethod = getStreamQuoteMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.StreamQuoteRequest, com.injective_rfq_rpc.StreamQuoteResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StreamQuote"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.StreamQuoteRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.StreamQuoteResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("StreamQuote"))
              .build();
        }
      }
    }
    return getStreamQuoteMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.ListSettlementRequest,
      com.injective_rfq_rpc.ListSettlementResponse> getListSettlementMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListSettlement",
      requestType = com.injective_rfq_rpc.ListSettlementRequest.class,
      responseType = com.injective_rfq_rpc.ListSettlementResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.ListSettlementRequest,
      com.injective_rfq_rpc.ListSettlementResponse> getListSettlementMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.ListSettlementRequest, com.injective_rfq_rpc.ListSettlementResponse> getListSettlementMethod;
    if ((getListSettlementMethod = InjectiveRfqRPCGrpc.getListSettlementMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getListSettlementMethod = InjectiveRfqRPCGrpc.getListSettlementMethod) == null) {
          InjectiveRfqRPCGrpc.getListSettlementMethod = getListSettlementMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.ListSettlementRequest, com.injective_rfq_rpc.ListSettlementResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListSettlement"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.ListSettlementRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.ListSettlementResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("ListSettlement"))
              .build();
        }
      }
    }
    return getListSettlementMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.StreamSettlementRequest,
      com.injective_rfq_rpc.StreamSettlementResponse> getStreamSettlementMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamSettlement",
      requestType = com.injective_rfq_rpc.StreamSettlementRequest.class,
      responseType = com.injective_rfq_rpc.StreamSettlementResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.StreamSettlementRequest,
      com.injective_rfq_rpc.StreamSettlementResponse> getStreamSettlementMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.StreamSettlementRequest, com.injective_rfq_rpc.StreamSettlementResponse> getStreamSettlementMethod;
    if ((getStreamSettlementMethod = InjectiveRfqRPCGrpc.getStreamSettlementMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getStreamSettlementMethod = InjectiveRfqRPCGrpc.getStreamSettlementMethod) == null) {
          InjectiveRfqRPCGrpc.getStreamSettlementMethod = getStreamSettlementMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.StreamSettlementRequest, com.injective_rfq_rpc.StreamSettlementResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StreamSettlement"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.StreamSettlementRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.StreamSettlementResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("StreamSettlement"))
              .build();
        }
      }
    }
    return getStreamSettlementMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.CreateConditionalOrderRequest,
      com.injective_rfq_rpc.CreateConditionalOrderResponse> getCreateConditionalOrderMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateConditionalOrder",
      requestType = com.injective_rfq_rpc.CreateConditionalOrderRequest.class,
      responseType = com.injective_rfq_rpc.CreateConditionalOrderResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.CreateConditionalOrderRequest,
      com.injective_rfq_rpc.CreateConditionalOrderResponse> getCreateConditionalOrderMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.CreateConditionalOrderRequest, com.injective_rfq_rpc.CreateConditionalOrderResponse> getCreateConditionalOrderMethod;
    if ((getCreateConditionalOrderMethod = InjectiveRfqRPCGrpc.getCreateConditionalOrderMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getCreateConditionalOrderMethod = InjectiveRfqRPCGrpc.getCreateConditionalOrderMethod) == null) {
          InjectiveRfqRPCGrpc.getCreateConditionalOrderMethod = getCreateConditionalOrderMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.CreateConditionalOrderRequest, com.injective_rfq_rpc.CreateConditionalOrderResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateConditionalOrder"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.CreateConditionalOrderRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.CreateConditionalOrderResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("CreateConditionalOrder"))
              .build();
        }
      }
    }
    return getCreateConditionalOrderMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.ListConditionalOrdersRequest,
      com.injective_rfq_rpc.ListConditionalOrdersResponse> getListConditionalOrdersMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListConditionalOrders",
      requestType = com.injective_rfq_rpc.ListConditionalOrdersRequest.class,
      responseType = com.injective_rfq_rpc.ListConditionalOrdersResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.ListConditionalOrdersRequest,
      com.injective_rfq_rpc.ListConditionalOrdersResponse> getListConditionalOrdersMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.ListConditionalOrdersRequest, com.injective_rfq_rpc.ListConditionalOrdersResponse> getListConditionalOrdersMethod;
    if ((getListConditionalOrdersMethod = InjectiveRfqRPCGrpc.getListConditionalOrdersMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getListConditionalOrdersMethod = InjectiveRfqRPCGrpc.getListConditionalOrdersMethod) == null) {
          InjectiveRfqRPCGrpc.getListConditionalOrdersMethod = getListConditionalOrdersMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.ListConditionalOrdersRequest, com.injective_rfq_rpc.ListConditionalOrdersResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListConditionalOrders"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.ListConditionalOrdersRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.ListConditionalOrdersResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("ListConditionalOrders"))
              .build();
        }
      }
    }
    return getListConditionalOrdersMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.TakerStreamStreamingRequest,
      com.injective_rfq_rpc.TakerStreamResponse> getTakerStreamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "TakerStream",
      requestType = com.injective_rfq_rpc.TakerStreamStreamingRequest.class,
      responseType = com.injective_rfq_rpc.TakerStreamResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.TakerStreamStreamingRequest,
      com.injective_rfq_rpc.TakerStreamResponse> getTakerStreamMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.TakerStreamStreamingRequest, com.injective_rfq_rpc.TakerStreamResponse> getTakerStreamMethod;
    if ((getTakerStreamMethod = InjectiveRfqRPCGrpc.getTakerStreamMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getTakerStreamMethod = InjectiveRfqRPCGrpc.getTakerStreamMethod) == null) {
          InjectiveRfqRPCGrpc.getTakerStreamMethod = getTakerStreamMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.TakerStreamStreamingRequest, com.injective_rfq_rpc.TakerStreamResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "TakerStream"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.TakerStreamStreamingRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.TakerStreamResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("TakerStream"))
              .build();
        }
      }
    }
    return getTakerStreamMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_rfq_rpc.MakerStreamStreamingRequest,
      com.injective_rfq_rpc.MakerStreamResponse> getMakerStreamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "MakerStream",
      requestType = com.injective_rfq_rpc.MakerStreamStreamingRequest.class,
      responseType = com.injective_rfq_rpc.MakerStreamResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<com.injective_rfq_rpc.MakerStreamStreamingRequest,
      com.injective_rfq_rpc.MakerStreamResponse> getMakerStreamMethod() {
    io.grpc.MethodDescriptor<com.injective_rfq_rpc.MakerStreamStreamingRequest, com.injective_rfq_rpc.MakerStreamResponse> getMakerStreamMethod;
    if ((getMakerStreamMethod = InjectiveRfqRPCGrpc.getMakerStreamMethod) == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        if ((getMakerStreamMethod = InjectiveRfqRPCGrpc.getMakerStreamMethod) == null) {
          InjectiveRfqRPCGrpc.getMakerStreamMethod = getMakerStreamMethod =
              io.grpc.MethodDescriptor.<com.injective_rfq_rpc.MakerStreamStreamingRequest, com.injective_rfq_rpc.MakerStreamResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "MakerStream"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.MakerStreamStreamingRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_rfq_rpc.MakerStreamResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveRfqRPCMethodDescriptorSupplier("MakerStream"))
              .build();
        }
      }
    }
    return getMakerStreamMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static InjectiveRfqRPCStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveRfqRPCStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveRfqRPCStub>() {
        @java.lang.Override
        public InjectiveRfqRPCStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveRfqRPCStub(channel, callOptions);
        }
      };
    return InjectiveRfqRPCStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static InjectiveRfqRPCBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveRfqRPCBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveRfqRPCBlockingV2Stub>() {
        @java.lang.Override
        public InjectiveRfqRPCBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveRfqRPCBlockingV2Stub(channel, callOptions);
        }
      };
    return InjectiveRfqRPCBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static InjectiveRfqRPCBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveRfqRPCBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveRfqRPCBlockingStub>() {
        @java.lang.Override
        public InjectiveRfqRPCBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveRfqRPCBlockingStub(channel, callOptions);
        }
      };
    return InjectiveRfqRPCBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static InjectiveRfqRPCFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveRfqRPCFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveRfqRPCFutureStub>() {
        @java.lang.Override
        public InjectiveRfqRPCFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveRfqRPCFutureStub(channel, callOptions);
        }
      };
    return InjectiveRfqRPCFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * InjectiveRfqRPC defines gRPC API of the RFQ (Request for Quote) API.
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Create RFQ request
     * </pre>
     */
    default void request(com.injective_rfq_rpc.RequestRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.RequestResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRequestMethod(), responseObserver);
    }

    /**
     * <pre>
     * Stream RFQ requests
     * </pre>
     */
    default void streamRequest(com.injective_rfq_rpc.StreamRequestRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.StreamRequestResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStreamRequestMethod(), responseObserver);
    }

    /**
     * <pre>
     * Create RFQ quote
     * </pre>
     */
    default void quote(com.injective_rfq_rpc.QuoteRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.QuoteResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getQuoteMethod(), responseObserver);
    }

    /**
     * <pre>
     * Stream RFQ quotes
     * </pre>
     */
    default void streamQuote(com.injective_rfq_rpc.StreamQuoteRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.StreamQuoteResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStreamQuoteMethod(), responseObserver);
    }

    /**
     * <pre>
     * List RFQ settlements
     * </pre>
     */
    default void listSettlement(com.injective_rfq_rpc.ListSettlementRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.ListSettlementResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListSettlementMethod(), responseObserver);
    }

    /**
     * <pre>
     * Stream RFQ settlements
     * </pre>
     */
    default void streamSettlement(com.injective_rfq_rpc.StreamSettlementRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.StreamSettlementResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStreamSettlementMethod(), responseObserver);
    }

    /**
     * <pre>
     * Create a conditional TP/SL order
     * </pre>
     */
    default void createConditionalOrder(com.injective_rfq_rpc.CreateConditionalOrderRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.CreateConditionalOrderResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateConditionalOrderMethod(), responseObserver);
    }

    /**
     * <pre>
     * List conditional TP/SL orders
     * </pre>
     */
    default void listConditionalOrders(com.injective_rfq_rpc.ListConditionalOrdersRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.ListConditionalOrdersResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListConditionalOrdersMethod(), responseObserver);
    }

    /**
     * <pre>
     * Bidirectional stream for takers: send requests, receive quotes
     * </pre>
     */
    default io.grpc.stub.StreamObserver<com.injective_rfq_rpc.TakerStreamStreamingRequest> takerStream(
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.TakerStreamResponse> responseObserver) {
      return io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall(getTakerStreamMethod(), responseObserver);
    }

    /**
     * <pre>
     * Bidirectional stream for makers: receive requests, send quotes
     * </pre>
     */
    default io.grpc.stub.StreamObserver<com.injective_rfq_rpc.MakerStreamStreamingRequest> makerStream(
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.MakerStreamResponse> responseObserver) {
      return io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall(getMakerStreamMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service InjectiveRfqRPC.
   * <pre>
   * InjectiveRfqRPC defines gRPC API of the RFQ (Request for Quote) API.
   * </pre>
   */
  public static abstract class InjectiveRfqRPCImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return InjectiveRfqRPCGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service InjectiveRfqRPC.
   * <pre>
   * InjectiveRfqRPC defines gRPC API of the RFQ (Request for Quote) API.
   * </pre>
   */
  public static final class InjectiveRfqRPCStub
      extends io.grpc.stub.AbstractAsyncStub<InjectiveRfqRPCStub> {
    private InjectiveRfqRPCStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveRfqRPCStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveRfqRPCStub(channel, callOptions);
    }

    /**
     * <pre>
     * Create RFQ request
     * </pre>
     */
    public void request(com.injective_rfq_rpc.RequestRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.RequestResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRequestMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Stream RFQ requests
     * </pre>
     */
    public void streamRequest(com.injective_rfq_rpc.StreamRequestRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.StreamRequestResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getStreamRequestMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Create RFQ quote
     * </pre>
     */
    public void quote(com.injective_rfq_rpc.QuoteRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.QuoteResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getQuoteMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Stream RFQ quotes
     * </pre>
     */
    public void streamQuote(com.injective_rfq_rpc.StreamQuoteRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.StreamQuoteResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getStreamQuoteMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * List RFQ settlements
     * </pre>
     */
    public void listSettlement(com.injective_rfq_rpc.ListSettlementRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.ListSettlementResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListSettlementMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Stream RFQ settlements
     * </pre>
     */
    public void streamSettlement(com.injective_rfq_rpc.StreamSettlementRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.StreamSettlementResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getStreamSettlementMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Create a conditional TP/SL order
     * </pre>
     */
    public void createConditionalOrder(com.injective_rfq_rpc.CreateConditionalOrderRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.CreateConditionalOrderResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateConditionalOrderMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * List conditional TP/SL orders
     * </pre>
     */
    public void listConditionalOrders(com.injective_rfq_rpc.ListConditionalOrdersRequest request,
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.ListConditionalOrdersResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListConditionalOrdersMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Bidirectional stream for takers: send requests, receive quotes
     * </pre>
     */
    public io.grpc.stub.StreamObserver<com.injective_rfq_rpc.TakerStreamStreamingRequest> takerStream(
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.TakerStreamResponse> responseObserver) {
      return io.grpc.stub.ClientCalls.asyncBidiStreamingCall(
          getChannel().newCall(getTakerStreamMethod(), getCallOptions()), responseObserver);
    }

    /**
     * <pre>
     * Bidirectional stream for makers: receive requests, send quotes
     * </pre>
     */
    public io.grpc.stub.StreamObserver<com.injective_rfq_rpc.MakerStreamStreamingRequest> makerStream(
        io.grpc.stub.StreamObserver<com.injective_rfq_rpc.MakerStreamResponse> responseObserver) {
      return io.grpc.stub.ClientCalls.asyncBidiStreamingCall(
          getChannel().newCall(getMakerStreamMethod(), getCallOptions()), responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service InjectiveRfqRPC.
   * <pre>
   * InjectiveRfqRPC defines gRPC API of the RFQ (Request for Quote) API.
   * </pre>
   */
  public static final class InjectiveRfqRPCBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<InjectiveRfqRPCBlockingV2Stub> {
    private InjectiveRfqRPCBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveRfqRPCBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveRfqRPCBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Create RFQ request
     * </pre>
     */
    public com.injective_rfq_rpc.RequestResponse request(com.injective_rfq_rpc.RequestRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getRequestMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Stream RFQ requests
     * </pre>
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<?, com.injective_rfq_rpc.StreamRequestResponse>
        streamRequest(com.injective_rfq_rpc.StreamRequestRequest request) {
      return io.grpc.stub.ClientCalls.blockingV2ServerStreamingCall(
          getChannel(), getStreamRequestMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Create RFQ quote
     * </pre>
     */
    public com.injective_rfq_rpc.QuoteResponse quote(com.injective_rfq_rpc.QuoteRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getQuoteMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Stream RFQ quotes
     * </pre>
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<?, com.injective_rfq_rpc.StreamQuoteResponse>
        streamQuote(com.injective_rfq_rpc.StreamQuoteRequest request) {
      return io.grpc.stub.ClientCalls.blockingV2ServerStreamingCall(
          getChannel(), getStreamQuoteMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * List RFQ settlements
     * </pre>
     */
    public com.injective_rfq_rpc.ListSettlementResponse listSettlement(com.injective_rfq_rpc.ListSettlementRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getListSettlementMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Stream RFQ settlements
     * </pre>
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<?, com.injective_rfq_rpc.StreamSettlementResponse>
        streamSettlement(com.injective_rfq_rpc.StreamSettlementRequest request) {
      return io.grpc.stub.ClientCalls.blockingV2ServerStreamingCall(
          getChannel(), getStreamSettlementMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Create a conditional TP/SL order
     * </pre>
     */
    public com.injective_rfq_rpc.CreateConditionalOrderResponse createConditionalOrder(com.injective_rfq_rpc.CreateConditionalOrderRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getCreateConditionalOrderMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * List conditional TP/SL orders
     * </pre>
     */
    public com.injective_rfq_rpc.ListConditionalOrdersResponse listConditionalOrders(com.injective_rfq_rpc.ListConditionalOrdersRequest request) throws io.grpc.StatusException {
      return io.grpc.stub.ClientCalls.blockingV2UnaryCall(
          getChannel(), getListConditionalOrdersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Bidirectional stream for takers: send requests, receive quotes
     * </pre>
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<com.injective_rfq_rpc.TakerStreamStreamingRequest, com.injective_rfq_rpc.TakerStreamResponse>
        takerStream() {
      return io.grpc.stub.ClientCalls.blockingBidiStreamingCall(
          getChannel(), getTakerStreamMethod(), getCallOptions());
    }

    /**
     * <pre>
     * Bidirectional stream for makers: receive requests, send quotes
     * </pre>
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<com.injective_rfq_rpc.MakerStreamStreamingRequest, com.injective_rfq_rpc.MakerStreamResponse>
        makerStream() {
      return io.grpc.stub.ClientCalls.blockingBidiStreamingCall(
          getChannel(), getMakerStreamMethod(), getCallOptions());
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service InjectiveRfqRPC.
   * <pre>
   * InjectiveRfqRPC defines gRPC API of the RFQ (Request for Quote) API.
   * </pre>
   */
  public static final class InjectiveRfqRPCBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<InjectiveRfqRPCBlockingStub> {
    private InjectiveRfqRPCBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveRfqRPCBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveRfqRPCBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Create RFQ request
     * </pre>
     */
    public com.injective_rfq_rpc.RequestResponse request(com.injective_rfq_rpc.RequestRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRequestMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Stream RFQ requests
     * </pre>
     */
    public java.util.Iterator<com.injective_rfq_rpc.StreamRequestResponse> streamRequest(
        com.injective_rfq_rpc.StreamRequestRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getStreamRequestMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Create RFQ quote
     * </pre>
     */
    public com.injective_rfq_rpc.QuoteResponse quote(com.injective_rfq_rpc.QuoteRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getQuoteMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Stream RFQ quotes
     * </pre>
     */
    public java.util.Iterator<com.injective_rfq_rpc.StreamQuoteResponse> streamQuote(
        com.injective_rfq_rpc.StreamQuoteRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getStreamQuoteMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * List RFQ settlements
     * </pre>
     */
    public com.injective_rfq_rpc.ListSettlementResponse listSettlement(com.injective_rfq_rpc.ListSettlementRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListSettlementMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Stream RFQ settlements
     * </pre>
     */
    public java.util.Iterator<com.injective_rfq_rpc.StreamSettlementResponse> streamSettlement(
        com.injective_rfq_rpc.StreamSettlementRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getStreamSettlementMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Create a conditional TP/SL order
     * </pre>
     */
    public com.injective_rfq_rpc.CreateConditionalOrderResponse createConditionalOrder(com.injective_rfq_rpc.CreateConditionalOrderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateConditionalOrderMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * List conditional TP/SL orders
     * </pre>
     */
    public com.injective_rfq_rpc.ListConditionalOrdersResponse listConditionalOrders(com.injective_rfq_rpc.ListConditionalOrdersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListConditionalOrdersMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service InjectiveRfqRPC.
   * <pre>
   * InjectiveRfqRPC defines gRPC API of the RFQ (Request for Quote) API.
   * </pre>
   */
  public static final class InjectiveRfqRPCFutureStub
      extends io.grpc.stub.AbstractFutureStub<InjectiveRfqRPCFutureStub> {
    private InjectiveRfqRPCFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveRfqRPCFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveRfqRPCFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Create RFQ request
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_rfq_rpc.RequestResponse> request(
        com.injective_rfq_rpc.RequestRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRequestMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Create RFQ quote
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_rfq_rpc.QuoteResponse> quote(
        com.injective_rfq_rpc.QuoteRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getQuoteMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * List RFQ settlements
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_rfq_rpc.ListSettlementResponse> listSettlement(
        com.injective_rfq_rpc.ListSettlementRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListSettlementMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Create a conditional TP/SL order
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_rfq_rpc.CreateConditionalOrderResponse> createConditionalOrder(
        com.injective_rfq_rpc.CreateConditionalOrderRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateConditionalOrderMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * List conditional TP/SL orders
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_rfq_rpc.ListConditionalOrdersResponse> listConditionalOrders(
        com.injective_rfq_rpc.ListConditionalOrdersRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListConditionalOrdersMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_REQUEST = 0;
  private static final int METHODID_STREAM_REQUEST = 1;
  private static final int METHODID_QUOTE = 2;
  private static final int METHODID_STREAM_QUOTE = 3;
  private static final int METHODID_LIST_SETTLEMENT = 4;
  private static final int METHODID_STREAM_SETTLEMENT = 5;
  private static final int METHODID_CREATE_CONDITIONAL_ORDER = 6;
  private static final int METHODID_LIST_CONDITIONAL_ORDERS = 7;
  private static final int METHODID_TAKER_STREAM = 8;
  private static final int METHODID_MAKER_STREAM = 9;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_REQUEST:
          serviceImpl.request((com.injective_rfq_rpc.RequestRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.RequestResponse>) responseObserver);
          break;
        case METHODID_STREAM_REQUEST:
          serviceImpl.streamRequest((com.injective_rfq_rpc.StreamRequestRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.StreamRequestResponse>) responseObserver);
          break;
        case METHODID_QUOTE:
          serviceImpl.quote((com.injective_rfq_rpc.QuoteRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.QuoteResponse>) responseObserver);
          break;
        case METHODID_STREAM_QUOTE:
          serviceImpl.streamQuote((com.injective_rfq_rpc.StreamQuoteRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.StreamQuoteResponse>) responseObserver);
          break;
        case METHODID_LIST_SETTLEMENT:
          serviceImpl.listSettlement((com.injective_rfq_rpc.ListSettlementRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.ListSettlementResponse>) responseObserver);
          break;
        case METHODID_STREAM_SETTLEMENT:
          serviceImpl.streamSettlement((com.injective_rfq_rpc.StreamSettlementRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.StreamSettlementResponse>) responseObserver);
          break;
        case METHODID_CREATE_CONDITIONAL_ORDER:
          serviceImpl.createConditionalOrder((com.injective_rfq_rpc.CreateConditionalOrderRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.CreateConditionalOrderResponse>) responseObserver);
          break;
        case METHODID_LIST_CONDITIONAL_ORDERS:
          serviceImpl.listConditionalOrders((com.injective_rfq_rpc.ListConditionalOrdersRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.ListConditionalOrdersResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_TAKER_STREAM:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.takerStream(
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.TakerStreamResponse>) responseObserver);
        case METHODID_MAKER_STREAM:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.makerStream(
              (io.grpc.stub.StreamObserver<com.injective_rfq_rpc.MakerStreamResponse>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getRequestMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_rfq_rpc.RequestRequest,
              com.injective_rfq_rpc.RequestResponse>(
                service, METHODID_REQUEST)))
        .addMethod(
          getStreamRequestMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.injective_rfq_rpc.StreamRequestRequest,
              com.injective_rfq_rpc.StreamRequestResponse>(
                service, METHODID_STREAM_REQUEST)))
        .addMethod(
          getQuoteMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_rfq_rpc.QuoteRequest,
              com.injective_rfq_rpc.QuoteResponse>(
                service, METHODID_QUOTE)))
        .addMethod(
          getStreamQuoteMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.injective_rfq_rpc.StreamQuoteRequest,
              com.injective_rfq_rpc.StreamQuoteResponse>(
                service, METHODID_STREAM_QUOTE)))
        .addMethod(
          getListSettlementMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_rfq_rpc.ListSettlementRequest,
              com.injective_rfq_rpc.ListSettlementResponse>(
                service, METHODID_LIST_SETTLEMENT)))
        .addMethod(
          getStreamSettlementMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.injective_rfq_rpc.StreamSettlementRequest,
              com.injective_rfq_rpc.StreamSettlementResponse>(
                service, METHODID_STREAM_SETTLEMENT)))
        .addMethod(
          getCreateConditionalOrderMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_rfq_rpc.CreateConditionalOrderRequest,
              com.injective_rfq_rpc.CreateConditionalOrderResponse>(
                service, METHODID_CREATE_CONDITIONAL_ORDER)))
        .addMethod(
          getListConditionalOrdersMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_rfq_rpc.ListConditionalOrdersRequest,
              com.injective_rfq_rpc.ListConditionalOrdersResponse>(
                service, METHODID_LIST_CONDITIONAL_ORDERS)))
        .addMethod(
          getTakerStreamMethod(),
          io.grpc.stub.ServerCalls.asyncBidiStreamingCall(
            new MethodHandlers<
              com.injective_rfq_rpc.TakerStreamStreamingRequest,
              com.injective_rfq_rpc.TakerStreamResponse>(
                service, METHODID_TAKER_STREAM)))
        .addMethod(
          getMakerStreamMethod(),
          io.grpc.stub.ServerCalls.asyncBidiStreamingCall(
            new MethodHandlers<
              com.injective_rfq_rpc.MakerStreamStreamingRequest,
              com.injective_rfq_rpc.MakerStreamResponse>(
                service, METHODID_MAKER_STREAM)))
        .build();
  }

  private static abstract class InjectiveRfqRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    InjectiveRfqRPCBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.injective_rfq_rpc.InjectiveRfqRpcProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("InjectiveRfqRPC");
    }
  }

  private static final class InjectiveRfqRPCFileDescriptorSupplier
      extends InjectiveRfqRPCBaseDescriptorSupplier {
    InjectiveRfqRPCFileDescriptorSupplier() {}
  }

  private static final class InjectiveRfqRPCMethodDescriptorSupplier
      extends InjectiveRfqRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    InjectiveRfqRPCMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (InjectiveRfqRPCGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new InjectiveRfqRPCFileDescriptorSupplier())
              .addMethod(getRequestMethod())
              .addMethod(getStreamRequestMethod())
              .addMethod(getQuoteMethod())
              .addMethod(getStreamQuoteMethod())
              .addMethod(getListSettlementMethod())
              .addMethod(getStreamSettlementMethod())
              .addMethod(getCreateConditionalOrderMethod())
              .addMethod(getListConditionalOrdersMethod())
              .addMethod(getTakerStreamMethod())
              .addMethod(getMakerStreamMethod())
              .build();
        }
      }
    }
    return result;
  }
}

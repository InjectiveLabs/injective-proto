package com.injective_auction_rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * InjectiveAuctionRPC defines gRPC API of the Auction API.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.65.1)",
    comments = "Source: exchange/injective_auction_rpc.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class InjectiveAuctionRPCGrpc {

  private InjectiveAuctionRPCGrpc() {}

  public static final java.lang.String SERVICE_NAME = "injective_auction_rpc.InjectiveAuctionRPC";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.injective_auction_rpc.AuctionEndpointRequest,
      com.injective_auction_rpc.AuctionEndpointResponse> getAuctionEndpointMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AuctionEndpoint",
      requestType = com.injective_auction_rpc.AuctionEndpointRequest.class,
      responseType = com.injective_auction_rpc.AuctionEndpointResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_auction_rpc.AuctionEndpointRequest,
      com.injective_auction_rpc.AuctionEndpointResponse> getAuctionEndpointMethod() {
    io.grpc.MethodDescriptor<com.injective_auction_rpc.AuctionEndpointRequest, com.injective_auction_rpc.AuctionEndpointResponse> getAuctionEndpointMethod;
    if ((getAuctionEndpointMethod = InjectiveAuctionRPCGrpc.getAuctionEndpointMethod) == null) {
      synchronized (InjectiveAuctionRPCGrpc.class) {
        if ((getAuctionEndpointMethod = InjectiveAuctionRPCGrpc.getAuctionEndpointMethod) == null) {
          InjectiveAuctionRPCGrpc.getAuctionEndpointMethod = getAuctionEndpointMethod =
              io.grpc.MethodDescriptor.<com.injective_auction_rpc.AuctionEndpointRequest, com.injective_auction_rpc.AuctionEndpointResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AuctionEndpoint"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_auction_rpc.AuctionEndpointRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_auction_rpc.AuctionEndpointResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveAuctionRPCMethodDescriptorSupplier("AuctionEndpoint"))
              .build();
        }
      }
    }
    return getAuctionEndpointMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_auction_rpc.AuctionsRequest,
      com.injective_auction_rpc.AuctionsResponse> getAuctionsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Auctions",
      requestType = com.injective_auction_rpc.AuctionsRequest.class,
      responseType = com.injective_auction_rpc.AuctionsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_auction_rpc.AuctionsRequest,
      com.injective_auction_rpc.AuctionsResponse> getAuctionsMethod() {
    io.grpc.MethodDescriptor<com.injective_auction_rpc.AuctionsRequest, com.injective_auction_rpc.AuctionsResponse> getAuctionsMethod;
    if ((getAuctionsMethod = InjectiveAuctionRPCGrpc.getAuctionsMethod) == null) {
      synchronized (InjectiveAuctionRPCGrpc.class) {
        if ((getAuctionsMethod = InjectiveAuctionRPCGrpc.getAuctionsMethod) == null) {
          InjectiveAuctionRPCGrpc.getAuctionsMethod = getAuctionsMethod =
              io.grpc.MethodDescriptor.<com.injective_auction_rpc.AuctionsRequest, com.injective_auction_rpc.AuctionsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Auctions"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_auction_rpc.AuctionsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_auction_rpc.AuctionsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveAuctionRPCMethodDescriptorSupplier("Auctions"))
              .build();
        }
      }
    }
    return getAuctionsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_auction_rpc.StreamBidsRequest,
      com.injective_auction_rpc.StreamBidsResponse> getStreamBidsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamBids",
      requestType = com.injective_auction_rpc.StreamBidsRequest.class,
      responseType = com.injective_auction_rpc.StreamBidsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.injective_auction_rpc.StreamBidsRequest,
      com.injective_auction_rpc.StreamBidsResponse> getStreamBidsMethod() {
    io.grpc.MethodDescriptor<com.injective_auction_rpc.StreamBidsRequest, com.injective_auction_rpc.StreamBidsResponse> getStreamBidsMethod;
    if ((getStreamBidsMethod = InjectiveAuctionRPCGrpc.getStreamBidsMethod) == null) {
      synchronized (InjectiveAuctionRPCGrpc.class) {
        if ((getStreamBidsMethod = InjectiveAuctionRPCGrpc.getStreamBidsMethod) == null) {
          InjectiveAuctionRPCGrpc.getStreamBidsMethod = getStreamBidsMethod =
              io.grpc.MethodDescriptor.<com.injective_auction_rpc.StreamBidsRequest, com.injective_auction_rpc.StreamBidsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StreamBids"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_auction_rpc.StreamBidsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_auction_rpc.StreamBidsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveAuctionRPCMethodDescriptorSupplier("StreamBids"))
              .build();
        }
      }
    }
    return getStreamBidsMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static InjectiveAuctionRPCStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveAuctionRPCStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveAuctionRPCStub>() {
        @java.lang.Override
        public InjectiveAuctionRPCStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveAuctionRPCStub(channel, callOptions);
        }
      };
    return InjectiveAuctionRPCStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static InjectiveAuctionRPCBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveAuctionRPCBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveAuctionRPCBlockingStub>() {
        @java.lang.Override
        public InjectiveAuctionRPCBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveAuctionRPCBlockingStub(channel, callOptions);
        }
      };
    return InjectiveAuctionRPCBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static InjectiveAuctionRPCFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveAuctionRPCFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveAuctionRPCFutureStub>() {
        @java.lang.Override
        public InjectiveAuctionRPCFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveAuctionRPCFutureStub(channel, callOptions);
        }
      };
    return InjectiveAuctionRPCFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * InjectiveAuctionRPC defines gRPC API of the Auction API.
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Provide historical auction info for a given auction
     * </pre>
     */
    default void auctionEndpoint(com.injective_auction_rpc.AuctionEndpointRequest request,
        io.grpc.stub.StreamObserver<com.injective_auction_rpc.AuctionEndpointResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAuctionEndpointMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide the historical auctions info
     * </pre>
     */
    default void auctions(com.injective_auction_rpc.AuctionsRequest request,
        io.grpc.stub.StreamObserver<com.injective_auction_rpc.AuctionsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAuctionsMethod(), responseObserver);
    }

    /**
     * <pre>
     * StreamBids streams new bids of an auction.
     * </pre>
     */
    default void streamBids(com.injective_auction_rpc.StreamBidsRequest request,
        io.grpc.stub.StreamObserver<com.injective_auction_rpc.StreamBidsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStreamBidsMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service InjectiveAuctionRPC.
   * <pre>
   * InjectiveAuctionRPC defines gRPC API of the Auction API.
   * </pre>
   */
  public static abstract class InjectiveAuctionRPCImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return InjectiveAuctionRPCGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service InjectiveAuctionRPC.
   * <pre>
   * InjectiveAuctionRPC defines gRPC API of the Auction API.
   * </pre>
   */
  public static final class InjectiveAuctionRPCStub
      extends io.grpc.stub.AbstractAsyncStub<InjectiveAuctionRPCStub> {
    private InjectiveAuctionRPCStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveAuctionRPCStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveAuctionRPCStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide historical auction info for a given auction
     * </pre>
     */
    public void auctionEndpoint(com.injective_auction_rpc.AuctionEndpointRequest request,
        io.grpc.stub.StreamObserver<com.injective_auction_rpc.AuctionEndpointResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAuctionEndpointMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide the historical auctions info
     * </pre>
     */
    public void auctions(com.injective_auction_rpc.AuctionsRequest request,
        io.grpc.stub.StreamObserver<com.injective_auction_rpc.AuctionsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAuctionsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * StreamBids streams new bids of an auction.
     * </pre>
     */
    public void streamBids(com.injective_auction_rpc.StreamBidsRequest request,
        io.grpc.stub.StreamObserver<com.injective_auction_rpc.StreamBidsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getStreamBidsMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service InjectiveAuctionRPC.
   * <pre>
   * InjectiveAuctionRPC defines gRPC API of the Auction API.
   * </pre>
   */
  public static final class InjectiveAuctionRPCBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<InjectiveAuctionRPCBlockingStub> {
    private InjectiveAuctionRPCBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveAuctionRPCBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveAuctionRPCBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide historical auction info for a given auction
     * </pre>
     */
    public com.injective_auction_rpc.AuctionEndpointResponse auctionEndpoint(com.injective_auction_rpc.AuctionEndpointRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAuctionEndpointMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide the historical auctions info
     * </pre>
     */
    public com.injective_auction_rpc.AuctionsResponse auctions(com.injective_auction_rpc.AuctionsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAuctionsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * StreamBids streams new bids of an auction.
     * </pre>
     */
    public java.util.Iterator<com.injective_auction_rpc.StreamBidsResponse> streamBids(
        com.injective_auction_rpc.StreamBidsRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getStreamBidsMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service InjectiveAuctionRPC.
   * <pre>
   * InjectiveAuctionRPC defines gRPC API of the Auction API.
   * </pre>
   */
  public static final class InjectiveAuctionRPCFutureStub
      extends io.grpc.stub.AbstractFutureStub<InjectiveAuctionRPCFutureStub> {
    private InjectiveAuctionRPCFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveAuctionRPCFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveAuctionRPCFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide historical auction info for a given auction
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_auction_rpc.AuctionEndpointResponse> auctionEndpoint(
        com.injective_auction_rpc.AuctionEndpointRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAuctionEndpointMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide the historical auctions info
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_auction_rpc.AuctionsResponse> auctions(
        com.injective_auction_rpc.AuctionsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAuctionsMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_AUCTION_ENDPOINT = 0;
  private static final int METHODID_AUCTIONS = 1;
  private static final int METHODID_STREAM_BIDS = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_AUCTION_ENDPOINT:
          serviceImpl.auctionEndpoint((com.injective_auction_rpc.AuctionEndpointRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_auction_rpc.AuctionEndpointResponse>) responseObserver);
          break;
        case METHODID_AUCTIONS:
          serviceImpl.auctions((com.injective_auction_rpc.AuctionsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_auction_rpc.AuctionsResponse>) responseObserver);
          break;
        case METHODID_STREAM_BIDS:
          serviceImpl.streamBids((com.injective_auction_rpc.StreamBidsRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_auction_rpc.StreamBidsResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getAuctionEndpointMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_auction_rpc.AuctionEndpointRequest,
              com.injective_auction_rpc.AuctionEndpointResponse>(
                service, METHODID_AUCTION_ENDPOINT)))
        .addMethod(
          getAuctionsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_auction_rpc.AuctionsRequest,
              com.injective_auction_rpc.AuctionsResponse>(
                service, METHODID_AUCTIONS)))
        .addMethod(
          getStreamBidsMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.injective_auction_rpc.StreamBidsRequest,
              com.injective_auction_rpc.StreamBidsResponse>(
                service, METHODID_STREAM_BIDS)))
        .build();
  }

  private static abstract class InjectiveAuctionRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    InjectiveAuctionRPCBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.injective_auction_rpc.InjectiveAuctionRpcProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("InjectiveAuctionRPC");
    }
  }

  private static final class InjectiveAuctionRPCFileDescriptorSupplier
      extends InjectiveAuctionRPCBaseDescriptorSupplier {
    InjectiveAuctionRPCFileDescriptorSupplier() {}
  }

  private static final class InjectiveAuctionRPCMethodDescriptorSupplier
      extends InjectiveAuctionRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    InjectiveAuctionRPCMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (InjectiveAuctionRPCGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new InjectiveAuctionRPCFileDescriptorSupplier())
              .addMethod(getAuctionEndpointMethod())
              .addMethod(getAuctionsMethod())
              .addMethod(getStreamBidsMethod())
              .build();
        }
      }
    }
    return result;
  }
}

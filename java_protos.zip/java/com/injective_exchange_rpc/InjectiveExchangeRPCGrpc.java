package com.injective_exchange_rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * InjectiveExchangeRPC defines gRPC API of an Injective Exchange service.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.73.0)",
    comments = "Source: exchange/injective_exchange_rpc.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class InjectiveExchangeRPCGrpc {

  private InjectiveExchangeRPCGrpc() {}

  public static final java.lang.String SERVICE_NAME = "injective_exchange_rpc.InjectiveExchangeRPC";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.injective_exchange_rpc.GetTxRequest,
      com.injective_exchange_rpc.GetTxResponse> getGetTxMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetTx",
      requestType = com.injective_exchange_rpc.GetTxRequest.class,
      responseType = com.injective_exchange_rpc.GetTxResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_exchange_rpc.GetTxRequest,
      com.injective_exchange_rpc.GetTxResponse> getGetTxMethod() {
    io.grpc.MethodDescriptor<com.injective_exchange_rpc.GetTxRequest, com.injective_exchange_rpc.GetTxResponse> getGetTxMethod;
    if ((getGetTxMethod = InjectiveExchangeRPCGrpc.getGetTxMethod) == null) {
      synchronized (InjectiveExchangeRPCGrpc.class) {
        if ((getGetTxMethod = InjectiveExchangeRPCGrpc.getGetTxMethod) == null) {
          InjectiveExchangeRPCGrpc.getGetTxMethod = getGetTxMethod =
              io.grpc.MethodDescriptor.<com.injective_exchange_rpc.GetTxRequest, com.injective_exchange_rpc.GetTxResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetTx"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.GetTxRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.GetTxResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExchangeRPCMethodDescriptorSupplier("GetTx"))
              .build();
        }
      }
    }
    return getGetTxMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_exchange_rpc.PrepareTxRequest,
      com.injective_exchange_rpc.PrepareTxResponse> getPrepareTxMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PrepareTx",
      requestType = com.injective_exchange_rpc.PrepareTxRequest.class,
      responseType = com.injective_exchange_rpc.PrepareTxResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_exchange_rpc.PrepareTxRequest,
      com.injective_exchange_rpc.PrepareTxResponse> getPrepareTxMethod() {
    io.grpc.MethodDescriptor<com.injective_exchange_rpc.PrepareTxRequest, com.injective_exchange_rpc.PrepareTxResponse> getPrepareTxMethod;
    if ((getPrepareTxMethod = InjectiveExchangeRPCGrpc.getPrepareTxMethod) == null) {
      synchronized (InjectiveExchangeRPCGrpc.class) {
        if ((getPrepareTxMethod = InjectiveExchangeRPCGrpc.getPrepareTxMethod) == null) {
          InjectiveExchangeRPCGrpc.getPrepareTxMethod = getPrepareTxMethod =
              io.grpc.MethodDescriptor.<com.injective_exchange_rpc.PrepareTxRequest, com.injective_exchange_rpc.PrepareTxResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "PrepareTx"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.PrepareTxRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.PrepareTxResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExchangeRPCMethodDescriptorSupplier("PrepareTx"))
              .build();
        }
      }
    }
    return getPrepareTxMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_exchange_rpc.PrepareEip712Request,
      com.injective_exchange_rpc.PrepareEip712Response> getPrepareEip712Method;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PrepareEip712",
      requestType = com.injective_exchange_rpc.PrepareEip712Request.class,
      responseType = com.injective_exchange_rpc.PrepareEip712Response.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_exchange_rpc.PrepareEip712Request,
      com.injective_exchange_rpc.PrepareEip712Response> getPrepareEip712Method() {
    io.grpc.MethodDescriptor<com.injective_exchange_rpc.PrepareEip712Request, com.injective_exchange_rpc.PrepareEip712Response> getPrepareEip712Method;
    if ((getPrepareEip712Method = InjectiveExchangeRPCGrpc.getPrepareEip712Method) == null) {
      synchronized (InjectiveExchangeRPCGrpc.class) {
        if ((getPrepareEip712Method = InjectiveExchangeRPCGrpc.getPrepareEip712Method) == null) {
          InjectiveExchangeRPCGrpc.getPrepareEip712Method = getPrepareEip712Method =
              io.grpc.MethodDescriptor.<com.injective_exchange_rpc.PrepareEip712Request, com.injective_exchange_rpc.PrepareEip712Response>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "PrepareEip712"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.PrepareEip712Request.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.PrepareEip712Response.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExchangeRPCMethodDescriptorSupplier("PrepareEip712"))
              .build();
        }
      }
    }
    return getPrepareEip712Method;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_exchange_rpc.BroadcastTxRequest,
      com.injective_exchange_rpc.BroadcastTxResponse> getBroadcastTxMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "BroadcastTx",
      requestType = com.injective_exchange_rpc.BroadcastTxRequest.class,
      responseType = com.injective_exchange_rpc.BroadcastTxResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_exchange_rpc.BroadcastTxRequest,
      com.injective_exchange_rpc.BroadcastTxResponse> getBroadcastTxMethod() {
    io.grpc.MethodDescriptor<com.injective_exchange_rpc.BroadcastTxRequest, com.injective_exchange_rpc.BroadcastTxResponse> getBroadcastTxMethod;
    if ((getBroadcastTxMethod = InjectiveExchangeRPCGrpc.getBroadcastTxMethod) == null) {
      synchronized (InjectiveExchangeRPCGrpc.class) {
        if ((getBroadcastTxMethod = InjectiveExchangeRPCGrpc.getBroadcastTxMethod) == null) {
          InjectiveExchangeRPCGrpc.getBroadcastTxMethod = getBroadcastTxMethod =
              io.grpc.MethodDescriptor.<com.injective_exchange_rpc.BroadcastTxRequest, com.injective_exchange_rpc.BroadcastTxResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "BroadcastTx"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.BroadcastTxRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.BroadcastTxResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExchangeRPCMethodDescriptorSupplier("BroadcastTx"))
              .build();
        }
      }
    }
    return getBroadcastTxMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_exchange_rpc.PrepareCosmosTxRequest,
      com.injective_exchange_rpc.PrepareCosmosTxResponse> getPrepareCosmosTxMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PrepareCosmosTx",
      requestType = com.injective_exchange_rpc.PrepareCosmosTxRequest.class,
      responseType = com.injective_exchange_rpc.PrepareCosmosTxResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_exchange_rpc.PrepareCosmosTxRequest,
      com.injective_exchange_rpc.PrepareCosmosTxResponse> getPrepareCosmosTxMethod() {
    io.grpc.MethodDescriptor<com.injective_exchange_rpc.PrepareCosmosTxRequest, com.injective_exchange_rpc.PrepareCosmosTxResponse> getPrepareCosmosTxMethod;
    if ((getPrepareCosmosTxMethod = InjectiveExchangeRPCGrpc.getPrepareCosmosTxMethod) == null) {
      synchronized (InjectiveExchangeRPCGrpc.class) {
        if ((getPrepareCosmosTxMethod = InjectiveExchangeRPCGrpc.getPrepareCosmosTxMethod) == null) {
          InjectiveExchangeRPCGrpc.getPrepareCosmosTxMethod = getPrepareCosmosTxMethod =
              io.grpc.MethodDescriptor.<com.injective_exchange_rpc.PrepareCosmosTxRequest, com.injective_exchange_rpc.PrepareCosmosTxResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "PrepareCosmosTx"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.PrepareCosmosTxRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.PrepareCosmosTxResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExchangeRPCMethodDescriptorSupplier("PrepareCosmosTx"))
              .build();
        }
      }
    }
    return getPrepareCosmosTxMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_exchange_rpc.BroadcastCosmosTxRequest,
      com.injective_exchange_rpc.BroadcastCosmosTxResponse> getBroadcastCosmosTxMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "BroadcastCosmosTx",
      requestType = com.injective_exchange_rpc.BroadcastCosmosTxRequest.class,
      responseType = com.injective_exchange_rpc.BroadcastCosmosTxResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_exchange_rpc.BroadcastCosmosTxRequest,
      com.injective_exchange_rpc.BroadcastCosmosTxResponse> getBroadcastCosmosTxMethod() {
    io.grpc.MethodDescriptor<com.injective_exchange_rpc.BroadcastCosmosTxRequest, com.injective_exchange_rpc.BroadcastCosmosTxResponse> getBroadcastCosmosTxMethod;
    if ((getBroadcastCosmosTxMethod = InjectiveExchangeRPCGrpc.getBroadcastCosmosTxMethod) == null) {
      synchronized (InjectiveExchangeRPCGrpc.class) {
        if ((getBroadcastCosmosTxMethod = InjectiveExchangeRPCGrpc.getBroadcastCosmosTxMethod) == null) {
          InjectiveExchangeRPCGrpc.getBroadcastCosmosTxMethod = getBroadcastCosmosTxMethod =
              io.grpc.MethodDescriptor.<com.injective_exchange_rpc.BroadcastCosmosTxRequest, com.injective_exchange_rpc.BroadcastCosmosTxResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "BroadcastCosmosTx"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.BroadcastCosmosTxRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.BroadcastCosmosTxResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExchangeRPCMethodDescriptorSupplier("BroadcastCosmosTx"))
              .build();
        }
      }
    }
    return getBroadcastCosmosTxMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_exchange_rpc.GetFeePayerRequest,
      com.injective_exchange_rpc.GetFeePayerResponse> getGetFeePayerMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetFeePayer",
      requestType = com.injective_exchange_rpc.GetFeePayerRequest.class,
      responseType = com.injective_exchange_rpc.GetFeePayerResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_exchange_rpc.GetFeePayerRequest,
      com.injective_exchange_rpc.GetFeePayerResponse> getGetFeePayerMethod() {
    io.grpc.MethodDescriptor<com.injective_exchange_rpc.GetFeePayerRequest, com.injective_exchange_rpc.GetFeePayerResponse> getGetFeePayerMethod;
    if ((getGetFeePayerMethod = InjectiveExchangeRPCGrpc.getGetFeePayerMethod) == null) {
      synchronized (InjectiveExchangeRPCGrpc.class) {
        if ((getGetFeePayerMethod = InjectiveExchangeRPCGrpc.getGetFeePayerMethod) == null) {
          InjectiveExchangeRPCGrpc.getGetFeePayerMethod = getGetFeePayerMethod =
              io.grpc.MethodDescriptor.<com.injective_exchange_rpc.GetFeePayerRequest, com.injective_exchange_rpc.GetFeePayerResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetFeePayer"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.GetFeePayerRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_exchange_rpc.GetFeePayerResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveExchangeRPCMethodDescriptorSupplier("GetFeePayer"))
              .build();
        }
      }
    }
    return getGetFeePayerMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static InjectiveExchangeRPCStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveExchangeRPCStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveExchangeRPCStub>() {
        @java.lang.Override
        public InjectiveExchangeRPCStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveExchangeRPCStub(channel, callOptions);
        }
      };
    return InjectiveExchangeRPCStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static InjectiveExchangeRPCBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveExchangeRPCBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveExchangeRPCBlockingV2Stub>() {
        @java.lang.Override
        public InjectiveExchangeRPCBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveExchangeRPCBlockingV2Stub(channel, callOptions);
        }
      };
    return InjectiveExchangeRPCBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static InjectiveExchangeRPCBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveExchangeRPCBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveExchangeRPCBlockingStub>() {
        @java.lang.Override
        public InjectiveExchangeRPCBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveExchangeRPCBlockingStub(channel, callOptions);
        }
      };
    return InjectiveExchangeRPCBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static InjectiveExchangeRPCFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveExchangeRPCFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveExchangeRPCFutureStub>() {
        @java.lang.Override
        public InjectiveExchangeRPCFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveExchangeRPCFutureStub(channel, callOptions);
        }
      };
    return InjectiveExchangeRPCFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * InjectiveExchangeRPC defines gRPC API of an Injective Exchange service.
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * GetTx gets transaction details by hash.
     * </pre>
     */
    default void getTx(com.injective_exchange_rpc.GetTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.GetTxResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetTxMethod(), responseObserver);
    }

    /**
     * <pre>
     * PrepareTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    default void prepareTx(com.injective_exchange_rpc.PrepareTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.PrepareTxResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPrepareTxMethod(), responseObserver);
    }

    /**
     * <pre>
     * prepareEip712 generates EIP712 for an Injective Message
     * </pre>
     */
    default void prepareEip712(com.injective_exchange_rpc.PrepareEip712Request request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.PrepareEip712Response> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPrepareEip712Method(), responseObserver);
    }

    /**
     * <pre>
     * BroadcastTx broadcasts a signed Web3 transaction
     * </pre>
     */
    default void broadcastTx(com.injective_exchange_rpc.BroadcastTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.BroadcastTxResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBroadcastTxMethod(), responseObserver);
    }

    /**
     * <pre>
     * PrepareCosmosTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    default void prepareCosmosTx(com.injective_exchange_rpc.PrepareCosmosTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.PrepareCosmosTxResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPrepareCosmosTxMethod(), responseObserver);
    }

    /**
     * <pre>
     * BroadcastCosmosTx broadcasts a signed Web3 transaction
     * </pre>
     */
    default void broadcastCosmosTx(com.injective_exchange_rpc.BroadcastCosmosTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.BroadcastCosmosTxResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBroadcastCosmosTxMethod(), responseObserver);
    }

    /**
     * <pre>
     * Return fee payer information's
     * </pre>
     */
    default void getFeePayer(com.injective_exchange_rpc.GetFeePayerRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.GetFeePayerResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetFeePayerMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service InjectiveExchangeRPC.
   * <pre>
   * InjectiveExchangeRPC defines gRPC API of an Injective Exchange service.
   * </pre>
   */
  public static abstract class InjectiveExchangeRPCImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return InjectiveExchangeRPCGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service InjectiveExchangeRPC.
   * <pre>
   * InjectiveExchangeRPC defines gRPC API of an Injective Exchange service.
   * </pre>
   */
  public static final class InjectiveExchangeRPCStub
      extends io.grpc.stub.AbstractAsyncStub<InjectiveExchangeRPCStub> {
    private InjectiveExchangeRPCStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveExchangeRPCStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveExchangeRPCStub(channel, callOptions);
    }

    /**
     * <pre>
     * GetTx gets transaction details by hash.
     * </pre>
     */
    public void getTx(com.injective_exchange_rpc.GetTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.GetTxResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetTxMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * PrepareTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    public void prepareTx(com.injective_exchange_rpc.PrepareTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.PrepareTxResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPrepareTxMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * prepareEip712 generates EIP712 for an Injective Message
     * </pre>
     */
    public void prepareEip712(com.injective_exchange_rpc.PrepareEip712Request request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.PrepareEip712Response> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPrepareEip712Method(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * BroadcastTx broadcasts a signed Web3 transaction
     * </pre>
     */
    public void broadcastTx(com.injective_exchange_rpc.BroadcastTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.BroadcastTxResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getBroadcastTxMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * PrepareCosmosTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    public void prepareCosmosTx(com.injective_exchange_rpc.PrepareCosmosTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.PrepareCosmosTxResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPrepareCosmosTxMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * BroadcastCosmosTx broadcasts a signed Web3 transaction
     * </pre>
     */
    public void broadcastCosmosTx(com.injective_exchange_rpc.BroadcastCosmosTxRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.BroadcastCosmosTxResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getBroadcastCosmosTxMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Return fee payer information's
     * </pre>
     */
    public void getFeePayer(com.injective_exchange_rpc.GetFeePayerRequest request,
        io.grpc.stub.StreamObserver<com.injective_exchange_rpc.GetFeePayerResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetFeePayerMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service InjectiveExchangeRPC.
   * <pre>
   * InjectiveExchangeRPC defines gRPC API of an Injective Exchange service.
   * </pre>
   */
  public static final class InjectiveExchangeRPCBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<InjectiveExchangeRPCBlockingV2Stub> {
    private InjectiveExchangeRPCBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveExchangeRPCBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveExchangeRPCBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * GetTx gets transaction details by hash.
     * </pre>
     */
    public com.injective_exchange_rpc.GetTxResponse getTx(com.injective_exchange_rpc.GetTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * PrepareTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    public com.injective_exchange_rpc.PrepareTxResponse prepareTx(com.injective_exchange_rpc.PrepareTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPrepareTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * prepareEip712 generates EIP712 for an Injective Message
     * </pre>
     */
    public com.injective_exchange_rpc.PrepareEip712Response prepareEip712(com.injective_exchange_rpc.PrepareEip712Request request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPrepareEip712Method(), getCallOptions(), request);
    }

    /**
     * <pre>
     * BroadcastTx broadcasts a signed Web3 transaction
     * </pre>
     */
    public com.injective_exchange_rpc.BroadcastTxResponse broadcastTx(com.injective_exchange_rpc.BroadcastTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBroadcastTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * PrepareCosmosTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    public com.injective_exchange_rpc.PrepareCosmosTxResponse prepareCosmosTx(com.injective_exchange_rpc.PrepareCosmosTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPrepareCosmosTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * BroadcastCosmosTx broadcasts a signed Web3 transaction
     * </pre>
     */
    public com.injective_exchange_rpc.BroadcastCosmosTxResponse broadcastCosmosTx(com.injective_exchange_rpc.BroadcastCosmosTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBroadcastCosmosTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Return fee payer information's
     * </pre>
     */
    public com.injective_exchange_rpc.GetFeePayerResponse getFeePayer(com.injective_exchange_rpc.GetFeePayerRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetFeePayerMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service InjectiveExchangeRPC.
   * <pre>
   * InjectiveExchangeRPC defines gRPC API of an Injective Exchange service.
   * </pre>
   */
  public static final class InjectiveExchangeRPCBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<InjectiveExchangeRPCBlockingStub> {
    private InjectiveExchangeRPCBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveExchangeRPCBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveExchangeRPCBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * GetTx gets transaction details by hash.
     * </pre>
     */
    public com.injective_exchange_rpc.GetTxResponse getTx(com.injective_exchange_rpc.GetTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * PrepareTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    public com.injective_exchange_rpc.PrepareTxResponse prepareTx(com.injective_exchange_rpc.PrepareTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPrepareTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * prepareEip712 generates EIP712 for an Injective Message
     * </pre>
     */
    public com.injective_exchange_rpc.PrepareEip712Response prepareEip712(com.injective_exchange_rpc.PrepareEip712Request request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPrepareEip712Method(), getCallOptions(), request);
    }

    /**
     * <pre>
     * BroadcastTx broadcasts a signed Web3 transaction
     * </pre>
     */
    public com.injective_exchange_rpc.BroadcastTxResponse broadcastTx(com.injective_exchange_rpc.BroadcastTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBroadcastTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * PrepareCosmosTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    public com.injective_exchange_rpc.PrepareCosmosTxResponse prepareCosmosTx(com.injective_exchange_rpc.PrepareCosmosTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPrepareCosmosTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * BroadcastCosmosTx broadcasts a signed Web3 transaction
     * </pre>
     */
    public com.injective_exchange_rpc.BroadcastCosmosTxResponse broadcastCosmosTx(com.injective_exchange_rpc.BroadcastCosmosTxRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBroadcastCosmosTxMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Return fee payer information's
     * </pre>
     */
    public com.injective_exchange_rpc.GetFeePayerResponse getFeePayer(com.injective_exchange_rpc.GetFeePayerRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetFeePayerMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service InjectiveExchangeRPC.
   * <pre>
   * InjectiveExchangeRPC defines gRPC API of an Injective Exchange service.
   * </pre>
   */
  public static final class InjectiveExchangeRPCFutureStub
      extends io.grpc.stub.AbstractFutureStub<InjectiveExchangeRPCFutureStub> {
    private InjectiveExchangeRPCFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveExchangeRPCFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveExchangeRPCFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * GetTx gets transaction details by hash.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_exchange_rpc.GetTxResponse> getTx(
        com.injective_exchange_rpc.GetTxRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetTxMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * PrepareTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_exchange_rpc.PrepareTxResponse> prepareTx(
        com.injective_exchange_rpc.PrepareTxRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPrepareTxMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * prepareEip712 generates EIP712 for an Injective Message
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_exchange_rpc.PrepareEip712Response> prepareEip712(
        com.injective_exchange_rpc.PrepareEip712Request request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPrepareEip712Method(), getCallOptions()), request);
    }

    /**
     * <pre>
     * BroadcastTx broadcasts a signed Web3 transaction
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_exchange_rpc.BroadcastTxResponse> broadcastTx(
        com.injective_exchange_rpc.BroadcastTxRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getBroadcastTxMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * PrepareCosmosTx generates a Web3-signable body for a Cosmos transaction
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_exchange_rpc.PrepareCosmosTxResponse> prepareCosmosTx(
        com.injective_exchange_rpc.PrepareCosmosTxRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPrepareCosmosTxMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * BroadcastCosmosTx broadcasts a signed Web3 transaction
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_exchange_rpc.BroadcastCosmosTxResponse> broadcastCosmosTx(
        com.injective_exchange_rpc.BroadcastCosmosTxRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getBroadcastCosmosTxMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Return fee payer information's
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_exchange_rpc.GetFeePayerResponse> getFeePayer(
        com.injective_exchange_rpc.GetFeePayerRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetFeePayerMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_TX = 0;
  private static final int METHODID_PREPARE_TX = 1;
  private static final int METHODID_PREPARE_EIP712 = 2;
  private static final int METHODID_BROADCAST_TX = 3;
  private static final int METHODID_PREPARE_COSMOS_TX = 4;
  private static final int METHODID_BROADCAST_COSMOS_TX = 5;
  private static final int METHODID_GET_FEE_PAYER = 6;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_TX:
          serviceImpl.getTx((com.injective_exchange_rpc.GetTxRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_exchange_rpc.GetTxResponse>) responseObserver);
          break;
        case METHODID_PREPARE_TX:
          serviceImpl.prepareTx((com.injective_exchange_rpc.PrepareTxRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_exchange_rpc.PrepareTxResponse>) responseObserver);
          break;
        case METHODID_PREPARE_EIP712:
          serviceImpl.prepareEip712((com.injective_exchange_rpc.PrepareEip712Request) request,
              (io.grpc.stub.StreamObserver<com.injective_exchange_rpc.PrepareEip712Response>) responseObserver);
          break;
        case METHODID_BROADCAST_TX:
          serviceImpl.broadcastTx((com.injective_exchange_rpc.BroadcastTxRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_exchange_rpc.BroadcastTxResponse>) responseObserver);
          break;
        case METHODID_PREPARE_COSMOS_TX:
          serviceImpl.prepareCosmosTx((com.injective_exchange_rpc.PrepareCosmosTxRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_exchange_rpc.PrepareCosmosTxResponse>) responseObserver);
          break;
        case METHODID_BROADCAST_COSMOS_TX:
          serviceImpl.broadcastCosmosTx((com.injective_exchange_rpc.BroadcastCosmosTxRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_exchange_rpc.BroadcastCosmosTxResponse>) responseObserver);
          break;
        case METHODID_GET_FEE_PAYER:
          serviceImpl.getFeePayer((com.injective_exchange_rpc.GetFeePayerRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_exchange_rpc.GetFeePayerResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getGetTxMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_exchange_rpc.GetTxRequest,
              com.injective_exchange_rpc.GetTxResponse>(
                service, METHODID_GET_TX)))
        .addMethod(
          getPrepareTxMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_exchange_rpc.PrepareTxRequest,
              com.injective_exchange_rpc.PrepareTxResponse>(
                service, METHODID_PREPARE_TX)))
        .addMethod(
          getPrepareEip712Method(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_exchange_rpc.PrepareEip712Request,
              com.injective_exchange_rpc.PrepareEip712Response>(
                service, METHODID_PREPARE_EIP712)))
        .addMethod(
          getBroadcastTxMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_exchange_rpc.BroadcastTxRequest,
              com.injective_exchange_rpc.BroadcastTxResponse>(
                service, METHODID_BROADCAST_TX)))
        .addMethod(
          getPrepareCosmosTxMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_exchange_rpc.PrepareCosmosTxRequest,
              com.injective_exchange_rpc.PrepareCosmosTxResponse>(
                service, METHODID_PREPARE_COSMOS_TX)))
        .addMethod(
          getBroadcastCosmosTxMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_exchange_rpc.BroadcastCosmosTxRequest,
              com.injective_exchange_rpc.BroadcastCosmosTxResponse>(
                service, METHODID_BROADCAST_COSMOS_TX)))
        .addMethod(
          getGetFeePayerMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_exchange_rpc.GetFeePayerRequest,
              com.injective_exchange_rpc.GetFeePayerResponse>(
                service, METHODID_GET_FEE_PAYER)))
        .build();
  }

  private static abstract class InjectiveExchangeRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    InjectiveExchangeRPCBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.injective_exchange_rpc.InjectiveExchangeRpcProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("InjectiveExchangeRPC");
    }
  }

  private static final class InjectiveExchangeRPCFileDescriptorSupplier
      extends InjectiveExchangeRPCBaseDescriptorSupplier {
    InjectiveExchangeRPCFileDescriptorSupplier() {}
  }

  private static final class InjectiveExchangeRPCMethodDescriptorSupplier
      extends InjectiveExchangeRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    InjectiveExchangeRPCMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (InjectiveExchangeRPCGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new InjectiveExchangeRPCFileDescriptorSupplier())
              .addMethod(getGetTxMethod())
              .addMethod(getPrepareTxMethod())
              .addMethod(getPrepareEip712Method())
              .addMethod(getBroadcastTxMethod())
              .addMethod(getPrepareCosmosTxMethod())
              .addMethod(getBroadcastCosmosTxMethod())
              .addMethod(getGetFeePayerMethod())
              .build();
        }
      }
    }
    return result;
  }
}

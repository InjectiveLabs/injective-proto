package com.cosmwasm.wasm.v1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Msg defines the wasm Msg service.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.71.0)",
    comments = "Source: cosmwasm/wasm/v1/tx.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class MsgGrpc {

  private MsgGrpc() {}

  public static final java.lang.String SERVICE_NAME = "cosmwasm.wasm.v1.Msg";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgStoreCode,
      com.cosmwasm.wasm.v1.MsgStoreCodeResponse> getStoreCodeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StoreCode",
      requestType = com.cosmwasm.wasm.v1.MsgStoreCode.class,
      responseType = com.cosmwasm.wasm.v1.MsgStoreCodeResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgStoreCode,
      com.cosmwasm.wasm.v1.MsgStoreCodeResponse> getStoreCodeMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgStoreCode, com.cosmwasm.wasm.v1.MsgStoreCodeResponse> getStoreCodeMethod;
    if ((getStoreCodeMethod = MsgGrpc.getStoreCodeMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getStoreCodeMethod = MsgGrpc.getStoreCodeMethod) == null) {
          MsgGrpc.getStoreCodeMethod = getStoreCodeMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgStoreCode, com.cosmwasm.wasm.v1.MsgStoreCodeResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StoreCode"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgStoreCode.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgStoreCodeResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("StoreCode"))
              .build();
        }
      }
    }
    return getStoreCodeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgInstantiateContract,
      com.cosmwasm.wasm.v1.MsgInstantiateContractResponse> getInstantiateContractMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "InstantiateContract",
      requestType = com.cosmwasm.wasm.v1.MsgInstantiateContract.class,
      responseType = com.cosmwasm.wasm.v1.MsgInstantiateContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgInstantiateContract,
      com.cosmwasm.wasm.v1.MsgInstantiateContractResponse> getInstantiateContractMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgInstantiateContract, com.cosmwasm.wasm.v1.MsgInstantiateContractResponse> getInstantiateContractMethod;
    if ((getInstantiateContractMethod = MsgGrpc.getInstantiateContractMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getInstantiateContractMethod = MsgGrpc.getInstantiateContractMethod) == null) {
          MsgGrpc.getInstantiateContractMethod = getInstantiateContractMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgInstantiateContract, com.cosmwasm.wasm.v1.MsgInstantiateContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "InstantiateContract"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgInstantiateContract.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgInstantiateContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("InstantiateContract"))
              .build();
        }
      }
    }
    return getInstantiateContractMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgInstantiateContract2,
      com.cosmwasm.wasm.v1.MsgInstantiateContract2Response> getInstantiateContract2Method;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "InstantiateContract2",
      requestType = com.cosmwasm.wasm.v1.MsgInstantiateContract2.class,
      responseType = com.cosmwasm.wasm.v1.MsgInstantiateContract2Response.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgInstantiateContract2,
      com.cosmwasm.wasm.v1.MsgInstantiateContract2Response> getInstantiateContract2Method() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgInstantiateContract2, com.cosmwasm.wasm.v1.MsgInstantiateContract2Response> getInstantiateContract2Method;
    if ((getInstantiateContract2Method = MsgGrpc.getInstantiateContract2Method) == null) {
      synchronized (MsgGrpc.class) {
        if ((getInstantiateContract2Method = MsgGrpc.getInstantiateContract2Method) == null) {
          MsgGrpc.getInstantiateContract2Method = getInstantiateContract2Method =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgInstantiateContract2, com.cosmwasm.wasm.v1.MsgInstantiateContract2Response>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "InstantiateContract2"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgInstantiateContract2.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgInstantiateContract2Response.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("InstantiateContract2"))
              .build();
        }
      }
    }
    return getInstantiateContract2Method;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgExecuteContract,
      com.cosmwasm.wasm.v1.MsgExecuteContractResponse> getExecuteContractMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ExecuteContract",
      requestType = com.cosmwasm.wasm.v1.MsgExecuteContract.class,
      responseType = com.cosmwasm.wasm.v1.MsgExecuteContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgExecuteContract,
      com.cosmwasm.wasm.v1.MsgExecuteContractResponse> getExecuteContractMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgExecuteContract, com.cosmwasm.wasm.v1.MsgExecuteContractResponse> getExecuteContractMethod;
    if ((getExecuteContractMethod = MsgGrpc.getExecuteContractMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getExecuteContractMethod = MsgGrpc.getExecuteContractMethod) == null) {
          MsgGrpc.getExecuteContractMethod = getExecuteContractMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgExecuteContract, com.cosmwasm.wasm.v1.MsgExecuteContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ExecuteContract"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgExecuteContract.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgExecuteContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("ExecuteContract"))
              .build();
        }
      }
    }
    return getExecuteContractMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgMigrateContract,
      com.cosmwasm.wasm.v1.MsgMigrateContractResponse> getMigrateContractMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "MigrateContract",
      requestType = com.cosmwasm.wasm.v1.MsgMigrateContract.class,
      responseType = com.cosmwasm.wasm.v1.MsgMigrateContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgMigrateContract,
      com.cosmwasm.wasm.v1.MsgMigrateContractResponse> getMigrateContractMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgMigrateContract, com.cosmwasm.wasm.v1.MsgMigrateContractResponse> getMigrateContractMethod;
    if ((getMigrateContractMethod = MsgGrpc.getMigrateContractMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getMigrateContractMethod = MsgGrpc.getMigrateContractMethod) == null) {
          MsgGrpc.getMigrateContractMethod = getMigrateContractMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgMigrateContract, com.cosmwasm.wasm.v1.MsgMigrateContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "MigrateContract"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgMigrateContract.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgMigrateContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("MigrateContract"))
              .build();
        }
      }
    }
    return getMigrateContractMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateAdmin,
      com.cosmwasm.wasm.v1.MsgUpdateAdminResponse> getUpdateAdminMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateAdmin",
      requestType = com.cosmwasm.wasm.v1.MsgUpdateAdmin.class,
      responseType = com.cosmwasm.wasm.v1.MsgUpdateAdminResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateAdmin,
      com.cosmwasm.wasm.v1.MsgUpdateAdminResponse> getUpdateAdminMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateAdmin, com.cosmwasm.wasm.v1.MsgUpdateAdminResponse> getUpdateAdminMethod;
    if ((getUpdateAdminMethod = MsgGrpc.getUpdateAdminMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getUpdateAdminMethod = MsgGrpc.getUpdateAdminMethod) == null) {
          MsgGrpc.getUpdateAdminMethod = getUpdateAdminMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgUpdateAdmin, com.cosmwasm.wasm.v1.MsgUpdateAdminResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateAdmin"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUpdateAdmin.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUpdateAdminResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("UpdateAdmin"))
              .build();
        }
      }
    }
    return getUpdateAdminMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgClearAdmin,
      com.cosmwasm.wasm.v1.MsgClearAdminResponse> getClearAdminMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ClearAdmin",
      requestType = com.cosmwasm.wasm.v1.MsgClearAdmin.class,
      responseType = com.cosmwasm.wasm.v1.MsgClearAdminResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgClearAdmin,
      com.cosmwasm.wasm.v1.MsgClearAdminResponse> getClearAdminMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgClearAdmin, com.cosmwasm.wasm.v1.MsgClearAdminResponse> getClearAdminMethod;
    if ((getClearAdminMethod = MsgGrpc.getClearAdminMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getClearAdminMethod = MsgGrpc.getClearAdminMethod) == null) {
          MsgGrpc.getClearAdminMethod = getClearAdminMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgClearAdmin, com.cosmwasm.wasm.v1.MsgClearAdminResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ClearAdmin"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgClearAdmin.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgClearAdminResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("ClearAdmin"))
              .build();
        }
      }
    }
    return getClearAdminMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig,
      com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse> getUpdateInstantiateConfigMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateInstantiateConfig",
      requestType = com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig.class,
      responseType = com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig,
      com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse> getUpdateInstantiateConfigMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig, com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse> getUpdateInstantiateConfigMethod;
    if ((getUpdateInstantiateConfigMethod = MsgGrpc.getUpdateInstantiateConfigMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getUpdateInstantiateConfigMethod = MsgGrpc.getUpdateInstantiateConfigMethod) == null) {
          MsgGrpc.getUpdateInstantiateConfigMethod = getUpdateInstantiateConfigMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig, com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateInstantiateConfig"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("UpdateInstantiateConfig"))
              .build();
        }
      }
    }
    return getUpdateInstantiateConfigMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateParams,
      com.cosmwasm.wasm.v1.MsgUpdateParamsResponse> getUpdateParamsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateParams",
      requestType = com.cosmwasm.wasm.v1.MsgUpdateParams.class,
      responseType = com.cosmwasm.wasm.v1.MsgUpdateParamsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateParams,
      com.cosmwasm.wasm.v1.MsgUpdateParamsResponse> getUpdateParamsMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateParams, com.cosmwasm.wasm.v1.MsgUpdateParamsResponse> getUpdateParamsMethod;
    if ((getUpdateParamsMethod = MsgGrpc.getUpdateParamsMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getUpdateParamsMethod = MsgGrpc.getUpdateParamsMethod) == null) {
          MsgGrpc.getUpdateParamsMethod = getUpdateParamsMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgUpdateParams, com.cosmwasm.wasm.v1.MsgUpdateParamsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateParams"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUpdateParams.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUpdateParamsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("UpdateParams"))
              .build();
        }
      }
    }
    return getUpdateParamsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgSudoContract,
      com.cosmwasm.wasm.v1.MsgSudoContractResponse> getSudoContractMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SudoContract",
      requestType = com.cosmwasm.wasm.v1.MsgSudoContract.class,
      responseType = com.cosmwasm.wasm.v1.MsgSudoContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgSudoContract,
      com.cosmwasm.wasm.v1.MsgSudoContractResponse> getSudoContractMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgSudoContract, com.cosmwasm.wasm.v1.MsgSudoContractResponse> getSudoContractMethod;
    if ((getSudoContractMethod = MsgGrpc.getSudoContractMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getSudoContractMethod = MsgGrpc.getSudoContractMethod) == null) {
          MsgGrpc.getSudoContractMethod = getSudoContractMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgSudoContract, com.cosmwasm.wasm.v1.MsgSudoContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SudoContract"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgSudoContract.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgSudoContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("SudoContract"))
              .build();
        }
      }
    }
    return getSudoContractMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgPinCodes,
      com.cosmwasm.wasm.v1.MsgPinCodesResponse> getPinCodesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PinCodes",
      requestType = com.cosmwasm.wasm.v1.MsgPinCodes.class,
      responseType = com.cosmwasm.wasm.v1.MsgPinCodesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgPinCodes,
      com.cosmwasm.wasm.v1.MsgPinCodesResponse> getPinCodesMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgPinCodes, com.cosmwasm.wasm.v1.MsgPinCodesResponse> getPinCodesMethod;
    if ((getPinCodesMethod = MsgGrpc.getPinCodesMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getPinCodesMethod = MsgGrpc.getPinCodesMethod) == null) {
          MsgGrpc.getPinCodesMethod = getPinCodesMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgPinCodes, com.cosmwasm.wasm.v1.MsgPinCodesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "PinCodes"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgPinCodes.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgPinCodesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("PinCodes"))
              .build();
        }
      }
    }
    return getPinCodesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUnpinCodes,
      com.cosmwasm.wasm.v1.MsgUnpinCodesResponse> getUnpinCodesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UnpinCodes",
      requestType = com.cosmwasm.wasm.v1.MsgUnpinCodes.class,
      responseType = com.cosmwasm.wasm.v1.MsgUnpinCodesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUnpinCodes,
      com.cosmwasm.wasm.v1.MsgUnpinCodesResponse> getUnpinCodesMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUnpinCodes, com.cosmwasm.wasm.v1.MsgUnpinCodesResponse> getUnpinCodesMethod;
    if ((getUnpinCodesMethod = MsgGrpc.getUnpinCodesMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getUnpinCodesMethod = MsgGrpc.getUnpinCodesMethod) == null) {
          MsgGrpc.getUnpinCodesMethod = getUnpinCodesMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgUnpinCodes, com.cosmwasm.wasm.v1.MsgUnpinCodesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UnpinCodes"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUnpinCodes.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUnpinCodesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("UnpinCodes"))
              .build();
        }
      }
    }
    return getUnpinCodesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract,
      com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse> getStoreAndInstantiateContractMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StoreAndInstantiateContract",
      requestType = com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract.class,
      responseType = com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract,
      com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse> getStoreAndInstantiateContractMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract, com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse> getStoreAndInstantiateContractMethod;
    if ((getStoreAndInstantiateContractMethod = MsgGrpc.getStoreAndInstantiateContractMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getStoreAndInstantiateContractMethod = MsgGrpc.getStoreAndInstantiateContractMethod) == null) {
          MsgGrpc.getStoreAndInstantiateContractMethod = getStoreAndInstantiateContractMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract, com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StoreAndInstantiateContract"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("StoreAndInstantiateContract"))
              .build();
        }
      }
    }
    return getStoreAndInstantiateContractMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses,
      com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse> getRemoveCodeUploadParamsAddressesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RemoveCodeUploadParamsAddresses",
      requestType = com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses.class,
      responseType = com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses,
      com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse> getRemoveCodeUploadParamsAddressesMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses, com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse> getRemoveCodeUploadParamsAddressesMethod;
    if ((getRemoveCodeUploadParamsAddressesMethod = MsgGrpc.getRemoveCodeUploadParamsAddressesMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getRemoveCodeUploadParamsAddressesMethod = MsgGrpc.getRemoveCodeUploadParamsAddressesMethod) == null) {
          MsgGrpc.getRemoveCodeUploadParamsAddressesMethod = getRemoveCodeUploadParamsAddressesMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses, com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "RemoveCodeUploadParamsAddresses"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("RemoveCodeUploadParamsAddresses"))
              .build();
        }
      }
    }
    return getRemoveCodeUploadParamsAddressesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses,
      com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse> getAddCodeUploadParamsAddressesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AddCodeUploadParamsAddresses",
      requestType = com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses.class,
      responseType = com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses,
      com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse> getAddCodeUploadParamsAddressesMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses, com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse> getAddCodeUploadParamsAddressesMethod;
    if ((getAddCodeUploadParamsAddressesMethod = MsgGrpc.getAddCodeUploadParamsAddressesMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getAddCodeUploadParamsAddressesMethod = MsgGrpc.getAddCodeUploadParamsAddressesMethod) == null) {
          MsgGrpc.getAddCodeUploadParamsAddressesMethod = getAddCodeUploadParamsAddressesMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses, com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AddCodeUploadParamsAddresses"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("AddCodeUploadParamsAddresses"))
              .build();
        }
      }
    }
    return getAddCodeUploadParamsAddressesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract,
      com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse> getStoreAndMigrateContractMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StoreAndMigrateContract",
      requestType = com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract.class,
      responseType = com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract,
      com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse> getStoreAndMigrateContractMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract, com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse> getStoreAndMigrateContractMethod;
    if ((getStoreAndMigrateContractMethod = MsgGrpc.getStoreAndMigrateContractMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getStoreAndMigrateContractMethod = MsgGrpc.getStoreAndMigrateContractMethod) == null) {
          MsgGrpc.getStoreAndMigrateContractMethod = getStoreAndMigrateContractMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract, com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StoreAndMigrateContract"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("StoreAndMigrateContract"))
              .build();
        }
      }
    }
    return getStoreAndMigrateContractMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateContractLabel,
      com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse> getUpdateContractLabelMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateContractLabel",
      requestType = com.cosmwasm.wasm.v1.MsgUpdateContractLabel.class,
      responseType = com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateContractLabel,
      com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse> getUpdateContractLabelMethod() {
    io.grpc.MethodDescriptor<com.cosmwasm.wasm.v1.MsgUpdateContractLabel, com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse> getUpdateContractLabelMethod;
    if ((getUpdateContractLabelMethod = MsgGrpc.getUpdateContractLabelMethod) == null) {
      synchronized (MsgGrpc.class) {
        if ((getUpdateContractLabelMethod = MsgGrpc.getUpdateContractLabelMethod) == null) {
          MsgGrpc.getUpdateContractLabelMethod = getUpdateContractLabelMethod =
              io.grpc.MethodDescriptor.<com.cosmwasm.wasm.v1.MsgUpdateContractLabel, com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateContractLabel"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUpdateContractLabel.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MsgMethodDescriptorSupplier("UpdateContractLabel"))
              .build();
        }
      }
    }
    return getUpdateContractLabelMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static MsgStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MsgStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MsgStub>() {
        @java.lang.Override
        public MsgStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MsgStub(channel, callOptions);
        }
      };
    return MsgStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static MsgBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MsgBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MsgBlockingV2Stub>() {
        @java.lang.Override
        public MsgBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MsgBlockingV2Stub(channel, callOptions);
        }
      };
    return MsgBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static MsgBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MsgBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MsgBlockingStub>() {
        @java.lang.Override
        public MsgBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MsgBlockingStub(channel, callOptions);
        }
      };
    return MsgBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static MsgFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MsgFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MsgFutureStub>() {
        @java.lang.Override
        public MsgFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MsgFutureStub(channel, callOptions);
        }
      };
    return MsgFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Msg defines the wasm Msg service.
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * StoreCode to submit Wasm code to the system
     * </pre>
     */
    default void storeCode(com.cosmwasm.wasm.v1.MsgStoreCode request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgStoreCodeResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStoreCodeMethod(), responseObserver);
    }

    /**
     * <pre>
     *  InstantiateContract creates a new smart contract instance for the given
     *  code id.
     * </pre>
     */
    default void instantiateContract(com.cosmwasm.wasm.v1.MsgInstantiateContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgInstantiateContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getInstantiateContractMethod(), responseObserver);
    }

    /**
     * <pre>
     *  InstantiateContract2 creates a new smart contract instance for the given
     *  code id with a predictable address
     * </pre>
     */
    default void instantiateContract2(com.cosmwasm.wasm.v1.MsgInstantiateContract2 request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgInstantiateContract2Response> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getInstantiateContract2Method(), responseObserver);
    }

    /**
     * <pre>
     * Execute submits the given message data to a smart contract
     * </pre>
     */
    default void executeContract(com.cosmwasm.wasm.v1.MsgExecuteContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgExecuteContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getExecuteContractMethod(), responseObserver);
    }

    /**
     * <pre>
     * Migrate runs a code upgrade/ downgrade for a smart contract
     * </pre>
     */
    default void migrateContract(com.cosmwasm.wasm.v1.MsgMigrateContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgMigrateContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getMigrateContractMethod(), responseObserver);
    }

    /**
     * <pre>
     * UpdateAdmin sets a new admin for a smart contract
     * </pre>
     */
    default void updateAdmin(com.cosmwasm.wasm.v1.MsgUpdateAdmin request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateAdminResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateAdminMethod(), responseObserver);
    }

    /**
     * <pre>
     * ClearAdmin removes any admin stored for a smart contract
     * </pre>
     */
    default void clearAdmin(com.cosmwasm.wasm.v1.MsgClearAdmin request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgClearAdminResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getClearAdminMethod(), responseObserver);
    }

    /**
     * <pre>
     * UpdateInstantiateConfig updates instantiate config for a smart contract
     * </pre>
     */
    default void updateInstantiateConfig(com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateInstantiateConfigMethod(), responseObserver);
    }

    /**
     * <pre>
     * UpdateParams defines a governance operation for updating the x/wasm
     * module parameters. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    default void updateParams(com.cosmwasm.wasm.v1.MsgUpdateParams request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateParamsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateParamsMethod(), responseObserver);
    }

    /**
     * <pre>
     * SudoContract defines a governance operation for calling sudo
     * on a contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    default void sudoContract(com.cosmwasm.wasm.v1.MsgSudoContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgSudoContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSudoContractMethod(), responseObserver);
    }

    /**
     * <pre>
     * PinCodes defines a governance operation for pinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    default void pinCodes(com.cosmwasm.wasm.v1.MsgPinCodes request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgPinCodesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPinCodesMethod(), responseObserver);
    }

    /**
     * <pre>
     * UnpinCodes defines a governance operation for unpinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    default void unpinCodes(com.cosmwasm.wasm.v1.MsgUnpinCodes request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUnpinCodesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUnpinCodesMethod(), responseObserver);
    }

    /**
     * <pre>
     * StoreAndInstantiateContract defines a governance operation for storing
     * and instantiating the contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    default void storeAndInstantiateContract(com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStoreAndInstantiateContractMethod(), responseObserver);
    }

    /**
     * <pre>
     * RemoveCodeUploadParamsAddresses defines a governance operation for
     * removing addresses from code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    default void removeCodeUploadParamsAddresses(com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRemoveCodeUploadParamsAddressesMethod(), responseObserver);
    }

    /**
     * <pre>
     * AddCodeUploadParamsAddresses defines a governance operation for
     * adding addresses to code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    default void addCodeUploadParamsAddresses(com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAddCodeUploadParamsAddressesMethod(), responseObserver);
    }

    /**
     * <pre>
     * StoreAndMigrateContract defines a governance operation for storing
     * and migrating the contract. The authority is defined in the keeper.
     * Since: 0.42
     * </pre>
     */
    default void storeAndMigrateContract(com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStoreAndMigrateContractMethod(), responseObserver);
    }

    /**
     * <pre>
     * UpdateContractLabel sets a new label for a smart contract
     * Since: 0.43
     * </pre>
     */
    default void updateContractLabel(com.cosmwasm.wasm.v1.MsgUpdateContractLabel request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateContractLabelMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service Msg.
   * <pre>
   * Msg defines the wasm Msg service.
   * </pre>
   */
  public static abstract class MsgImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return MsgGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service Msg.
   * <pre>
   * Msg defines the wasm Msg service.
   * </pre>
   */
  public static final class MsgStub
      extends io.grpc.stub.AbstractAsyncStub<MsgStub> {
    private MsgStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MsgStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MsgStub(channel, callOptions);
    }

    /**
     * <pre>
     * StoreCode to submit Wasm code to the system
     * </pre>
     */
    public void storeCode(com.cosmwasm.wasm.v1.MsgStoreCode request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgStoreCodeResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getStoreCodeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     *  InstantiateContract creates a new smart contract instance for the given
     *  code id.
     * </pre>
     */
    public void instantiateContract(com.cosmwasm.wasm.v1.MsgInstantiateContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgInstantiateContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getInstantiateContractMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     *  InstantiateContract2 creates a new smart contract instance for the given
     *  code id with a predictable address
     * </pre>
     */
    public void instantiateContract2(com.cosmwasm.wasm.v1.MsgInstantiateContract2 request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgInstantiateContract2Response> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getInstantiateContract2Method(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Execute submits the given message data to a smart contract
     * </pre>
     */
    public void executeContract(com.cosmwasm.wasm.v1.MsgExecuteContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgExecuteContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getExecuteContractMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Migrate runs a code upgrade/ downgrade for a smart contract
     * </pre>
     */
    public void migrateContract(com.cosmwasm.wasm.v1.MsgMigrateContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgMigrateContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getMigrateContractMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * UpdateAdmin sets a new admin for a smart contract
     * </pre>
     */
    public void updateAdmin(com.cosmwasm.wasm.v1.MsgUpdateAdmin request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateAdminResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateAdminMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * ClearAdmin removes any admin stored for a smart contract
     * </pre>
     */
    public void clearAdmin(com.cosmwasm.wasm.v1.MsgClearAdmin request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgClearAdminResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getClearAdminMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * UpdateInstantiateConfig updates instantiate config for a smart contract
     * </pre>
     */
    public void updateInstantiateConfig(com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateInstantiateConfigMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * UpdateParams defines a governance operation for updating the x/wasm
     * module parameters. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public void updateParams(com.cosmwasm.wasm.v1.MsgUpdateParams request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateParamsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateParamsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * SudoContract defines a governance operation for calling sudo
     * on a contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public void sudoContract(com.cosmwasm.wasm.v1.MsgSudoContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgSudoContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSudoContractMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * PinCodes defines a governance operation for pinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public void pinCodes(com.cosmwasm.wasm.v1.MsgPinCodes request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgPinCodesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPinCodesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * UnpinCodes defines a governance operation for unpinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public void unpinCodes(com.cosmwasm.wasm.v1.MsgUnpinCodes request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUnpinCodesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUnpinCodesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * StoreAndInstantiateContract defines a governance operation for storing
     * and instantiating the contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public void storeAndInstantiateContract(com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getStoreAndInstantiateContractMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * RemoveCodeUploadParamsAddresses defines a governance operation for
     * removing addresses from code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    public void removeCodeUploadParamsAddresses(com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRemoveCodeUploadParamsAddressesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * AddCodeUploadParamsAddresses defines a governance operation for
     * adding addresses to code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    public void addCodeUploadParamsAddresses(com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAddCodeUploadParamsAddressesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * StoreAndMigrateContract defines a governance operation for storing
     * and migrating the contract. The authority is defined in the keeper.
     * Since: 0.42
     * </pre>
     */
    public void storeAndMigrateContract(com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getStoreAndMigrateContractMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * UpdateContractLabel sets a new label for a smart contract
     * Since: 0.43
     * </pre>
     */
    public void updateContractLabel(com.cosmwasm.wasm.v1.MsgUpdateContractLabel request,
        io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateContractLabelMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service Msg.
   * <pre>
   * Msg defines the wasm Msg service.
   * </pre>
   */
  public static final class MsgBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<MsgBlockingV2Stub> {
    private MsgBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MsgBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MsgBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * StoreCode to submit Wasm code to the system
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgStoreCodeResponse storeCode(com.cosmwasm.wasm.v1.MsgStoreCode request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getStoreCodeMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     *  InstantiateContract creates a new smart contract instance for the given
     *  code id.
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgInstantiateContractResponse instantiateContract(com.cosmwasm.wasm.v1.MsgInstantiateContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInstantiateContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     *  InstantiateContract2 creates a new smart contract instance for the given
     *  code id with a predictable address
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgInstantiateContract2Response instantiateContract2(com.cosmwasm.wasm.v1.MsgInstantiateContract2 request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInstantiateContract2Method(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Execute submits the given message data to a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgExecuteContractResponse executeContract(com.cosmwasm.wasm.v1.MsgExecuteContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExecuteContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Migrate runs a code upgrade/ downgrade for a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgMigrateContractResponse migrateContract(com.cosmwasm.wasm.v1.MsgMigrateContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getMigrateContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UpdateAdmin sets a new admin for a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUpdateAdminResponse updateAdmin(com.cosmwasm.wasm.v1.MsgUpdateAdmin request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateAdminMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * ClearAdmin removes any admin stored for a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgClearAdminResponse clearAdmin(com.cosmwasm.wasm.v1.MsgClearAdmin request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getClearAdminMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UpdateInstantiateConfig updates instantiate config for a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse updateInstantiateConfig(com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateInstantiateConfigMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UpdateParams defines a governance operation for updating the x/wasm
     * module parameters. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUpdateParamsResponse updateParams(com.cosmwasm.wasm.v1.MsgUpdateParams request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateParamsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * SudoContract defines a governance operation for calling sudo
     * on a contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgSudoContractResponse sudoContract(com.cosmwasm.wasm.v1.MsgSudoContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSudoContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * PinCodes defines a governance operation for pinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgPinCodesResponse pinCodes(com.cosmwasm.wasm.v1.MsgPinCodes request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPinCodesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UnpinCodes defines a governance operation for unpinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUnpinCodesResponse unpinCodes(com.cosmwasm.wasm.v1.MsgUnpinCodes request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUnpinCodesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * StoreAndInstantiateContract defines a governance operation for storing
     * and instantiating the contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse storeAndInstantiateContract(com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getStoreAndInstantiateContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * RemoveCodeUploadParamsAddresses defines a governance operation for
     * removing addresses from code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse removeCodeUploadParamsAddresses(com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRemoveCodeUploadParamsAddressesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * AddCodeUploadParamsAddresses defines a governance operation for
     * adding addresses to code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse addCodeUploadParamsAddresses(com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAddCodeUploadParamsAddressesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * StoreAndMigrateContract defines a governance operation for storing
     * and migrating the contract. The authority is defined in the keeper.
     * Since: 0.42
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse storeAndMigrateContract(com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getStoreAndMigrateContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UpdateContractLabel sets a new label for a smart contract
     * Since: 0.43
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse updateContractLabel(com.cosmwasm.wasm.v1.MsgUpdateContractLabel request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateContractLabelMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service Msg.
   * <pre>
   * Msg defines the wasm Msg service.
   * </pre>
   */
  public static final class MsgBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<MsgBlockingStub> {
    private MsgBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MsgBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MsgBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * StoreCode to submit Wasm code to the system
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgStoreCodeResponse storeCode(com.cosmwasm.wasm.v1.MsgStoreCode request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getStoreCodeMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     *  InstantiateContract creates a new smart contract instance for the given
     *  code id.
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgInstantiateContractResponse instantiateContract(com.cosmwasm.wasm.v1.MsgInstantiateContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInstantiateContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     *  InstantiateContract2 creates a new smart contract instance for the given
     *  code id with a predictable address
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgInstantiateContract2Response instantiateContract2(com.cosmwasm.wasm.v1.MsgInstantiateContract2 request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInstantiateContract2Method(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Execute submits the given message data to a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgExecuteContractResponse executeContract(com.cosmwasm.wasm.v1.MsgExecuteContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExecuteContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Migrate runs a code upgrade/ downgrade for a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgMigrateContractResponse migrateContract(com.cosmwasm.wasm.v1.MsgMigrateContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getMigrateContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UpdateAdmin sets a new admin for a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUpdateAdminResponse updateAdmin(com.cosmwasm.wasm.v1.MsgUpdateAdmin request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateAdminMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * ClearAdmin removes any admin stored for a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgClearAdminResponse clearAdmin(com.cosmwasm.wasm.v1.MsgClearAdmin request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getClearAdminMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UpdateInstantiateConfig updates instantiate config for a smart contract
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse updateInstantiateConfig(com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateInstantiateConfigMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UpdateParams defines a governance operation for updating the x/wasm
     * module parameters. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUpdateParamsResponse updateParams(com.cosmwasm.wasm.v1.MsgUpdateParams request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateParamsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * SudoContract defines a governance operation for calling sudo
     * on a contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgSudoContractResponse sudoContract(com.cosmwasm.wasm.v1.MsgSudoContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSudoContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * PinCodes defines a governance operation for pinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgPinCodesResponse pinCodes(com.cosmwasm.wasm.v1.MsgPinCodes request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPinCodesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UnpinCodes defines a governance operation for unpinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUnpinCodesResponse unpinCodes(com.cosmwasm.wasm.v1.MsgUnpinCodes request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUnpinCodesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * StoreAndInstantiateContract defines a governance operation for storing
     * and instantiating the contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse storeAndInstantiateContract(com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getStoreAndInstantiateContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * RemoveCodeUploadParamsAddresses defines a governance operation for
     * removing addresses from code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse removeCodeUploadParamsAddresses(com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRemoveCodeUploadParamsAddressesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * AddCodeUploadParamsAddresses defines a governance operation for
     * adding addresses to code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse addCodeUploadParamsAddresses(com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAddCodeUploadParamsAddressesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * StoreAndMigrateContract defines a governance operation for storing
     * and migrating the contract. The authority is defined in the keeper.
     * Since: 0.42
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse storeAndMigrateContract(com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getStoreAndMigrateContractMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * UpdateContractLabel sets a new label for a smart contract
     * Since: 0.43
     * </pre>
     */
    public com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse updateContractLabel(com.cosmwasm.wasm.v1.MsgUpdateContractLabel request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateContractLabelMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service Msg.
   * <pre>
   * Msg defines the wasm Msg service.
   * </pre>
   */
  public static final class MsgFutureStub
      extends io.grpc.stub.AbstractFutureStub<MsgFutureStub> {
    private MsgFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MsgFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MsgFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * StoreCode to submit Wasm code to the system
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgStoreCodeResponse> storeCode(
        com.cosmwasm.wasm.v1.MsgStoreCode request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getStoreCodeMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     *  InstantiateContract creates a new smart contract instance for the given
     *  code id.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgInstantiateContractResponse> instantiateContract(
        com.cosmwasm.wasm.v1.MsgInstantiateContract request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getInstantiateContractMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     *  InstantiateContract2 creates a new smart contract instance for the given
     *  code id with a predictable address
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgInstantiateContract2Response> instantiateContract2(
        com.cosmwasm.wasm.v1.MsgInstantiateContract2 request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getInstantiateContract2Method(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Execute submits the given message data to a smart contract
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgExecuteContractResponse> executeContract(
        com.cosmwasm.wasm.v1.MsgExecuteContract request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getExecuteContractMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Migrate runs a code upgrade/ downgrade for a smart contract
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgMigrateContractResponse> migrateContract(
        com.cosmwasm.wasm.v1.MsgMigrateContract request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getMigrateContractMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * UpdateAdmin sets a new admin for a smart contract
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgUpdateAdminResponse> updateAdmin(
        com.cosmwasm.wasm.v1.MsgUpdateAdmin request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateAdminMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * ClearAdmin removes any admin stored for a smart contract
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgClearAdminResponse> clearAdmin(
        com.cosmwasm.wasm.v1.MsgClearAdmin request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getClearAdminMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * UpdateInstantiateConfig updates instantiate config for a smart contract
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse> updateInstantiateConfig(
        com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateInstantiateConfigMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * UpdateParams defines a governance operation for updating the x/wasm
     * module parameters. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgUpdateParamsResponse> updateParams(
        com.cosmwasm.wasm.v1.MsgUpdateParams request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateParamsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * SudoContract defines a governance operation for calling sudo
     * on a contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgSudoContractResponse> sudoContract(
        com.cosmwasm.wasm.v1.MsgSudoContract request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSudoContractMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * PinCodes defines a governance operation for pinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgPinCodesResponse> pinCodes(
        com.cosmwasm.wasm.v1.MsgPinCodes request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPinCodesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * UnpinCodes defines a governance operation for unpinning a set of
     * code ids in the wasmvm cache. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgUnpinCodesResponse> unpinCodes(
        com.cosmwasm.wasm.v1.MsgUnpinCodes request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUnpinCodesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * StoreAndInstantiateContract defines a governance operation for storing
     * and instantiating the contract. The authority is defined in the keeper.
     * Since: 0.40
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse> storeAndInstantiateContract(
        com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getStoreAndInstantiateContractMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * RemoveCodeUploadParamsAddresses defines a governance operation for
     * removing addresses from code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse> removeCodeUploadParamsAddresses(
        com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRemoveCodeUploadParamsAddressesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * AddCodeUploadParamsAddresses defines a governance operation for
     * adding addresses to code upload params.
     * The authority is defined in the keeper.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse> addCodeUploadParamsAddresses(
        com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAddCodeUploadParamsAddressesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * StoreAndMigrateContract defines a governance operation for storing
     * and migrating the contract. The authority is defined in the keeper.
     * Since: 0.42
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse> storeAndMigrateContract(
        com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getStoreAndMigrateContractMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * UpdateContractLabel sets a new label for a smart contract
     * Since: 0.43
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse> updateContractLabel(
        com.cosmwasm.wasm.v1.MsgUpdateContractLabel request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateContractLabelMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_STORE_CODE = 0;
  private static final int METHODID_INSTANTIATE_CONTRACT = 1;
  private static final int METHODID_INSTANTIATE_CONTRACT2 = 2;
  private static final int METHODID_EXECUTE_CONTRACT = 3;
  private static final int METHODID_MIGRATE_CONTRACT = 4;
  private static final int METHODID_UPDATE_ADMIN = 5;
  private static final int METHODID_CLEAR_ADMIN = 6;
  private static final int METHODID_UPDATE_INSTANTIATE_CONFIG = 7;
  private static final int METHODID_UPDATE_PARAMS = 8;
  private static final int METHODID_SUDO_CONTRACT = 9;
  private static final int METHODID_PIN_CODES = 10;
  private static final int METHODID_UNPIN_CODES = 11;
  private static final int METHODID_STORE_AND_INSTANTIATE_CONTRACT = 12;
  private static final int METHODID_REMOVE_CODE_UPLOAD_PARAMS_ADDRESSES = 13;
  private static final int METHODID_ADD_CODE_UPLOAD_PARAMS_ADDRESSES = 14;
  private static final int METHODID_STORE_AND_MIGRATE_CONTRACT = 15;
  private static final int METHODID_UPDATE_CONTRACT_LABEL = 16;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_STORE_CODE:
          serviceImpl.storeCode((com.cosmwasm.wasm.v1.MsgStoreCode) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgStoreCodeResponse>) responseObserver);
          break;
        case METHODID_INSTANTIATE_CONTRACT:
          serviceImpl.instantiateContract((com.cosmwasm.wasm.v1.MsgInstantiateContract) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgInstantiateContractResponse>) responseObserver);
          break;
        case METHODID_INSTANTIATE_CONTRACT2:
          serviceImpl.instantiateContract2((com.cosmwasm.wasm.v1.MsgInstantiateContract2) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgInstantiateContract2Response>) responseObserver);
          break;
        case METHODID_EXECUTE_CONTRACT:
          serviceImpl.executeContract((com.cosmwasm.wasm.v1.MsgExecuteContract) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgExecuteContractResponse>) responseObserver);
          break;
        case METHODID_MIGRATE_CONTRACT:
          serviceImpl.migrateContract((com.cosmwasm.wasm.v1.MsgMigrateContract) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgMigrateContractResponse>) responseObserver);
          break;
        case METHODID_UPDATE_ADMIN:
          serviceImpl.updateAdmin((com.cosmwasm.wasm.v1.MsgUpdateAdmin) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateAdminResponse>) responseObserver);
          break;
        case METHODID_CLEAR_ADMIN:
          serviceImpl.clearAdmin((com.cosmwasm.wasm.v1.MsgClearAdmin) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgClearAdminResponse>) responseObserver);
          break;
        case METHODID_UPDATE_INSTANTIATE_CONFIG:
          serviceImpl.updateInstantiateConfig((com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse>) responseObserver);
          break;
        case METHODID_UPDATE_PARAMS:
          serviceImpl.updateParams((com.cosmwasm.wasm.v1.MsgUpdateParams) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateParamsResponse>) responseObserver);
          break;
        case METHODID_SUDO_CONTRACT:
          serviceImpl.sudoContract((com.cosmwasm.wasm.v1.MsgSudoContract) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgSudoContractResponse>) responseObserver);
          break;
        case METHODID_PIN_CODES:
          serviceImpl.pinCodes((com.cosmwasm.wasm.v1.MsgPinCodes) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgPinCodesResponse>) responseObserver);
          break;
        case METHODID_UNPIN_CODES:
          serviceImpl.unpinCodes((com.cosmwasm.wasm.v1.MsgUnpinCodes) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUnpinCodesResponse>) responseObserver);
          break;
        case METHODID_STORE_AND_INSTANTIATE_CONTRACT:
          serviceImpl.storeAndInstantiateContract((com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse>) responseObserver);
          break;
        case METHODID_REMOVE_CODE_UPLOAD_PARAMS_ADDRESSES:
          serviceImpl.removeCodeUploadParamsAddresses((com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse>) responseObserver);
          break;
        case METHODID_ADD_CODE_UPLOAD_PARAMS_ADDRESSES:
          serviceImpl.addCodeUploadParamsAddresses((com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse>) responseObserver);
          break;
        case METHODID_STORE_AND_MIGRATE_CONTRACT:
          serviceImpl.storeAndMigrateContract((com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse>) responseObserver);
          break;
        case METHODID_UPDATE_CONTRACT_LABEL:
          serviceImpl.updateContractLabel((com.cosmwasm.wasm.v1.MsgUpdateContractLabel) request,
              (io.grpc.stub.StreamObserver<com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getStoreCodeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgStoreCode,
              com.cosmwasm.wasm.v1.MsgStoreCodeResponse>(
                service, METHODID_STORE_CODE)))
        .addMethod(
          getInstantiateContractMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgInstantiateContract,
              com.cosmwasm.wasm.v1.MsgInstantiateContractResponse>(
                service, METHODID_INSTANTIATE_CONTRACT)))
        .addMethod(
          getInstantiateContract2Method(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgInstantiateContract2,
              com.cosmwasm.wasm.v1.MsgInstantiateContract2Response>(
                service, METHODID_INSTANTIATE_CONTRACT2)))
        .addMethod(
          getExecuteContractMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgExecuteContract,
              com.cosmwasm.wasm.v1.MsgExecuteContractResponse>(
                service, METHODID_EXECUTE_CONTRACT)))
        .addMethod(
          getMigrateContractMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgMigrateContract,
              com.cosmwasm.wasm.v1.MsgMigrateContractResponse>(
                service, METHODID_MIGRATE_CONTRACT)))
        .addMethod(
          getUpdateAdminMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgUpdateAdmin,
              com.cosmwasm.wasm.v1.MsgUpdateAdminResponse>(
                service, METHODID_UPDATE_ADMIN)))
        .addMethod(
          getClearAdminMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgClearAdmin,
              com.cosmwasm.wasm.v1.MsgClearAdminResponse>(
                service, METHODID_CLEAR_ADMIN)))
        .addMethod(
          getUpdateInstantiateConfigMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfig,
              com.cosmwasm.wasm.v1.MsgUpdateInstantiateConfigResponse>(
                service, METHODID_UPDATE_INSTANTIATE_CONFIG)))
        .addMethod(
          getUpdateParamsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgUpdateParams,
              com.cosmwasm.wasm.v1.MsgUpdateParamsResponse>(
                service, METHODID_UPDATE_PARAMS)))
        .addMethod(
          getSudoContractMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgSudoContract,
              com.cosmwasm.wasm.v1.MsgSudoContractResponse>(
                service, METHODID_SUDO_CONTRACT)))
        .addMethod(
          getPinCodesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgPinCodes,
              com.cosmwasm.wasm.v1.MsgPinCodesResponse>(
                service, METHODID_PIN_CODES)))
        .addMethod(
          getUnpinCodesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgUnpinCodes,
              com.cosmwasm.wasm.v1.MsgUnpinCodesResponse>(
                service, METHODID_UNPIN_CODES)))
        .addMethod(
          getStoreAndInstantiateContractMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContract,
              com.cosmwasm.wasm.v1.MsgStoreAndInstantiateContractResponse>(
                service, METHODID_STORE_AND_INSTANTIATE_CONTRACT)))
        .addMethod(
          getRemoveCodeUploadParamsAddressesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddresses,
              com.cosmwasm.wasm.v1.MsgRemoveCodeUploadParamsAddressesResponse>(
                service, METHODID_REMOVE_CODE_UPLOAD_PARAMS_ADDRESSES)))
        .addMethod(
          getAddCodeUploadParamsAddressesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddresses,
              com.cosmwasm.wasm.v1.MsgAddCodeUploadParamsAddressesResponse>(
                service, METHODID_ADD_CODE_UPLOAD_PARAMS_ADDRESSES)))
        .addMethod(
          getStoreAndMigrateContractMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgStoreAndMigrateContract,
              com.cosmwasm.wasm.v1.MsgStoreAndMigrateContractResponse>(
                service, METHODID_STORE_AND_MIGRATE_CONTRACT)))
        .addMethod(
          getUpdateContractLabelMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.cosmwasm.wasm.v1.MsgUpdateContractLabel,
              com.cosmwasm.wasm.v1.MsgUpdateContractLabelResponse>(
                service, METHODID_UPDATE_CONTRACT_LABEL)))
        .build();
  }

  private static abstract class MsgBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    MsgBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.cosmwasm.wasm.v1.TxProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("Msg");
    }
  }

  private static final class MsgFileDescriptorSupplier
      extends MsgBaseDescriptorSupplier {
    MsgFileDescriptorSupplier() {}
  }

  private static final class MsgMethodDescriptorSupplier
      extends MsgBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    MsgMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (MsgGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new MsgFileDescriptorSupplier())
              .addMethod(getStoreCodeMethod())
              .addMethod(getInstantiateContractMethod())
              .addMethod(getInstantiateContract2Method())
              .addMethod(getExecuteContractMethod())
              .addMethod(getMigrateContractMethod())
              .addMethod(getUpdateAdminMethod())
              .addMethod(getClearAdminMethod())
              .addMethod(getUpdateInstantiateConfigMethod())
              .addMethod(getUpdateParamsMethod())
              .addMethod(getSudoContractMethod())
              .addMethod(getPinCodesMethod())
              .addMethod(getUnpinCodesMethod())
              .addMethod(getStoreAndInstantiateContractMethod())
              .addMethod(getRemoveCodeUploadParamsAddressesMethod())
              .addMethod(getAddCodeUploadParamsAddressesMethod())
              .addMethod(getStoreAndMigrateContractMethod())
              .addMethod(getUpdateContractLabelMethod())
              .build();
        }
      }
    }
    return result;
  }
}

package com.injective_archiver_rpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * InjectiveArchiverRPC defines gRPC API of Archiver provider.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.73.0)",
    comments = "Source: exchange/injective_archiver_rpc.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class InjectiveArchiverRPCGrpc {

  private InjectiveArchiverRPCGrpc() {}

  public static final java.lang.String SERVICE_NAME = "injective_archiver_rpc.InjectiveArchiverRPC";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.injective_archiver_rpc.BalanceRequest,
      com.injective_archiver_rpc.BalanceResponse> getBalanceMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Balance",
      requestType = com.injective_archiver_rpc.BalanceRequest.class,
      responseType = com.injective_archiver_rpc.BalanceResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_archiver_rpc.BalanceRequest,
      com.injective_archiver_rpc.BalanceResponse> getBalanceMethod() {
    io.grpc.MethodDescriptor<com.injective_archiver_rpc.BalanceRequest, com.injective_archiver_rpc.BalanceResponse> getBalanceMethod;
    if ((getBalanceMethod = InjectiveArchiverRPCGrpc.getBalanceMethod) == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        if ((getBalanceMethod = InjectiveArchiverRPCGrpc.getBalanceMethod) == null) {
          InjectiveArchiverRPCGrpc.getBalanceMethod = getBalanceMethod =
              io.grpc.MethodDescriptor.<com.injective_archiver_rpc.BalanceRequest, com.injective_archiver_rpc.BalanceResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Balance"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.BalanceRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.BalanceResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveArchiverRPCMethodDescriptorSupplier("Balance"))
              .build();
        }
      }
    }
    return getBalanceMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_archiver_rpc.RpnlRequest,
      com.injective_archiver_rpc.RpnlResponse> getRpnlMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Rpnl",
      requestType = com.injective_archiver_rpc.RpnlRequest.class,
      responseType = com.injective_archiver_rpc.RpnlResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_archiver_rpc.RpnlRequest,
      com.injective_archiver_rpc.RpnlResponse> getRpnlMethod() {
    io.grpc.MethodDescriptor<com.injective_archiver_rpc.RpnlRequest, com.injective_archiver_rpc.RpnlResponse> getRpnlMethod;
    if ((getRpnlMethod = InjectiveArchiverRPCGrpc.getRpnlMethod) == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        if ((getRpnlMethod = InjectiveArchiverRPCGrpc.getRpnlMethod) == null) {
          InjectiveArchiverRPCGrpc.getRpnlMethod = getRpnlMethod =
              io.grpc.MethodDescriptor.<com.injective_archiver_rpc.RpnlRequest, com.injective_archiver_rpc.RpnlResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Rpnl"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.RpnlRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.RpnlResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveArchiverRPCMethodDescriptorSupplier("Rpnl"))
              .build();
        }
      }
    }
    return getRpnlMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_archiver_rpc.VolumesRequest,
      com.injective_archiver_rpc.VolumesResponse> getVolumesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Volumes",
      requestType = com.injective_archiver_rpc.VolumesRequest.class,
      responseType = com.injective_archiver_rpc.VolumesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_archiver_rpc.VolumesRequest,
      com.injective_archiver_rpc.VolumesResponse> getVolumesMethod() {
    io.grpc.MethodDescriptor<com.injective_archiver_rpc.VolumesRequest, com.injective_archiver_rpc.VolumesResponse> getVolumesMethod;
    if ((getVolumesMethod = InjectiveArchiverRPCGrpc.getVolumesMethod) == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        if ((getVolumesMethod = InjectiveArchiverRPCGrpc.getVolumesMethod) == null) {
          InjectiveArchiverRPCGrpc.getVolumesMethod = getVolumesMethod =
              io.grpc.MethodDescriptor.<com.injective_archiver_rpc.VolumesRequest, com.injective_archiver_rpc.VolumesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Volumes"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.VolumesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.VolumesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveArchiverRPCMethodDescriptorSupplier("Volumes"))
              .build();
        }
      }
    }
    return getVolumesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_archiver_rpc.PnlLeaderboardRequest,
      com.injective_archiver_rpc.PnlLeaderboardResponse> getPnlLeaderboardMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PnlLeaderboard",
      requestType = com.injective_archiver_rpc.PnlLeaderboardRequest.class,
      responseType = com.injective_archiver_rpc.PnlLeaderboardResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_archiver_rpc.PnlLeaderboardRequest,
      com.injective_archiver_rpc.PnlLeaderboardResponse> getPnlLeaderboardMethod() {
    io.grpc.MethodDescriptor<com.injective_archiver_rpc.PnlLeaderboardRequest, com.injective_archiver_rpc.PnlLeaderboardResponse> getPnlLeaderboardMethod;
    if ((getPnlLeaderboardMethod = InjectiveArchiverRPCGrpc.getPnlLeaderboardMethod) == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        if ((getPnlLeaderboardMethod = InjectiveArchiverRPCGrpc.getPnlLeaderboardMethod) == null) {
          InjectiveArchiverRPCGrpc.getPnlLeaderboardMethod = getPnlLeaderboardMethod =
              io.grpc.MethodDescriptor.<com.injective_archiver_rpc.PnlLeaderboardRequest, com.injective_archiver_rpc.PnlLeaderboardResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "PnlLeaderboard"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.PnlLeaderboardRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.PnlLeaderboardResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveArchiverRPCMethodDescriptorSupplier("PnlLeaderboard"))
              .build();
        }
      }
    }
    return getPnlLeaderboardMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_archiver_rpc.VolLeaderboardRequest,
      com.injective_archiver_rpc.VolLeaderboardResponse> getVolLeaderboardMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "VolLeaderboard",
      requestType = com.injective_archiver_rpc.VolLeaderboardRequest.class,
      responseType = com.injective_archiver_rpc.VolLeaderboardResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_archiver_rpc.VolLeaderboardRequest,
      com.injective_archiver_rpc.VolLeaderboardResponse> getVolLeaderboardMethod() {
    io.grpc.MethodDescriptor<com.injective_archiver_rpc.VolLeaderboardRequest, com.injective_archiver_rpc.VolLeaderboardResponse> getVolLeaderboardMethod;
    if ((getVolLeaderboardMethod = InjectiveArchiverRPCGrpc.getVolLeaderboardMethod) == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        if ((getVolLeaderboardMethod = InjectiveArchiverRPCGrpc.getVolLeaderboardMethod) == null) {
          InjectiveArchiverRPCGrpc.getVolLeaderboardMethod = getVolLeaderboardMethod =
              io.grpc.MethodDescriptor.<com.injective_archiver_rpc.VolLeaderboardRequest, com.injective_archiver_rpc.VolLeaderboardResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "VolLeaderboard"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.VolLeaderboardRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.VolLeaderboardResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveArchiverRPCMethodDescriptorSupplier("VolLeaderboard"))
              .build();
        }
      }
    }
    return getVolLeaderboardMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest,
      com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse> getPnlLeaderboardFixedResolutionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PnlLeaderboardFixedResolution",
      requestType = com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest.class,
      responseType = com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest,
      com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse> getPnlLeaderboardFixedResolutionMethod() {
    io.grpc.MethodDescriptor<com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest, com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse> getPnlLeaderboardFixedResolutionMethod;
    if ((getPnlLeaderboardFixedResolutionMethod = InjectiveArchiverRPCGrpc.getPnlLeaderboardFixedResolutionMethod) == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        if ((getPnlLeaderboardFixedResolutionMethod = InjectiveArchiverRPCGrpc.getPnlLeaderboardFixedResolutionMethod) == null) {
          InjectiveArchiverRPCGrpc.getPnlLeaderboardFixedResolutionMethod = getPnlLeaderboardFixedResolutionMethod =
              io.grpc.MethodDescriptor.<com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest, com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "PnlLeaderboardFixedResolution"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveArchiverRPCMethodDescriptorSupplier("PnlLeaderboardFixedResolution"))
              .build();
        }
      }
    }
    return getPnlLeaderboardFixedResolutionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest,
      com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse> getVolLeaderboardFixedResolutionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "VolLeaderboardFixedResolution",
      requestType = com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest.class,
      responseType = com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest,
      com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse> getVolLeaderboardFixedResolutionMethod() {
    io.grpc.MethodDescriptor<com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest, com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse> getVolLeaderboardFixedResolutionMethod;
    if ((getVolLeaderboardFixedResolutionMethod = InjectiveArchiverRPCGrpc.getVolLeaderboardFixedResolutionMethod) == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        if ((getVolLeaderboardFixedResolutionMethod = InjectiveArchiverRPCGrpc.getVolLeaderboardFixedResolutionMethod) == null) {
          InjectiveArchiverRPCGrpc.getVolLeaderboardFixedResolutionMethod = getVolLeaderboardFixedResolutionMethod =
              io.grpc.MethodDescriptor.<com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest, com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "VolLeaderboardFixedResolution"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveArchiverRPCMethodDescriptorSupplier("VolLeaderboardFixedResolution"))
              .build();
        }
      }
    }
    return getVolLeaderboardFixedResolutionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_archiver_rpc.DenomHoldersRequest,
      com.injective_archiver_rpc.DenomHoldersResponse> getDenomHoldersMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DenomHolders",
      requestType = com.injective_archiver_rpc.DenomHoldersRequest.class,
      responseType = com.injective_archiver_rpc.DenomHoldersResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_archiver_rpc.DenomHoldersRequest,
      com.injective_archiver_rpc.DenomHoldersResponse> getDenomHoldersMethod() {
    io.grpc.MethodDescriptor<com.injective_archiver_rpc.DenomHoldersRequest, com.injective_archiver_rpc.DenomHoldersResponse> getDenomHoldersMethod;
    if ((getDenomHoldersMethod = InjectiveArchiverRPCGrpc.getDenomHoldersMethod) == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        if ((getDenomHoldersMethod = InjectiveArchiverRPCGrpc.getDenomHoldersMethod) == null) {
          InjectiveArchiverRPCGrpc.getDenomHoldersMethod = getDenomHoldersMethod =
              io.grpc.MethodDescriptor.<com.injective_archiver_rpc.DenomHoldersRequest, com.injective_archiver_rpc.DenomHoldersResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DenomHolders"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.DenomHoldersRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.DenomHoldersResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveArchiverRPCMethodDescriptorSupplier("DenomHolders"))
              .build();
        }
      }
    }
    return getDenomHoldersMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.injective_archiver_rpc.HistoricalTradesRequest,
      com.injective_archiver_rpc.HistoricalTradesResponse> getHistoricalTradesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "HistoricalTrades",
      requestType = com.injective_archiver_rpc.HistoricalTradesRequest.class,
      responseType = com.injective_archiver_rpc.HistoricalTradesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.injective_archiver_rpc.HistoricalTradesRequest,
      com.injective_archiver_rpc.HistoricalTradesResponse> getHistoricalTradesMethod() {
    io.grpc.MethodDescriptor<com.injective_archiver_rpc.HistoricalTradesRequest, com.injective_archiver_rpc.HistoricalTradesResponse> getHistoricalTradesMethod;
    if ((getHistoricalTradesMethod = InjectiveArchiverRPCGrpc.getHistoricalTradesMethod) == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        if ((getHistoricalTradesMethod = InjectiveArchiverRPCGrpc.getHistoricalTradesMethod) == null) {
          InjectiveArchiverRPCGrpc.getHistoricalTradesMethod = getHistoricalTradesMethod =
              io.grpc.MethodDescriptor.<com.injective_archiver_rpc.HistoricalTradesRequest, com.injective_archiver_rpc.HistoricalTradesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "HistoricalTrades"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.HistoricalTradesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.injective_archiver_rpc.HistoricalTradesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new InjectiveArchiverRPCMethodDescriptorSupplier("HistoricalTrades"))
              .build();
        }
      }
    }
    return getHistoricalTradesMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static InjectiveArchiverRPCStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveArchiverRPCStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveArchiverRPCStub>() {
        @java.lang.Override
        public InjectiveArchiverRPCStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveArchiverRPCStub(channel, callOptions);
        }
      };
    return InjectiveArchiverRPCStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static InjectiveArchiverRPCBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveArchiverRPCBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveArchiverRPCBlockingV2Stub>() {
        @java.lang.Override
        public InjectiveArchiverRPCBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveArchiverRPCBlockingV2Stub(channel, callOptions);
        }
      };
    return InjectiveArchiverRPCBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static InjectiveArchiverRPCBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveArchiverRPCBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveArchiverRPCBlockingStub>() {
        @java.lang.Override
        public InjectiveArchiverRPCBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveArchiverRPCBlockingStub(channel, callOptions);
        }
      };
    return InjectiveArchiverRPCBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static InjectiveArchiverRPCFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<InjectiveArchiverRPCFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<InjectiveArchiverRPCFutureStub>() {
        @java.lang.Override
        public InjectiveArchiverRPCFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new InjectiveArchiverRPCFutureStub(channel, callOptions);
        }
      };
    return InjectiveArchiverRPCFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * InjectiveArchiverRPC defines gRPC API of Archiver provider.
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Provide historical balance data for a given account address.
     * </pre>
     */
    default void balance(com.injective_archiver_rpc.BalanceRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.BalanceResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBalanceMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide historical realized profit and loss data for a given account address.
     * </pre>
     */
    default void rpnl(com.injective_archiver_rpc.RpnlRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.RpnlResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRpnlMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide historical volumes for a given account address.
     * </pre>
     */
    default void volumes(com.injective_archiver_rpc.VolumesRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.VolumesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getVolumesMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    default void pnlLeaderboard(com.injective_archiver_rpc.PnlLeaderboardRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.PnlLeaderboardResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPnlLeaderboardMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    default void volLeaderboard(com.injective_archiver_rpc.VolLeaderboardRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.VolLeaderboardResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getVolLeaderboardMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    default void pnlLeaderboardFixedResolution(com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPnlLeaderboardFixedResolutionMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    default void volLeaderboardFixedResolution(com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getVolLeaderboardFixedResolutionMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide a list of addresses holding a specific denom
     * </pre>
     */
    default void denomHolders(com.injective_archiver_rpc.DenomHoldersRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.DenomHoldersResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDenomHoldersMethod(), responseObserver);
    }

    /**
     * <pre>
     * Provide historical trades data.
     * </pre>
     */
    default void historicalTrades(com.injective_archiver_rpc.HistoricalTradesRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.HistoricalTradesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getHistoricalTradesMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service InjectiveArchiverRPC.
   * <pre>
   * InjectiveArchiverRPC defines gRPC API of Archiver provider.
   * </pre>
   */
  public static abstract class InjectiveArchiverRPCImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return InjectiveArchiverRPCGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service InjectiveArchiverRPC.
   * <pre>
   * InjectiveArchiverRPC defines gRPC API of Archiver provider.
   * </pre>
   */
  public static final class InjectiveArchiverRPCStub
      extends io.grpc.stub.AbstractAsyncStub<InjectiveArchiverRPCStub> {
    private InjectiveArchiverRPCStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveArchiverRPCStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveArchiverRPCStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide historical balance data for a given account address.
     * </pre>
     */
    public void balance(com.injective_archiver_rpc.BalanceRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.BalanceResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getBalanceMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide historical realized profit and loss data for a given account address.
     * </pre>
     */
    public void rpnl(com.injective_archiver_rpc.RpnlRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.RpnlResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRpnlMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide historical volumes for a given account address.
     * </pre>
     */
    public void volumes(com.injective_archiver_rpc.VolumesRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.VolumesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getVolumesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    public void pnlLeaderboard(com.injective_archiver_rpc.PnlLeaderboardRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.PnlLeaderboardResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPnlLeaderboardMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    public void volLeaderboard(com.injective_archiver_rpc.VolLeaderboardRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.VolLeaderboardResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getVolLeaderboardMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    public void pnlLeaderboardFixedResolution(com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPnlLeaderboardFixedResolutionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    public void volLeaderboardFixedResolution(com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getVolLeaderboardFixedResolutionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide a list of addresses holding a specific denom
     * </pre>
     */
    public void denomHolders(com.injective_archiver_rpc.DenomHoldersRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.DenomHoldersResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDenomHoldersMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Provide historical trades data.
     * </pre>
     */
    public void historicalTrades(com.injective_archiver_rpc.HistoricalTradesRequest request,
        io.grpc.stub.StreamObserver<com.injective_archiver_rpc.HistoricalTradesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getHistoricalTradesMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service InjectiveArchiverRPC.
   * <pre>
   * InjectiveArchiverRPC defines gRPC API of Archiver provider.
   * </pre>
   */
  public static final class InjectiveArchiverRPCBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<InjectiveArchiverRPCBlockingV2Stub> {
    private InjectiveArchiverRPCBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveArchiverRPCBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveArchiverRPCBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide historical balance data for a given account address.
     * </pre>
     */
    public com.injective_archiver_rpc.BalanceResponse balance(com.injective_archiver_rpc.BalanceRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBalanceMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide historical realized profit and loss data for a given account address.
     * </pre>
     */
    public com.injective_archiver_rpc.RpnlResponse rpnl(com.injective_archiver_rpc.RpnlRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRpnlMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide historical volumes for a given account address.
     * </pre>
     */
    public com.injective_archiver_rpc.VolumesResponse volumes(com.injective_archiver_rpc.VolumesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getVolumesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    public com.injective_archiver_rpc.PnlLeaderboardResponse pnlLeaderboard(com.injective_archiver_rpc.PnlLeaderboardRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPnlLeaderboardMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    public com.injective_archiver_rpc.VolLeaderboardResponse volLeaderboard(com.injective_archiver_rpc.VolLeaderboardRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getVolLeaderboardMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    public com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse pnlLeaderboardFixedResolution(com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPnlLeaderboardFixedResolutionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    public com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse volLeaderboardFixedResolution(com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getVolLeaderboardFixedResolutionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide a list of addresses holding a specific denom
     * </pre>
     */
    public com.injective_archiver_rpc.DenomHoldersResponse denomHolders(com.injective_archiver_rpc.DenomHoldersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDenomHoldersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide historical trades data.
     * </pre>
     */
    public com.injective_archiver_rpc.HistoricalTradesResponse historicalTrades(com.injective_archiver_rpc.HistoricalTradesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getHistoricalTradesMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service InjectiveArchiverRPC.
   * <pre>
   * InjectiveArchiverRPC defines gRPC API of Archiver provider.
   * </pre>
   */
  public static final class InjectiveArchiverRPCBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<InjectiveArchiverRPCBlockingStub> {
    private InjectiveArchiverRPCBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveArchiverRPCBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveArchiverRPCBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide historical balance data for a given account address.
     * </pre>
     */
    public com.injective_archiver_rpc.BalanceResponse balance(com.injective_archiver_rpc.BalanceRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBalanceMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide historical realized profit and loss data for a given account address.
     * </pre>
     */
    public com.injective_archiver_rpc.RpnlResponse rpnl(com.injective_archiver_rpc.RpnlRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRpnlMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide historical volumes for a given account address.
     * </pre>
     */
    public com.injective_archiver_rpc.VolumesResponse volumes(com.injective_archiver_rpc.VolumesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getVolumesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    public com.injective_archiver_rpc.PnlLeaderboardResponse pnlLeaderboard(com.injective_archiver_rpc.PnlLeaderboardRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPnlLeaderboardMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    public com.injective_archiver_rpc.VolLeaderboardResponse volLeaderboard(com.injective_archiver_rpc.VolLeaderboardRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getVolLeaderboardMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    public com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse pnlLeaderboardFixedResolution(com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPnlLeaderboardFixedResolutionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    public com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse volLeaderboardFixedResolution(com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getVolLeaderboardFixedResolutionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide a list of addresses holding a specific denom
     * </pre>
     */
    public com.injective_archiver_rpc.DenomHoldersResponse denomHolders(com.injective_archiver_rpc.DenomHoldersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDenomHoldersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Provide historical trades data.
     * </pre>
     */
    public com.injective_archiver_rpc.HistoricalTradesResponse historicalTrades(com.injective_archiver_rpc.HistoricalTradesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getHistoricalTradesMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service InjectiveArchiverRPC.
   * <pre>
   * InjectiveArchiverRPC defines gRPC API of Archiver provider.
   * </pre>
   */
  public static final class InjectiveArchiverRPCFutureStub
      extends io.grpc.stub.AbstractFutureStub<InjectiveArchiverRPCFutureStub> {
    private InjectiveArchiverRPCFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected InjectiveArchiverRPCFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new InjectiveArchiverRPCFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Provide historical balance data for a given account address.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_archiver_rpc.BalanceResponse> balance(
        com.injective_archiver_rpc.BalanceRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getBalanceMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide historical realized profit and loss data for a given account address.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_archiver_rpc.RpnlResponse> rpnl(
        com.injective_archiver_rpc.RpnlRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRpnlMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide historical volumes for a given account address.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_archiver_rpc.VolumesResponse> volumes(
        com.injective_archiver_rpc.VolumesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getVolumesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_archiver_rpc.PnlLeaderboardResponse> pnlLeaderboard(
        com.injective_archiver_rpc.PnlLeaderboardRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPnlLeaderboardMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_archiver_rpc.VolLeaderboardResponse> volLeaderboard(
        com.injective_archiver_rpc.VolLeaderboardRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getVolLeaderboardMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide pnl leaderboard data.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse> pnlLeaderboardFixedResolution(
        com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPnlLeaderboardFixedResolutionMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide volume leaderboard data.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse> volLeaderboardFixedResolution(
        com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getVolLeaderboardFixedResolutionMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide a list of addresses holding a specific denom
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_archiver_rpc.DenomHoldersResponse> denomHolders(
        com.injective_archiver_rpc.DenomHoldersRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDenomHoldersMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Provide historical trades data.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.injective_archiver_rpc.HistoricalTradesResponse> historicalTrades(
        com.injective_archiver_rpc.HistoricalTradesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getHistoricalTradesMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_BALANCE = 0;
  private static final int METHODID_RPNL = 1;
  private static final int METHODID_VOLUMES = 2;
  private static final int METHODID_PNL_LEADERBOARD = 3;
  private static final int METHODID_VOL_LEADERBOARD = 4;
  private static final int METHODID_PNL_LEADERBOARD_FIXED_RESOLUTION = 5;
  private static final int METHODID_VOL_LEADERBOARD_FIXED_RESOLUTION = 6;
  private static final int METHODID_DENOM_HOLDERS = 7;
  private static final int METHODID_HISTORICAL_TRADES = 8;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_BALANCE:
          serviceImpl.balance((com.injective_archiver_rpc.BalanceRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_archiver_rpc.BalanceResponse>) responseObserver);
          break;
        case METHODID_RPNL:
          serviceImpl.rpnl((com.injective_archiver_rpc.RpnlRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_archiver_rpc.RpnlResponse>) responseObserver);
          break;
        case METHODID_VOLUMES:
          serviceImpl.volumes((com.injective_archiver_rpc.VolumesRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_archiver_rpc.VolumesResponse>) responseObserver);
          break;
        case METHODID_PNL_LEADERBOARD:
          serviceImpl.pnlLeaderboard((com.injective_archiver_rpc.PnlLeaderboardRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_archiver_rpc.PnlLeaderboardResponse>) responseObserver);
          break;
        case METHODID_VOL_LEADERBOARD:
          serviceImpl.volLeaderboard((com.injective_archiver_rpc.VolLeaderboardRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_archiver_rpc.VolLeaderboardResponse>) responseObserver);
          break;
        case METHODID_PNL_LEADERBOARD_FIXED_RESOLUTION:
          serviceImpl.pnlLeaderboardFixedResolution((com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse>) responseObserver);
          break;
        case METHODID_VOL_LEADERBOARD_FIXED_RESOLUTION:
          serviceImpl.volLeaderboardFixedResolution((com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse>) responseObserver);
          break;
        case METHODID_DENOM_HOLDERS:
          serviceImpl.denomHolders((com.injective_archiver_rpc.DenomHoldersRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_archiver_rpc.DenomHoldersResponse>) responseObserver);
          break;
        case METHODID_HISTORICAL_TRADES:
          serviceImpl.historicalTrades((com.injective_archiver_rpc.HistoricalTradesRequest) request,
              (io.grpc.stub.StreamObserver<com.injective_archiver_rpc.HistoricalTradesResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getBalanceMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_archiver_rpc.BalanceRequest,
              com.injective_archiver_rpc.BalanceResponse>(
                service, METHODID_BALANCE)))
        .addMethod(
          getRpnlMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_archiver_rpc.RpnlRequest,
              com.injective_archiver_rpc.RpnlResponse>(
                service, METHODID_RPNL)))
        .addMethod(
          getVolumesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_archiver_rpc.VolumesRequest,
              com.injective_archiver_rpc.VolumesResponse>(
                service, METHODID_VOLUMES)))
        .addMethod(
          getPnlLeaderboardMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_archiver_rpc.PnlLeaderboardRequest,
              com.injective_archiver_rpc.PnlLeaderboardResponse>(
                service, METHODID_PNL_LEADERBOARD)))
        .addMethod(
          getVolLeaderboardMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_archiver_rpc.VolLeaderboardRequest,
              com.injective_archiver_rpc.VolLeaderboardResponse>(
                service, METHODID_VOL_LEADERBOARD)))
        .addMethod(
          getPnlLeaderboardFixedResolutionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_archiver_rpc.PnlLeaderboardFixedResolutionRequest,
              com.injective_archiver_rpc.PnlLeaderboardFixedResolutionResponse>(
                service, METHODID_PNL_LEADERBOARD_FIXED_RESOLUTION)))
        .addMethod(
          getVolLeaderboardFixedResolutionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_archiver_rpc.VolLeaderboardFixedResolutionRequest,
              com.injective_archiver_rpc.VolLeaderboardFixedResolutionResponse>(
                service, METHODID_VOL_LEADERBOARD_FIXED_RESOLUTION)))
        .addMethod(
          getDenomHoldersMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_archiver_rpc.DenomHoldersRequest,
              com.injective_archiver_rpc.DenomHoldersResponse>(
                service, METHODID_DENOM_HOLDERS)))
        .addMethod(
          getHistoricalTradesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.injective_archiver_rpc.HistoricalTradesRequest,
              com.injective_archiver_rpc.HistoricalTradesResponse>(
                service, METHODID_HISTORICAL_TRADES)))
        .build();
  }

  private static abstract class InjectiveArchiverRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    InjectiveArchiverRPCBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.injective_archiver_rpc.InjectiveArchiverRpcProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("InjectiveArchiverRPC");
    }
  }

  private static final class InjectiveArchiverRPCFileDescriptorSupplier
      extends InjectiveArchiverRPCBaseDescriptorSupplier {
    InjectiveArchiverRPCFileDescriptorSupplier() {}
  }

  private static final class InjectiveArchiverRPCMethodDescriptorSupplier
      extends InjectiveArchiverRPCBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    InjectiveArchiverRPCMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (InjectiveArchiverRPCGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new InjectiveArchiverRPCFileDescriptorSupplier())
              .addMethod(getBalanceMethod())
              .addMethod(getRpnlMethod())
              .addMethod(getVolumesMethod())
              .addMethod(getPnlLeaderboardMethod())
              .addMethod(getVolLeaderboardMethod())
              .addMethod(getPnlLeaderboardFixedResolutionMethod())
              .addMethod(getVolLeaderboardFixedResolutionMethod())
              .addMethod(getDenomHoldersMethod())
              .addMethod(getHistoricalTradesMethod())
              .build();
        }
      }
    }
    return result;
  }
}

// @generated
/// Params
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Params {
}
/// HypToken ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct HypToken {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(enumeration="HypTokenType", tag="3")]
    pub token_type: i32,
    #[prost(string, tag="4")]
    pub origin_mailbox: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub origin_denom: ::prost::alloc::string::String,
    #[prost(string, tag="6")]
    pub collateral_balance: ::prost::alloc::string::String,
    #[prost(string, tag="7")]
    pub ism_id: ::prost::alloc::string::String,
}
/// RemoteRouter ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RemoteRouter {
    #[prost(uint32, tag="1")]
    pub receiver_domain: u32,
    #[prost(string, tag="2")]
    pub receiver_contract: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub gas: ::prost::alloc::string::String,
}
/// HypTokenType ...
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum HypTokenType {
    /// HYP_TOKEN_TYPE_UNSPECIFIED ...
    Unspecified = 0,
    /// HYP_TOKEN_TYPE_COLLATERAL ...
    Collateral = 1,
    /// HYP_TOKEN_TYPE_SYNTHETIC ...
    Synthetic = 2,
}
impl HypTokenType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            HypTokenType::Unspecified => "HYP_TOKEN_TYPE_UNSPECIFIED",
            HypTokenType::Collateral => "HYP_TOKEN_TYPE_COLLATERAL",
            HypTokenType::Synthetic => "HYP_TOKEN_TYPE_SYNTHETIC",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "HYP_TOKEN_TYPE_UNSPECIFIED" => Some(Self::Unspecified),
            "HYP_TOKEN_TYPE_COLLATERAL" => Some(Self::Collateral),
            "HYP_TOKEN_TYPE_SYNTHETIC" => Some(Self::Synthetic),
            _ => None,
        }
    }
}
/// MsgCreateCollateralToken ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateCollateralToken {
    /// owner is the message sender.
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub origin_mailbox: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub origin_denom: ::prost::alloc::string::String,
}
/// MsgCreateCollateralTokenResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateCollateralTokenResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// MsgCreateSyntheticToken ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateSyntheticToken {
    /// owner is the message sender.
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub origin_mailbox: ::prost::alloc::string::String,
}
/// MsgCreateNativeSyntheticToken ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateNativeSyntheticToken {
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub origin_mailbox: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub origin_denom: ::prost::alloc::string::String,
}
/// MsgCreateSyntheticTokenResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateSyntheticTokenResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// MsgSetToken ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetToken {
    /// owner is the message sender.
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub new_owner: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub ism_id: ::prost::alloc::string::String,
    #[prost(bool, tag="7")]
    pub renounce_ownership: bool,
}
/// MsgSetTokenResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetTokenResponse {
}
/// MsgEnrollRemoteRouter ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgEnrollRemoteRouter {
    /// owner is the message sender.
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub remote_router: ::core::option::Option<RemoteRouter>,
}
/// MsgEnrollRemoteRouterResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgEnrollRemoteRouterResponse {
}
/// MsgUnrollRemoteRouter ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUnrollRemoteRouter {
    /// owner is the message sender.
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(uint32, tag="3")]
    pub receiver_domain: u32,
}
/// MsgUnrollRemoteRouterResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUnrollRemoteRouterResponse {
}
/// MsgRemoteTransfer ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgRemoteTransfer {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(uint32, tag="3")]
    pub destination_domain: u32,
    #[prost(string, tag="4")]
    pub recipient: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub amount: ::prost::alloc::string::String,
    /// Post Dispatch
    #[prost(string, tag="6")]
    pub custom_hook_id: ::prost::alloc::string::String,
    #[prost(string, tag="7")]
    pub gas_limit: ::prost::alloc::string::String,
    #[prost(message, optional, tag="8")]
    pub max_fee: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
    #[prost(string, tag="9")]
    pub custom_hook_metadata: ::prost::alloc::string::String,
}
/// MsgRemoteTransferResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgRemoteTransferResponse {
    #[prost(string, tag="1")]
    pub message_id: ::prost::alloc::string::String,
}
/// EventCreateSyntheticToken ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateSyntheticToken {
    #[prost(string, tag="1")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub origin_mailbox: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub origin_denom: ::prost::alloc::string::String,
}
/// EventCreateCollateralToken ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateCollateralToken {
    #[prost(string, tag="1")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub origin_mailbox: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub origin_denom: ::prost::alloc::string::String,
}
/// EventSetToken ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSetToken {
    #[prost(string, tag="1")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub ism_id: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub new_owner: ::prost::alloc::string::String,
    #[prost(bool, tag="5")]
    pub renounce_ownership: bool,
}
/// EventEnrollRemoteRouter ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventEnrollRemoteRouter {
    #[prost(string, tag="1")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(uint32, tag="3")]
    pub receiver_domain: u32,
    #[prost(string, tag="4")]
    pub receiver_contract: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub gas: ::prost::alloc::string::String,
}
/// EventUnrollRemoteRouter ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventUnrollRemoteRouter {
    #[prost(string, tag="1")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(uint32, tag="3")]
    pub receiver_domain: u32,
}
/// EventSendRemoteTransfer ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSendRemoteTransfer {
    #[prost(string, tag="1")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub sender: ::prost::alloc::string::String,
    #[prost(uint32, tag="3")]
    pub destination_domain: u32,
    #[prost(string, tag="4")]
    pub recipient: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub amount: ::prost::alloc::string::String,
}
/// EventReceiveRemoteTransfer ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventReceiveRemoteTransfer {
    #[prost(string, tag="1")]
    pub token_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub sender: ::prost::alloc::string::String,
    #[prost(uint32, tag="3")]
    pub origin_domain: u32,
    #[prost(string, tag="4")]
    pub recipient: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub amount: ::prost::alloc::string::String,
}
/// QueryTokensRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTokensRequest {
    #[prost(message, optional, tag="1")]
    pub pagination: ::core::option::Option<super::super::super::cosmos::base::query::v1beta1::PageRequest>,
}
/// QueryTokensResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTokensResponse {
    /// params defines the parameters of the module.
    #[prost(message, repeated, tag="1")]
    pub tokens: ::prost::alloc::vec::Vec<WrappedHypToken>,
    /// pagination defines the pagination in the response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::cosmos::base::query::v1beta1::PageResponse>,
}
/// QueryTokenRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTokenRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// QueryTokenResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTokenResponse {
    #[prost(message, optional, tag="1")]
    pub token: ::core::option::Option<WrappedHypToken>,
}
/// WrappedHypToken
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct WrappedHypToken {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(enumeration="HypTokenType", tag="3")]
    pub token_type: i32,
    #[prost(string, tag="4")]
    pub origin_mailbox: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub origin_denom: ::prost::alloc::string::String,
    #[prost(string, tag="7")]
    pub ism_id: ::prost::alloc::string::String,
}
/// QueryBridgedSupplyRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryBridgedSupplyRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// QueryBridgedSupplyResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryBridgedSupplyResponse {
    #[prost(message, optional, tag="1")]
    pub bridged_supply: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
}
/// QueryRemoteRoutersRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRemoteRoutersRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::cosmos::base::query::v1beta1::PageRequest>,
}
/// QueryRemoteRoutersResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRemoteRoutersResponse {
    /// Remote Routers ...
    #[prost(message, repeated, tag="1")]
    pub remote_routers: ::prost::alloc::vec::Vec<RemoteRouter>,
    /// pagination defines the pagination in the response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::cosmos::base::query::v1beta1::PageResponse>,
}
/// QueryQuoteRemoteTransferRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryQuoteRemoteTransferRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub destination_domain: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub custom_hook_id: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub custom_hook_metadata: ::prost::alloc::string::String,
}
/// QueryQuoteRemoteTransferResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryQuoteRemoteTransferResponse {
    #[prost(message, repeated, tag="1")]
    pub gas_payment: ::prost::alloc::vec::Vec<super::super::super::cosmos::base::v1beta1::Coin>,
}
/// GenesisState is the state that must be provided at genesis.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisState {
    #[prost(message, optional, tag="1")]
    pub params: ::core::option::Option<Params>,
    #[prost(message, repeated, tag="2")]
    pub tokens: ::prost::alloc::vec::Vec<HypToken>,
    #[prost(message, repeated, tag="3")]
    pub remote_routers: ::prost::alloc::vec::Vec<GenesisRemoteRouterWrapper>,
}
/// GenesisRemoteRouterWrapper ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisRemoteRouterWrapper {
    #[prost(uint64, tag="1")]
    pub token_id: u64,
    #[prost(message, optional, tag="2")]
    pub remote_router: ::core::option::Option<RemoteRouter>,
}
include!("hyperlane.warp.v1.tonic.rs");
// @@protoc_insertion_point(module)

// @generated
/// Route
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Route {
    /// ism ...
    #[prost(string, tag="1")]
    pub ism: ::prost::alloc::string::String,
    /// domain ...
    #[prost(uint32, tag="2")]
    pub domain: u32,
}
/// Routing ISM ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RoutingIsm {
    /// id ...
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    /// Routes associated with the Routing ISM.
    /// These are stored directly within the ISM to simplify the design,
    /// as the number of routes is expected to remain small.
    /// This approach avoids the added complexity of managing a separate
    /// collection.
    #[prost(message, repeated, tag="3")]
    pub routes: ::prost::alloc::vec::Vec<Route>,
}
/// MessageIdMultisigISM ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MessageIdMultisigIsm {
    /// id ...
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    /// validators
    /// these are 20 byte long ethereum style addresses
    #[prost(string, repeated, tag="3")]
    pub validators: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// threshold ...
    #[prost(uint32, tag="4")]
    pub threshold: u32,
}
/// MerkleRootMultisigISM ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MerkleRootMultisigIsm {
    /// XXX ...
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    /// validators
    /// these are 20 byte long ethereum style addresses
    #[prost(string, repeated, tag="3")]
    pub validators: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// threshold ...
    #[prost(uint32, tag="4")]
    pub threshold: u32,
}
/// NoopISM ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct NoopIsm {
    /// id ...
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
}
/// MsgCreateMessageIdMultisigIsm ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateMessageIdMultisigIsm {
    /// creator is the message sender.
    #[prost(string, tag="1")]
    pub creator: ::prost::alloc::string::String,
    /// validators
    /// these are 20 byte long ethereum style addresses
    #[prost(string, repeated, tag="2")]
    pub validators: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// threshold ...
    #[prost(uint32, tag="3")]
    pub threshold: u32,
}
/// MsgCreateMessageIdMultisigIsmResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateMessageIdMultisigIsmResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// MsgCreateMultisigIsm ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateMerkleRootMultisigIsm {
    /// creator is the message sender.
    #[prost(string, tag="1")]
    pub creator: ::prost::alloc::string::String,
    /// validators
    /// these are 20 byte long ethereum style addresses
    #[prost(string, repeated, tag="2")]
    pub validators: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// threshold ...
    #[prost(uint32, tag="3")]
    pub threshold: u32,
}
/// MsgCreateMultisigIsmResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateMerkleRootMultisigIsmResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// MsgCreateNoopIsm ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateNoopIsm {
    /// creator is the message sender.
    #[prost(string, tag="1")]
    pub creator: ::prost::alloc::string::String,
}
/// MsgCreateNoopIsmResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateNoopIsmResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// MsgAnnounceValidator ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgAnnounceValidator {
    /// validator ...
    #[prost(string, tag="1")]
    pub validator: ::prost::alloc::string::String,
    /// storage_location ...
    #[prost(string, tag="2")]
    pub storage_location: ::prost::alloc::string::String,
    /// signature ...
    #[prost(string, tag="3")]
    pub signature: ::prost::alloc::string::String,
    /// mailbox_id ...
    #[prost(string, tag="4")]
    pub mailbox_id: ::prost::alloc::string::String,
    /// creator ...
    #[prost(string, tag="5")]
    pub creator: ::prost::alloc::string::String,
}
/// MsgAnnounceValidatorResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgAnnounceValidatorResponse {
}
/// MsgCreateRoutingIsm ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateRoutingIsm {
    /// creator ...
    #[prost(string, tag="1")]
    pub creator: ::prost::alloc::string::String,
    /// routes ...
    #[prost(message, repeated, tag="2")]
    pub routes: ::prost::alloc::vec::Vec<Route>,
}
/// MsgCreateRoutingIsmResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateRoutingIsmResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// MsgSetRoutingIsmDomain ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetRoutingIsmDomain {
    /// ism_id ...
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    /// route ...
    #[prost(message, optional, tag="2")]
    pub route: ::core::option::Option<Route>,
    /// owner ...
    #[prost(string, tag="3")]
    pub owner: ::prost::alloc::string::String,
}
/// MsgSetRoutingIsmDomainResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetRoutingIsmDomainResponse {
}
/// MsgRemoveRoutingIsmDomain ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgRemoveRoutingIsmDomain {
    /// ism_id ...
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    /// domain ...
    #[prost(uint32, tag="2")]
    pub domain: u32,
    /// owner ...
    #[prost(string, tag="3")]
    pub owner: ::prost::alloc::string::String,
}
/// MsgRemoveRoutingIsmDomainResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgRemoveRoutingIsmDomainResponse {
}
/// MsgUpdateRoutingIsmOwner ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateRoutingIsmOwner {
    /// ism_id ...
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    /// new owner
    #[prost(string, tag="3")]
    pub new_owner: ::prost::alloc::string::String,
    /// renounce_ownership
    #[prost(bool, tag="4")]
    pub renounce_ownership: bool,
}
/// MsgUpdateRoutingIsmOwnerResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateRoutingIsmOwnerResponse {
}
/// EventCreateNoopIsm ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateNoopIsm {
    /// ism_id ...
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
}
/// EventCreateMerkleRootMultisigIsm ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateMerkleRootMultisigIsm {
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, repeated, tag="3")]
    pub validators: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(uint32, tag="4")]
    pub threshold: u32,
}
/// EventCreateMessageIdMultisigIsm ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateMessageIdMultisigIsm {
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, repeated, tag="3")]
    pub validators: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(uint32, tag="4")]
    pub threshold: u32,
}
/// EventCreateMessageIdMultisigIsm ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventAnnounceStorageLocation {
    #[prost(string, tag="1")]
    pub mailbox_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub sender: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub validator: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub storage_location: ::prost::alloc::string::String,
}
/// EventSetRoutingIsmDomain ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSetRoutingIsmDomain {
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub route_ism_id: ::prost::alloc::string::String,
    #[prost(uint32, tag="4")]
    pub route_domain: u32,
}
/// EventRemoveRoutingIsmDomain ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventRemoveRoutingIsmDomain {
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(uint32, tag="3")]
    pub route_domain: u32,
}
/// EventRemoveRoutingIsmDomain ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSetRoutingIsm {
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub new_owner: ::prost::alloc::string::String,
    #[prost(bool, tag="4")]
    pub renounce_ownership: bool,
}
/// EventCreateMessageIdMultisigIsm ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateRoutingIsm {
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
}
/// QueryIsmsRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIsmsRequest {
    /// pagination defines an optional pagination for the request.
    #[prost(message, optional, tag="1")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageRequest>,
}
/// QueryIsmsResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIsmsResponse {
    #[prost(message, repeated, tag="1")]
    pub isms: ::prost::alloc::vec::Vec<::prost_types::Any>,
    /// pagination defines the pagination in the response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageResponse>,
}
/// QueryIsmRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIsmRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// QueryIsmResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIsmResponse {
    #[prost(message, optional, tag="1")]
    pub ism: ::core::option::Option<::prost_types::Any>,
}
/// QueryAnnouncedStorageLocationsRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAnnouncedStorageLocationsRequest {
    #[prost(string, tag="1")]
    pub mailbox_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub validator_address: ::prost::alloc::string::String,
}
/// QueryAnnouncedStorageLocationsResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAnnouncedStorageLocationsResponse {
    #[prost(string, repeated, tag="1")]
    pub storage_locations: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QueryLatestAnnouncedStorageLocationRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryLatestAnnouncedStorageLocationRequest {
    #[prost(string, tag="1")]
    pub mailbox_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub validator_address: ::prost::alloc::string::String,
}
/// QueryLatestAnnouncedStorageLocationResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryLatestAnnouncedStorageLocationResponse {
    #[prost(string, tag="1")]
    pub storage_location: ::prost::alloc::string::String,
}
/// GenesisState defines the 01_interchain_security submodule's genesis state.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisState {
    /// accounts are the accounts present at genesis.
    #[prost(message, repeated, tag="1")]
    pub isms: ::prost::alloc::vec::Vec<::prost_types::Any>,
    #[prost(message, repeated, tag="2")]
    pub validator_storage_locations: ::prost::alloc::vec::Vec<GenesisValidatorStorageLocationWrapper>,
}
/// GenesisValidatorStorageLocationWrapper stores the information for
/// validator, mailbox and storage-location which validators have announced
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisValidatorStorageLocationWrapper {
    #[prost(uint64, tag="1")]
    pub mailbox_id: u64,
    #[prost(string, tag="2")]
    pub validator_address: ::prost::alloc::string::String,
    #[prost(uint64, tag="3")]
    pub index: u64,
    #[prost(string, tag="4")]
    pub storage_location: ::prost::alloc::string::String,
}
include!("hyperlane.core.interchain_security.v1.tonic.rs");
// @@protoc_insertion_point(module)

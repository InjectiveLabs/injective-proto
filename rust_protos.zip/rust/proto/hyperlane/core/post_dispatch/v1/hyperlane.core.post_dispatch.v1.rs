// @generated
/// InterchainGasPaymaster ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct InterchainGasPaymaster {
    /// id ...
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    /// denom ...
    #[prost(string, tag="3")]
    pub denom: ::prost::alloc::string::String,
    /// claimable_fees ...
    #[prost(message, repeated, tag="4")]
    pub claimable_fees: ::prost::alloc::vec::Vec<super::super::super::super::cosmos::base::v1beta1::Coin>,
}
/// DestinationGasConfig ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DestinationGasConfig {
    /// remote_domain ...
    #[prost(uint32, tag="1")]
    pub remote_domain: u32,
    /// gas_oracle ...
    #[prost(message, optional, tag="2")]
    pub gas_oracle: ::core::option::Option<GasOracle>,
    /// gas_overhead ...
    #[prost(string, tag="3")]
    pub gas_overhead: ::prost::alloc::string::String,
}
/// GasOracle ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GasOracle {
    /// token_exchange_rate ...
    #[prost(string, tag="1")]
    pub token_exchange_rate: ::prost::alloc::string::String,
    /// gas_price ...
    #[prost(string, tag="2")]
    pub gas_price: ::prost::alloc::string::String,
}
/// MerkleTreeHook ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MerkleTreeHook {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub mailbox_id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="3")]
    pub owner: ::prost::alloc::string::String,
    /// tree ...
    #[prost(message, optional, tag="4")]
    pub tree: ::core::option::Option<Tree>,
}
/// Tree represents an incremental merkle tree.
/// Contains current branch and the number of inserted leaves in the tree.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Tree {
    /// branch ...
    #[prost(bytes="vec", repeated, tag="1")]
    pub branch: ::prost::alloc::vec::Vec<::prost::alloc::vec::Vec<u8>>,
    /// count ...
    #[prost(uint32, tag="2")]
    pub count: u32,
}
/// NoopHook ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct NoopHook {
    /// id ...
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
}
/// MsgCreateIgp ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateIgp {
    /// owner is the message sender.
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    /// denom
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
}
/// MsgCreateIgpResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateIgpResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// MsgSetIgpOwner ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetIgpOwner {
    /// owner is the message sender.
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    /// igp_id
    #[prost(string, tag="2")]
    pub igp_id: ::prost::alloc::string::String,
    /// new_owner
    #[prost(string, tag="3")]
    pub new_owner: ::prost::alloc::string::String,
    /// renounce_ownership
    #[prost(bool, tag="4")]
    pub renounce_ownership: bool,
}
/// MsgCreateIgpResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetIgpOwnerResponse {
}
/// MsgSetDestinationGasConfig ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetDestinationGasConfig {
    /// owner ...
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    /// igp_id ...
    #[prost(string, tag="2")]
    pub igp_id: ::prost::alloc::string::String,
    /// destination_gas_config ...
    #[prost(message, optional, tag="3")]
    pub destination_gas_config: ::core::option::Option<DestinationGasConfig>,
}
/// MsgSetDestinationGasConfigResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetDestinationGasConfigResponse {
}
/// MsgPayForGas ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgPayForGas {
    /// sender ...
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// igp_id ...
    #[prost(string, tag="2")]
    pub igp_id: ::prost::alloc::string::String,
    /// message_id ...
    #[prost(string, tag="3")]
    pub message_id: ::prost::alloc::string::String,
    /// destination_domain ...
    #[prost(uint32, tag="4")]
    pub destination_domain: u32,
    /// gas_limit ...
    #[prost(string, tag="5")]
    pub gas_limit: ::prost::alloc::string::String,
    /// amount ...
    #[prost(message, optional, tag="6")]
    pub amount: ::core::option::Option<super::super::super::super::cosmos::base::v1beta1::Coin>,
}
/// MsgPayForGasResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgPayForGasResponse {
}
/// MsgClaim ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgClaim {
    /// sender ...
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// igp_id ...
    #[prost(string, tag="2")]
    pub igp_id: ::prost::alloc::string::String,
}
/// MsgClaimResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgClaimResponse {
}
/// MsgMerkleTreeHook ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateMerkleTreeHook {
    /// sender ...
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub mailbox_id: ::prost::alloc::string::String,
}
/// MsgCreateMerkleTreeHookResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateMerkleTreeHookResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// MsgMerkleTreeHook ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateNoopHook {
    /// sender ...
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
}
/// MsgCreateMerkleTreeHookResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateNoopHookResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// EventCreateMerkleTreeHook ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateMerkleTreeHook {
    /// id ...
    #[prost(string, tag="1")]
    pub merkle_tree_hook_id: ::prost::alloc::string::String,
    /// mailbox_id ...
    #[prost(string, tag="2")]
    pub mailbox_id: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub owner: ::prost::alloc::string::String,
}
/// EventInsertedIntoTree ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventInsertedIntoTree {
    /// message_id ...
    #[prost(string, tag="1")]
    pub message_id: ::prost::alloc::string::String,
    /// index ...
    #[prost(uint32, tag="2")]
    pub index: u32,
    /// merkle_tree_hook_id ...
    #[prost(string, tag="3")]
    pub merkle_tree_hook_id: ::prost::alloc::string::String,
}
/// EventGasPayment ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventGasPayment {
    /// message_id ...
    #[prost(string, tag="1")]
    pub message_id: ::prost::alloc::string::String,
    /// destination ...
    #[prost(uint32, tag="2")]
    pub destination: u32,
    /// gas_amount ...
    #[prost(string, tag="3")]
    pub gas_amount: ::prost::alloc::string::String,
    /// payment ...
    #[prost(string, tag="4")]
    pub payment: ::prost::alloc::string::String,
    /// igp_id ...
    #[prost(string, tag="5")]
    pub igp_id: ::prost::alloc::string::String,
}
/// EventCreateNoopHook ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateNoopHook {
    /// id ...
    #[prost(string, tag="1")]
    pub noop_hook_id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
}
/// EventCreateIgp ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateIgp {
    #[prost(string, tag="1")]
    pub igp_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub denom: ::prost::alloc::string::String,
}
/// EventSetIgp ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSetIgp {
    #[prost(string, tag="1")]
    pub igp_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub new_owner: ::prost::alloc::string::String,
    #[prost(bool, tag="4")]
    pub renounce_ownership: bool,
}
/// EventSetDestinationGasConfig ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSetDestinationGasConfig {
    #[prost(string, tag="1")]
    pub igp_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(uint32, tag="4")]
    pub remote_domain: u32,
    #[prost(string, tag="5")]
    pub gas_overhead: ::prost::alloc::string::String,
    #[prost(string, tag="6")]
    pub gas_price: ::prost::alloc::string::String,
    #[prost(string, tag="7")]
    pub token_exchange_rate: ::prost::alloc::string::String,
}
/// EventClaimIgp ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventClaimIgp {
    #[prost(string, tag="1")]
    pub igp_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub amount: ::prost::alloc::string::String,
}
/// QueryIgpsRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIgpsRequest {
    /// pagination defines an optional pagination for the request.
    #[prost(message, optional, tag="1")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageRequest>,
}
/// QueryIgpsResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIgpsResponse {
    #[prost(message, repeated, tag="1")]
    pub igps: ::prost::alloc::vec::Vec<InterchainGasPaymaster>,
    /// pagination defines the pagination in the response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageResponse>,
}
/// QueryIgpRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIgpRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// QueryIgpResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIgpResponse {
    #[prost(message, optional, tag="1")]
    pub igp: ::core::option::Option<InterchainGasPaymaster>,
}
/// QueryDestinationGasConfigsRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDestinationGasConfigsRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    /// pagination defines an optional pagination for the request.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageRequest>,
}
/// QueryDestinationGasConfigsResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDestinationGasConfigsResponse {
    #[prost(message, repeated, tag="1")]
    pub destination_gas_configs: ::prost::alloc::vec::Vec<DestinationGasConfig>,
    /// pagination defines the pagination in the response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageResponse>,
}
/// QueryQuoteGasPaymentRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryQuoteGasPaymentRequest {
    #[prost(string, tag="1")]
    pub igp_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub destination_domain: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub gas_limit: ::prost::alloc::string::String,
}
/// QueryQuoteGasPaymentResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryQuoteGasPaymentResponse {
    #[prost(message, repeated, tag="1")]
    pub gas_payment: ::prost::alloc::vec::Vec<super::super::super::super::cosmos::base::v1beta1::Coin>,
}
/// QueryMerkleTreeHooksRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMerkleTreeHooksRequest {
    #[prost(message, optional, tag="1")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageRequest>,
}
/// QueryMerkleTreeHooksResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMerkleTreeHooksResponse {
    #[prost(message, repeated, tag="1")]
    pub merkle_tree_hooks: ::prost::alloc::vec::Vec<WrappedMerkleTreeHookResponse>,
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageResponse>,
}
/// QueryMerkleTreeHookRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMerkleTreeHookRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// QueryMerkleTreeHookResponse
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMerkleTreeHookResponse {
    #[prost(message, optional, tag="1")]
    pub merkle_tree_hook: ::core::option::Option<WrappedMerkleTreeHookResponse>,
}
/// WrappedMerkleTreeHookResponse
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct WrappedMerkleTreeHookResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub mailbox_id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="4")]
    pub merkle_tree: ::core::option::Option<TreeResponse>,
}
/// TreeResponse
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TreeResponse {
    /// leafs ...
    #[prost(bytes="vec", repeated, tag="1")]
    pub leafs: ::prost::alloc::vec::Vec<::prost::alloc::vec::Vec<u8>>,
    /// count ...
    #[prost(uint32, tag="2")]
    pub count: u32,
    /// root ...
    #[prost(bytes="vec", tag="3")]
    pub root: ::prost::alloc::vec::Vec<u8>,
}
/// QueryNoopHookRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryNoopHookRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// QueryNoopHookResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryNoopHookResponse {
    #[prost(message, optional, tag="1")]
    pub noop_hook: ::core::option::Option<NoopHook>,
}
/// QueryNoopHooksRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryNoopHooksRequest {
    #[prost(message, optional, tag="1")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageRequest>,
}
/// QueryNoopHooksResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryNoopHooksResponse {
    #[prost(message, repeated, tag="1")]
    pub noop_hooks: ::prost::alloc::vec::Vec<NoopHook>,
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::super::cosmos::base::query::v1beta1::PageResponse>,
}
/// GenesisState defines the post dispatch submodule's genesis state.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisState {
    #[prost(message, repeated, tag="1")]
    pub igps: ::prost::alloc::vec::Vec<InterchainGasPaymaster>,
    #[prost(message, repeated, tag="2")]
    pub igp_gas_configs: ::prost::alloc::vec::Vec<GenesisDestinationGasConfigWrapper>,
    #[prost(message, repeated, tag="3")]
    pub merkle_tree_hooks: ::prost::alloc::vec::Vec<MerkleTreeHook>,
    #[prost(message, repeated, tag="4")]
    pub noop_hooks: ::prost::alloc::vec::Vec<NoopHook>,
}
/// GenesisDestinationGasConfigWrapper ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisDestinationGasConfigWrapper {
    /// remote_domain ...
    #[prost(uint32, tag="1")]
    pub remote_domain: u32,
    /// gas_oracle ...
    #[prost(message, optional, tag="2")]
    pub gas_oracle: ::core::option::Option<GasOracle>,
    /// gas_overhead ...
    #[prost(string, tag="3")]
    pub gas_overhead: ::prost::alloc::string::String,
    /// igp_id is required for the Genesis handling.
    #[prost(uint64, tag="4")]
    pub igp_id: u64,
}
include!("hyperlane.core.post_dispatch.v1.tonic.rs");
// @@protoc_insertion_point(module)

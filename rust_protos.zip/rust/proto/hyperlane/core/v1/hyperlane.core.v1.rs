// @generated
/// MsgCreateMailbox ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateMailbox {
    /// owner is the message sender.
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    /// local domain
    #[prost(uint32, tag="2")]
    pub local_domain: u32,
    #[prost(string, tag="3")]
    pub default_ism: ::prost::alloc::string::String,
    /// default_hook ...
    #[prost(string, tag="4")]
    pub default_hook: ::prost::alloc::string::String,
    /// required_hook ...
    #[prost(string, tag="5")]
    pub required_hook: ::prost::alloc::string::String,
}
/// MsgCreateMailboxResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateMailboxResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// MsgSetMailbox ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetMailbox {
    /// owner is the message sender.
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    /// mailbox_id
    #[prost(string, tag="2")]
    pub mailbox_id: ::prost::alloc::string::String,
    /// default_ism ...
    #[prost(string, tag="3")]
    pub default_ism: ::prost::alloc::string::String,
    /// default_hook ...
    #[prost(string, tag="4")]
    pub default_hook: ::prost::alloc::string::String,
    /// required_hook ...
    #[prost(string, tag="5")]
    pub required_hook: ::prost::alloc::string::String,
    /// new_owner ...
    #[prost(string, tag="6")]
    pub new_owner: ::prost::alloc::string::String,
    /// renounce_ownership
    #[prost(bool, tag="7")]
    pub renounce_ownership: bool,
}
/// MsgSetMailboxResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSetMailboxResponse {
}
/// MsgProcessMessage ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgProcessMessage {
    /// mailbox_id ...
    #[prost(string, tag="1")]
    pub mailbox_id: ::prost::alloc::string::String,
    /// relayer ...
    #[prost(string, tag="2")]
    pub relayer: ::prost::alloc::string::String,
    /// metadata ...
    #[prost(string, tag="3")]
    pub metadata: ::prost::alloc::string::String,
    /// message ...
    #[prost(string, tag="4")]
    pub message: ::prost::alloc::string::String,
}
/// MsgProcessMessageResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgProcessMessageResponse {
}
/// EventDispatch ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventDispatch {
    /// origin_mailbox_id ...
    #[prost(string, tag="1")]
    pub origin_mailbox_id: ::prost::alloc::string::String,
    /// sender ...
    #[prost(string, tag="2")]
    pub sender: ::prost::alloc::string::String,
    /// destination ...
    #[prost(uint32, tag="3")]
    pub destination: u32,
    /// recipient ...
    #[prost(string, tag="4")]
    pub recipient: ::prost::alloc::string::String,
    /// message ...
    #[prost(string, tag="5")]
    pub message: ::prost::alloc::string::String,
}
/// EventProcess ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventProcess {
    /// origin_mailbox_id ...
    #[prost(string, tag="1")]
    pub origin_mailbox_id: ::prost::alloc::string::String,
    /// origin ...
    #[prost(uint32, tag="2")]
    pub origin: u32,
    /// sender ...
    #[prost(string, tag="3")]
    pub sender: ::prost::alloc::string::String,
    /// recipient ...
    #[prost(string, tag="4")]
    pub recipient: ::prost::alloc::string::String,
    /// message_id ...
    #[prost(string, tag="5")]
    pub message_id: ::prost::alloc::string::String,
    /// message ...
    #[prost(string, tag="6")]
    pub message: ::prost::alloc::string::String,
}
/// EventCreateMailbox ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateMailbox {
    /// mailbox_id ...
    #[prost(string, tag="1")]
    pub mailbox_id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    /// default_ism ...
    #[prost(string, tag="3")]
    pub default_ism: ::prost::alloc::string::String,
    /// default_hook ...
    #[prost(string, tag="4")]
    pub default_hook: ::prost::alloc::string::String,
    /// required_hook ...
    #[prost(string, tag="5")]
    pub required_hook: ::prost::alloc::string::String,
    /// local_domain ...
    #[prost(uint32, tag="6")]
    pub local_domain: u32,
}
/// EventSetMailbox ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSetMailbox {
    /// mailbox_id ...
    #[prost(string, tag="1")]
    pub mailbox_id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    /// default_ism ...
    #[prost(string, tag="3")]
    pub default_ism: ::prost::alloc::string::String,
    /// default_hook ...
    #[prost(string, tag="4")]
    pub default_hook: ::prost::alloc::string::String,
    /// new_owner ...
    #[prost(string, tag="5")]
    pub new_owner: ::prost::alloc::string::String,
    /// renounce_ownership ...
    #[prost(bool, tag="6")]
    pub renounce_ownership: bool,
}
/// Mailbox ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Mailbox {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    /// owner ...
    #[prost(string, tag="2")]
    pub owner: ::prost::alloc::string::String,
    /// message_sent ...
    #[prost(uint32, tag="3")]
    pub message_sent: u32,
    /// message_received ...
    #[prost(uint32, tag="4")]
    pub message_received: u32,
    /// default_ism ...
    #[prost(string, tag="5")]
    pub default_ism: ::prost::alloc::string::String,
    /// default_hook
    #[prost(string, tag="6")]
    pub default_hook: ::prost::alloc::string::String,
    /// required_hook
    #[prost(string, tag="7")]
    pub required_hook: ::prost::alloc::string::String,
    /// domain
    #[prost(uint32, tag="8")]
    pub local_domain: u32,
}
/// QueryMailboxesRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMailboxesRequest {
    /// pagination defines an optional pagination for the request.
    #[prost(message, optional, tag="1")]
    pub pagination: ::core::option::Option<super::super::super::cosmos::base::query::v1beta1::PageRequest>,
}
/// QueryMailboxesResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMailboxesResponse {
    #[prost(message, repeated, tag="1")]
    pub mailboxes: ::prost::alloc::vec::Vec<Mailbox>,
    /// pagination defines the pagination in the response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::super::super::cosmos::base::query::v1beta1::PageResponse>,
}
/// QueryMailboxRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMailboxRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
/// QueryMailboxResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMailboxResponse {
    #[prost(message, optional, tag="1")]
    pub mailbox: ::core::option::Option<Mailbox>,
}
/// QueryDeliveredRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDeliveredRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub message_id: ::prost::alloc::string::String,
}
/// QueryDeliveredResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDeliveredResponse {
    #[prost(bool, tag="1")]
    pub delivered: bool,
}
/// QueryRecipientIsmRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRecipientIsmRequest {
    #[prost(string, tag="1")]
    pub recipient: ::prost::alloc::string::String,
}
/// QueryRecipientIsmResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRecipientIsmResponse {
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
}
/// QueryVerifyDryRunRequest ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryVerifyDryRunRequest {
    #[prost(string, tag="1")]
    pub ism_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub message: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub metadata: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub gas_limit: ::prost::alloc::string::String,
}
/// QueryVerifyDryRunResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryVerifyDryRunResponse {
    #[prost(bool, tag="1")]
    pub verified: bool,
}
/// QueryRegisteredISMs ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRegisteredIsMs {
}
/// QueryRegisteredISMsResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRegisteredIsMsResponse {
    #[prost(uint32, repeated, tag="1")]
    pub ids: ::prost::alloc::vec::Vec<u32>,
}
/// QueryRegisteredHooks ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRegisteredHooks {
}
/// QueryRegisteredHooksResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRegisteredHooksResponse {
    #[prost(uint32, repeated, tag="1")]
    pub ids: ::prost::alloc::vec::Vec<u32>,
}
/// QueryRegisteredApps ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRegisteredApps {
}
/// QueryRegisteredAppsResponse ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryRegisteredAppsResponse {
    #[prost(uint32, repeated, tag="1")]
    pub ids: ::prost::alloc::vec::Vec<u32>,
}
/// GenesisState is the state that must be provided at genesis.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisState {
    /// ism_genesis
    #[prost(message, optional, tag="1")]
    pub ism_genesis: ::core::option::Option<super::interchain_security::v1::GenesisState>,
    /// post_dispatch_genesis
    #[prost(message, optional, tag="2")]
    pub post_dispatch_genesis: ::core::option::Option<super::post_dispatch::v1::GenesisState>,
    #[prost(message, repeated, tag="3")]
    pub mailboxes: ::prost::alloc::vec::Vec<Mailbox>,
    #[prost(message, repeated, tag="4")]
    pub messages: ::prost::alloc::vec::Vec<GenesisMailboxMessageWrapper>,
    #[prost(uint64, tag="5")]
    pub ism_sequence: u64,
    #[prost(uint64, tag="6")]
    pub post_dispatch_sequence: u64,
    #[prost(uint64, tag="7")]
    pub app_sequence: u64,
}
/// GenesisMailboxMessageWrapper ...
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisMailboxMessageWrapper {
    #[prost(uint64, tag="1")]
    pub mailbox_id: u64,
    #[prost(string, tag="2")]
    pub message_id: ::prost::alloc::string::String,
}
include!("hyperlane.core.v1.tonic.rs");
// @@protoc_insertion_point(module)

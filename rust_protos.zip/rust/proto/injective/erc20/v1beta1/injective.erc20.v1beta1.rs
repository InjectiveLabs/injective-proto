// @generated
/// Params defines the parameters for the erc20 module.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Params {
}
/// TokenPair defines an association of bank denom <-> EVM token (erc20 contract
/// address)
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TokenPair {
    /// bank denom
    #[prost(string, tag="1")]
    pub bank_denom: ::prost::alloc::string::String,
    /// address of erc20 smart contract that is backed by
    #[prost(string, tag="2")]
    pub erc20_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateParams {
    /// authority is the address of the governance account.
    #[prost(string, tag="1")]
    pub authority: ::prost::alloc::string::String,
    /// params defines the erc20 parameters to update.
    ///
    /// NOTE: All parameters must be supplied.
    #[prost(message, optional, tag="2")]
    pub params: ::core::option::Option<Params>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateParamsResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateTokenPair {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub token_pair: ::core::option::Option<TokenPair>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateTokenPairResponse {
    #[prost(message, optional, tag="1")]
    pub token_pair: ::core::option::Option<TokenPair>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDeleteTokenPair {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// bank denom of the pair to be deleted
    #[prost(string, tag="2")]
    pub bank_denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDeleteTokenPairResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCreateTokenPair {
    #[prost(string, tag="1")]
    pub bank_denom: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub erc20_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventDeleteTokenPair {
    #[prost(string, tag="1")]
    pub bank_denom: ::prost::alloc::string::String,
}
/// GenesisState defines the erc20 module's genesis state.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisState {
    /// params defines the parameters of the module.
    #[prost(message, optional, tag="1")]
    pub params: ::core::option::Option<Params>,
    #[prost(message, repeated, tag="2")]
    pub token_pairs: ::prost::alloc::vec::Vec<TokenPair>,
}
/// QueryParamsRequest is the request type for the Query/Params RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryParamsRequest {
}
/// QueryParamsResponse is the response type for the Query/Params RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryParamsResponse {
    /// params defines the parameters of the module.
    #[prost(message, optional, tag="1")]
    pub params: ::core::option::Option<Params>,
}
/// QueryAllTokenPairsRequest is the request type for the Query/AllTokenPairs RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAllTokenPairsRequest {
}
/// QueryAllTokenPairsResponse is the response type for the Query/AllTokenPairs
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAllTokenPairsResponse {
    #[prost(message, repeated, tag="1")]
    pub token_pairs: ::prost::alloc::vec::Vec<TokenPair>,
}
/// QueryTokenPairByDenomRequest is the request type for the
/// Query/TokenPairByDenom RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTokenPairByDenomRequest {
    #[prost(string, tag="1")]
    pub bank_denom: ::prost::alloc::string::String,
}
/// QueryTokenPairByDenomResponse is the response type for the
/// Query/TokenPairByDenom RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTokenPairByDenomResponse {
    #[prost(message, optional, tag="1")]
    pub token_pair: ::core::option::Option<TokenPair>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTokenPairByErc20AddressRequest {
    #[prost(string, tag="1")]
    pub erc20_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTokenPairByErc20AddressResponse {
    #[prost(message, optional, tag="1")]
    pub token_pair: ::core::option::Option<TokenPair>,
}
include!("injective.erc20.v1beta1.tonic.rs");
// @@protoc_insertion_point(module)

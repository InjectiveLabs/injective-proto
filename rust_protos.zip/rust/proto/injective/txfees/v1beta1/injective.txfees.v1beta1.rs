// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Params {
    #[prost(uint64, tag="1")]
    pub max_gas_wanted_per_tx: u64,
    #[prost(uint64, tag="2")]
    pub high_gas_tx_threshold: u64,
    #[prost(string, tag="3")]
    pub min_gas_price_for_high_gas_tx: ::prost::alloc::string::String,
    #[prost(bool, tag="4")]
    pub mempool1559_enabled: bool,
    #[prost(string, tag="5")]
    pub min_gas_price: ::prost::alloc::string::String,
    #[prost(string, tag="6")]
    pub default_base_fee_multiplier: ::prost::alloc::string::String,
    #[prost(string, tag="7")]
    pub max_base_fee_multiplier: ::prost::alloc::string::String,
    #[prost(int64, tag="8")]
    pub reset_interval: i64,
    #[prost(string, tag="9")]
    pub max_block_change_rate: ::prost::alloc::string::String,
    #[prost(string, tag="10")]
    pub target_block_space_percent_rate: ::prost::alloc::string::String,
    #[prost(string, tag="11")]
    pub recheck_fee_low_base_fee: ::prost::alloc::string::String,
    #[prost(string, tag="12")]
    pub recheck_fee_high_base_fee: ::prost::alloc::string::String,
    #[prost(string, tag="13")]
    pub recheck_fee_base_fee_threshold_multiplier: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateParams {
    /// authority is the address of the governance account.
    #[prost(string, tag="1")]
    pub authority: ::prost::alloc::string::String,
    /// params defines the ocr parameters to update.
    ///
    /// NOTE: All parameters must be supplied.
    #[prost(message, optional, tag="2")]
    pub params: ::core::option::Option<Params>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateParamsResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EipBaseFee {
    #[prost(string, tag="1")]
    pub base_fee: ::prost::alloc::string::String,
}
/// QueryParamsRequest is the request type for the Query/Params RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryParamsRequest {
}
/// QueryParamsResponse is the response type for the Query/Params RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryParamsResponse {
    /// params defines the parameters of the module.
    #[prost(message, optional, tag="1")]
    pub params: ::core::option::Option<Params>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryEipBaseFeeRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryEipBaseFeeResponse {
    #[prost(message, optional, tag="1")]
    pub base_fee: ::core::option::Option<EipBaseFee>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisState {
    #[prost(message, optional, tag="1")]
    pub params: ::core::option::Option<Params>,
}
include!("injective.txfees.v1beta1.tonic.rs");
// @@protoc_insertion_point(module)

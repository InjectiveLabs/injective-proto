// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamRequest {
    /// filter for bank balances events
    #[prost(message, optional, tag="1")]
    pub bank_balances_filter: ::core::option::Option<BankBalancesFilter>,
    /// filter for subaccount deposits events
    #[prost(message, optional, tag="2")]
    pub subaccount_deposits_filter: ::core::option::Option<SubaccountDepositsFilter>,
    /// filter for spot trades events
    #[prost(message, optional, tag="3")]
    pub spot_trades_filter: ::core::option::Option<TradesFilter>,
    /// filter for derivative trades events
    #[prost(message, optional, tag="4")]
    pub derivative_trades_filter: ::core::option::Option<TradesFilter>,
    /// filter for spot orders events
    #[prost(message, optional, tag="5")]
    pub spot_orders_filter: ::core::option::Option<OrdersFilter>,
    /// filter for derivative orders events
    #[prost(message, optional, tag="6")]
    pub derivative_orders_filter: ::core::option::Option<OrdersFilter>,
    /// filter for spot orderbooks events
    #[prost(message, optional, tag="7")]
    pub spot_orderbooks_filter: ::core::option::Option<OrderbookFilter>,
    /// filter for derivative orderbooks events
    #[prost(message, optional, tag="8")]
    pub derivative_orderbooks_filter: ::core::option::Option<OrderbookFilter>,
    /// filter for positions events
    #[prost(message, optional, tag="9")]
    pub positions_filter: ::core::option::Option<PositionsFilter>,
    /// filter for oracle prices events
    #[prost(message, optional, tag="10")]
    pub oracle_price_filter: ::core::option::Option<OraclePriceFilter>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamResponse {
    /// the block height
    #[prost(uint64, tag="1")]
    pub block_height: u64,
    /// the block time
    #[prost(int64, tag="2")]
    pub block_time: i64,
    /// list of bank balances updates
    #[prost(message, repeated, tag="3")]
    pub bank_balances: ::prost::alloc::vec::Vec<BankBalance>,
    /// list of subaccount deposits updates
    #[prost(message, repeated, tag="4")]
    pub subaccount_deposits: ::prost::alloc::vec::Vec<SubaccountDeposits>,
    /// list of spot trades updates
    #[prost(message, repeated, tag="5")]
    pub spot_trades: ::prost::alloc::vec::Vec<SpotTrade>,
    /// list of derivative trades updates
    #[prost(message, repeated, tag="6")]
    pub derivative_trades: ::prost::alloc::vec::Vec<DerivativeTrade>,
    /// list of spot orders updates
    #[prost(message, repeated, tag="7")]
    pub spot_orders: ::prost::alloc::vec::Vec<SpotOrderUpdate>,
    /// list of derivative orders updates
    #[prost(message, repeated, tag="8")]
    pub derivative_orders: ::prost::alloc::vec::Vec<DerivativeOrderUpdate>,
    /// list of spot orderbook updates
    #[prost(message, repeated, tag="9")]
    pub spot_orderbook_updates: ::prost::alloc::vec::Vec<OrderbookUpdate>,
    /// list of derivative orderbook updates
    #[prost(message, repeated, tag="10")]
    pub derivative_orderbook_updates: ::prost::alloc::vec::Vec<OrderbookUpdate>,
    /// list of positions updates
    #[prost(message, repeated, tag="11")]
    pub positions: ::prost::alloc::vec::Vec<Position>,
    /// list of oracle prices updates
    #[prost(message, repeated, tag="12")]
    pub oracle_prices: ::prost::alloc::vec::Vec<OraclePrice>,
    /// the current gas price when the block was processed (in chain format)
    #[prost(string, tag="13")]
    pub gas_price: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrderbookUpdate {
    /// the sequence number of the orderbook update
    #[prost(uint64, tag="1")]
    pub seq: u64,
    /// the orderbook details
    #[prost(message, optional, tag="2")]
    pub orderbook: ::core::option::Option<Orderbook>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Orderbook {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// list of buy levels
    #[prost(message, repeated, tag="2")]
    pub buy_levels: ::prost::alloc::vec::Vec<super::super::exchange::v2::Level>,
    /// list of sell levels
    #[prost(message, repeated, tag="3")]
    pub sell_levels: ::prost::alloc::vec::Vec<super::super::exchange::v2::Level>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BankBalance {
    /// the account address
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
    /// list of account balances
    #[prost(message, repeated, tag="2")]
    pub balances: ::prost::alloc::vec::Vec<super::super::super::cosmos::base::v1beta1::Coin>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountDeposits {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the deposits details
    #[prost(message, repeated, tag="2")]
    pub deposits: ::prost::alloc::vec::Vec<SubaccountDeposit>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountDeposit {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub deposit: ::core::option::Option<super::super::exchange::v2::Deposit>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotOrderUpdate {
    /// the status of the order
    #[prost(enumeration="OrderUpdateStatus", tag="1")]
    pub status: i32,
    /// the order hash
    #[prost(string, tag="2")]
    pub order_hash: ::prost::alloc::string::String,
    /// the client order ID
    #[prost(string, tag="3")]
    pub cid: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="4")]
    pub order: ::core::option::Option<SpotOrder>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotOrder {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<super::super::exchange::v2::SpotLimitOrder>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeOrderUpdate {
    /// the status of the order
    #[prost(enumeration="OrderUpdateStatus", tag="1")]
    pub status: i32,
    /// the order hash
    #[prost(string, tag="2")]
    pub order_hash: ::prost::alloc::string::String,
    /// the client order ID
    #[prost(string, tag="3")]
    pub cid: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="4")]
    pub order: ::core::option::Option<DerivativeOrder>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeOrder {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<super::super::exchange::v2::DerivativeLimitOrder>,
    /// whether the order is a market order
    #[prost(bool, tag="3")]
    pub is_market: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Position {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// the subaccount ID
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// whether the position is long or short
    #[prost(bool, tag="3")]
    pub is_long: bool,
    /// the quantity of the position (in human readable format)
    #[prost(string, tag="4")]
    pub quantity: ::prost::alloc::string::String,
    /// the entry price of the position (in human readable format)
    #[prost(string, tag="5")]
    pub entry_price: ::prost::alloc::string::String,
    /// the margin of the position (in human readable format)
    #[prost(string, tag="6")]
    pub margin: ::prost::alloc::string::String,
    /// the cumulative funding entry of the position (in human readable format)
    #[prost(string, tag="7")]
    pub cumulative_funding_entry: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OraclePrice {
    /// the symbol of the oracle price
    #[prost(string, tag="1")]
    pub symbol: ::prost::alloc::string::String,
    /// the updated price
    #[prost(string, tag="2")]
    pub price: ::prost::alloc::string::String,
    /// the oracle type
    #[prost(string, tag="3")]
    pub r#type: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotTrade {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// whether the trade is a buy or sell
    #[prost(bool, tag="2")]
    pub is_buy: bool,
    /// the execution type
    #[prost(string, tag="3")]
    pub execution_type: ::prost::alloc::string::String,
    /// the quantity of the trade (in human readable format)
    #[prost(string, tag="4")]
    pub quantity: ::prost::alloc::string::String,
    /// the price of the trade (in human readable format)
    #[prost(string, tag="5")]
    pub price: ::prost::alloc::string::String,
    /// the subaccount ID that executed the trade
    #[prost(string, tag="6")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the fee of the trade (in human readable format)
    #[prost(string, tag="7")]
    pub fee: ::prost::alloc::string::String,
    /// the order hash
    #[prost(string, tag="8")]
    pub order_hash: ::prost::alloc::string::String,
    /// the fee recipient address
    #[prost(string, tag="9")]
    pub fee_recipient_address: ::prost::alloc::string::String,
    /// the client order ID
    #[prost(string, tag="10")]
    pub cid: ::prost::alloc::string::String,
    /// the trade ID
    #[prost(string, tag="11")]
    pub trade_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeTrade {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// whether the trade is a buy or sell
    #[prost(bool, tag="2")]
    pub is_buy: bool,
    /// the execution type
    #[prost(string, tag="3")]
    pub execution_type: ::prost::alloc::string::String,
    /// the subaccount ID
    #[prost(string, tag="4")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the position delta of the trade (in human readable format)
    #[prost(message, optional, tag="5")]
    pub position_delta: ::core::option::Option<super::super::exchange::v2::PositionDelta>,
    /// the payout of the trade (in human readable format)
    #[prost(string, tag="6")]
    pub payout: ::prost::alloc::string::String,
    /// the fee of the trade (in human readable format)
    #[prost(string, tag="7")]
    pub fee: ::prost::alloc::string::String,
    /// the order hash
    #[prost(string, tag="8")]
    pub order_hash: ::prost::alloc::string::String,
    /// the fee recipient address
    #[prost(string, tag="9")]
    pub fee_recipient_address: ::prost::alloc::string::String,
    /// the client order ID
    #[prost(string, tag="10")]
    pub cid: ::prost::alloc::string::String,
    /// the trade ID
    #[prost(string, tag="11")]
    pub trade_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradesFilter {
    /// list of subaccount IDs to filter by
    #[prost(string, repeated, tag="1")]
    pub subaccount_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// list of market IDs to filter by
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PositionsFilter {
    /// list of subaccount IDs to filter by
    #[prost(string, repeated, tag="1")]
    pub subaccount_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// list of market IDs to filter by
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrdersFilter {
    /// list of subaccount IDs to filter by
    #[prost(string, repeated, tag="1")]
    pub subaccount_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// list of market IDs to filter by
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrderbookFilter {
    /// list of market IDs to filter by
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BankBalancesFilter {
    /// list of account addresses to filter by
    #[prost(string, repeated, tag="1")]
    pub accounts: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountDepositsFilter {
    /// list of subaccount IDs to filter by
    #[prost(string, repeated, tag="1")]
    pub subaccount_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OraclePriceFilter {
    /// list of symbol to filter by
    #[prost(string, repeated, tag="1")]
    pub symbol: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum OrderUpdateStatus {
    Unspecified = 0,
    Booked = 1,
    Matched = 2,
    Cancelled = 3,
}
impl OrderUpdateStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            OrderUpdateStatus::Unspecified => "Unspecified",
            OrderUpdateStatus::Booked => "Booked",
            OrderUpdateStatus::Matched => "Matched",
            OrderUpdateStatus::Cancelled => "Cancelled",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Unspecified" => Some(Self::Unspecified),
            "Booked" => Some(Self::Booked),
            "Matched" => Some(Self::Matched),
            "Cancelled" => Some(Self::Cancelled),
            _ => None,
        }
    }
}
include!("injective.stream.v2.tonic.rs");
// @@protoc_insertion_point(module)

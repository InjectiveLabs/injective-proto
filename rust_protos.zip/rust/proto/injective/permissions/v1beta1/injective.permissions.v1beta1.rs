// @generated
/// Params defines the parameters for the permissions module.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Params {
}
/// Namespace defines a permissions namespace
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Namespace {
    /// tokenfactory denom to which this namespace applies to
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    /// address of smart contract to apply code-based restrictions
    #[prost(string, tag="2")]
    pub wasm_hook: ::prost::alloc::string::String,
    #[prost(bool, tag="3")]
    pub mints_paused: bool,
    #[prost(bool, tag="4")]
    pub sends_paused: bool,
    #[prost(bool, tag="5")]
    pub burns_paused: bool,
    /// permissions for each role
    #[prost(map="string, uint32", tag="6")]
    pub role_permissions: ::std::collections::HashMap<::prost::alloc::string::String, u32>,
    #[prost(map="string, message", tag="7")]
    pub address_roles: ::std::collections::HashMap<::prost::alloc::string::String, Roles>,
}
/// Role is only used for storage
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Role {
    #[prost(string, tag="1")]
    pub name: ::prost::alloc::string::String,
    #[prost(uint32, tag="2")]
    pub permissions: u32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Roles {
    #[prost(string, repeated, tag="1")]
    pub roles: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// used in storage
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RoleIDs {
    #[prost(uint32, repeated, tag="1")]
    pub role_ids: ::prost::alloc::vec::Vec<u32>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Voucher {
    #[prost(message, repeated, tag="1")]
    pub coins: ::prost::alloc::vec::Vec<super::super::super::cosmos::base::v1beta1::Coin>,
}
/// each Action enum value should be a power of two
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum Action {
    Unspecified = 0,
    Mint = 1,
    Receive = 2,
    Burn = 4,
}
impl Action {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            Action::Unspecified => "UNSPECIFIED",
            Action::Mint => "MINT",
            Action::Receive => "RECEIVE",
            Action::Burn => "BURN",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "UNSPECIFIED" => Some(Self::Unspecified),
            "MINT" => Some(Self::Mint),
            "RECEIVE" => Some(Self::Receive),
            "BURN" => Some(Self::Burn),
            _ => None,
        }
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateParams {
    /// authority is the address of the governance account.
    #[prost(string, tag="1")]
    pub authority: ::prost::alloc::string::String,
    /// params defines the permissions parameters to update.
    ///
    /// NOTE: All parameters must be supplied.
    #[prost(message, optional, tag="2")]
    pub params: ::core::option::Option<Params>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateParamsResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateNamespace {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub namespace: ::core::option::Option<Namespace>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateNamespaceResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDeleteNamespace {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub namespace_denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDeleteNamespaceResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateNamespace {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// namespace denom to which this updates are applied
    #[prost(string, tag="2")]
    pub namespace_denom: ::prost::alloc::string::String,
    /// address of smart contract to apply code-based restrictions
    #[prost(message, optional, tag="3")]
    pub wasm_hook: ::core::option::Option<msg_update_namespace::MsgSetWasmHook>,
    #[prost(message, optional, tag="4")]
    pub mints_paused: ::core::option::Option<msg_update_namespace::MsgSetMintsPaused>,
    #[prost(message, optional, tag="5")]
    pub sends_paused: ::core::option::Option<msg_update_namespace::MsgSetSendsPaused>,
    #[prost(message, optional, tag="6")]
    pub burns_paused: ::core::option::Option<msg_update_namespace::MsgSetBurnsPaused>,
}
/// Nested message and enum types in `MsgUpdateNamespace`.
pub mod msg_update_namespace {
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct MsgSetWasmHook {
        #[prost(string, tag="1")]
        pub new_value: ::prost::alloc::string::String,
    }
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct MsgSetMintsPaused {
        #[prost(bool, tag="1")]
        pub new_value: bool,
    }
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct MsgSetSendsPaused {
        #[prost(bool, tag="1")]
        pub new_value: bool,
    }
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct MsgSetBurnsPaused {
        #[prost(bool, tag="1")]
        pub new_value: bool,
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateNamespaceResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateNamespaceRoles {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// namespace denom to which this updates are applied
    #[prost(string, tag="2")]
    pub namespace_denom: ::prost::alloc::string::String,
    /// new role definitions or updated permissions for existing roles
    #[prost(map="string, uint32", tag="3")]
    pub role_permissions: ::std::collections::HashMap<::prost::alloc::string::String, u32>,
    /// new addresses to add or new roles for existing addresses to
    #[prost(map="string, message", tag="4")]
    pub address_roles: ::std::collections::HashMap<::prost::alloc::string::String, Roles>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateNamespaceRolesResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgRevokeNamespaceRoles {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// namespace denom to which this updates are applied
    #[prost(string, tag="2")]
    pub namespace_denom: ::prost::alloc::string::String,
    /// map of {"address" => array of roles to revoke from this address}
    #[prost(map="string, message", tag="3")]
    pub address_roles_to_revoke: ::std::collections::HashMap<::prost::alloc::string::String, Roles>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgRevokeNamespaceRolesResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgClaimVoucher {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// address of the original voucher sender (typically a module address,
    #[prost(string, tag="2")]
    pub originator: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgClaimVoucherResponse {
}
/// GenesisState defines the permissions module's genesis state.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisState {
    /// params defines the parameters of the module.
    #[prost(message, optional, tag="1")]
    pub params: ::core::option::Option<Params>,
    #[prost(message, repeated, tag="2")]
    pub namespaces: ::prost::alloc::vec::Vec<Namespace>,
}
/// QueryParamsRequest is the request type for the Query/Params RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryParamsRequest {
}
/// QueryParamsResponse is the response type for the Query/Params RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryParamsResponse {
    /// params defines the parameters of the module.
    #[prost(message, optional, tag="1")]
    pub params: ::core::option::Option<Params>,
}
/// QueryAllNamespacesRequest is the request type for the Query/AllNamespaces RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAllNamespacesRequest {
}
/// QueryAllNamespacesResponse is the response type for the Query/AllNamespaces
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAllNamespacesResponse {
    #[prost(message, repeated, tag="1")]
    pub namespaces: ::prost::alloc::vec::Vec<Namespace>,
}
/// QueryNamespaceByDenomRequest is the request type for the
/// Query/NamespaceByDenom RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryNamespaceByDenomRequest {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub include_roles: bool,
}
/// QueryNamespaceByDenomResponse is the response type for the
/// Query/NamespaceByDenom RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryNamespaceByDenomResponse {
    #[prost(message, optional, tag="1")]
    pub namespace: ::core::option::Option<Namespace>,
}
/// QueryAddressesByRoleRequest is the request type for the Query/AddressesByRole
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAddressesByRoleRequest {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub role: ::prost::alloc::string::String,
}
/// QueryAddressesByRoleResponse is the response type for the
/// Query/AddressesByRole RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAddressesByRoleResponse {
    #[prost(string, repeated, tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAddressRolesRequest {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAddressRolesResponse {
    #[prost(string, repeated, tag="1")]
    pub roles: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryVouchersForAddressRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryVouchersForAddressResponse {
    #[prost(map="string, message", tag="1")]
    pub vouchers: ::std::collections::HashMap<::prost::alloc::string::String, Voucher>,
}
include!("injective.permissions.v1beta1.tonic.rs");
// @@protoc_insertion_point(module)

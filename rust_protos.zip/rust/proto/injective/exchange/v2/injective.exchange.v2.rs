// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ForcePausedInfo {
    #[prost(enumeration="ForcePausedReason", tag="1")]
    pub reason: i32,
    #[prost(string, tag="2")]
    pub mark_price_at_pausing: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OpenNotionalCap {
    #[prost(oneof="open_notional_cap::Cap", tags="1, 2")]
    pub cap: ::core::option::Option<open_notional_cap::Cap>,
}
/// Nested message and enum types in `OpenNotionalCap`.
pub mod open_notional_cap {
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Cap {
        #[prost(message, tag="1")]
        Uncapped(super::OpenNotionalCapUncapped),
        #[prost(message, tag="2")]
        Capped(super::OpenNotionalCapCapped),
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OpenNotionalCapUncapped {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OpenNotionalCapCapped {
    #[prost(string, tag="1")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MarketFeeMultiplier {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub fee_multiplier: ::prost::alloc::string::String,
}
/// An object describing trade pair of two assets.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotMarket {
    /// A name of the pair in format AAA/BBB, where AAA is base asset, BBB is quote
    /// asset.
    #[prost(string, tag="1")]
    pub ticker: ::prost::alloc::string::String,
    /// Coin denom used for the base asset
    #[prost(string, tag="2")]
    pub base_denom: ::prost::alloc::string::String,
    /// Coin used for the quote asset
    #[prost(string, tag="3")]
    pub quote_denom: ::prost::alloc::string::String,
    /// maker_fee_rate defines the fee percentage makers pay when trading
    #[prost(string, tag="4")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the fee percentage takers pay when trading
    #[prost(string, tag="5")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// relayer_fee_share_rate defines the percentage of the transaction fee shared
    /// with the relayer in a derivative market
    #[prost(string, tag="6")]
    pub relayer_fee_share_rate: ::prost::alloc::string::String,
    /// Unique market ID.
    #[prost(string, tag="7")]
    pub market_id: ::prost::alloc::string::String,
    /// Status of the market
    #[prost(enumeration="MarketStatus", tag="8")]
    pub status: i32,
    /// min_price_tick_size defines the minimum tick size that the price required
    /// for orders in the market (in human readable format)
    #[prost(string, tag="9")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the quantity
    /// required for orders in the market (in human readable format)
    #[prost(string, tag="10")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market (in human readable format)
    #[prost(string, tag="11")]
    pub min_notional: ::prost::alloc::string::String,
    /// current market admin
    #[prost(string, tag="12")]
    pub admin: ::prost::alloc::string::String,
    /// level of admin permissions
    #[prost(uint32, tag="13")]
    pub admin_permissions: u32,
    /// base token decimals
    #[prost(uint32, tag="14")]
    pub base_decimals: u32,
    /// quote token decimals
    #[prost(uint32, tag="15")]
    pub quote_decimals: u32,
    /// has_disabled_minimal_protocol_fee indicates whether the minimal protocol
    /// fee is disabled for the market
    #[prost(bool, tag="16")]
    pub has_disabled_minimal_protocol_fee: bool,
}
/// An object describing a binary options market in Injective Protocol.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BinaryOptionsMarket {
    /// Ticker for the derivative contract.
    #[prost(string, tag="1")]
    pub ticker: ::prost::alloc::string::String,
    /// Oracle symbol
    #[prost(string, tag="2")]
    pub oracle_symbol: ::prost::alloc::string::String,
    /// Oracle Provider
    #[prost(string, tag="3")]
    pub oracle_provider: ::prost::alloc::string::String,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="4")]
    pub oracle_type: i32,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="5")]
    pub oracle_scale_factor: u32,
    /// expiration timestamp
    #[prost(int64, tag="6")]
    pub expiration_timestamp: i64,
    /// expiration timestamp
    #[prost(int64, tag="7")]
    pub settlement_timestamp: i64,
    /// admin of the market
    #[prost(string, tag="8")]
    pub admin: ::prost::alloc::string::String,
    /// Address of the quote currency denomination for the binary options contract
    #[prost(string, tag="9")]
    pub quote_denom: ::prost::alloc::string::String,
    /// Unique market ID.
    #[prost(string, tag="10")]
    pub market_id: ::prost::alloc::string::String,
    /// maker_fee_rate defines the maker fee rate of a binary options market
    #[prost(string, tag="11")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the taker fee rate of a derivative market
    #[prost(string, tag="12")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// relayer_fee_share_rate defines the percentage of the transaction fee shared
    /// with the relayer in a derivative market
    #[prost(string, tag="13")]
    pub relayer_fee_share_rate: ::prost::alloc::string::String,
    /// Status of the market
    #[prost(enumeration="MarketStatus", tag="14")]
    pub status: i32,
    /// min_price_tick_size defines the minimum tick size that the price and margin
    /// required for orders in the market (in human readable format)
    #[prost(string, tag="15")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the quantity
    /// required for orders in the market (in human readable format)
    #[prost(string, tag="16")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// settlement_price defines the settlement price of the binary options market
    /// (in human readable format)
    #[prost(string, tag="17")]
    pub settlement_price: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market (in human readable format)
    #[prost(string, tag="18")]
    pub min_notional: ::prost::alloc::string::String,
    /// level of admin permissions
    #[prost(uint32, tag="19")]
    pub admin_permissions: u32,
    /// quote token decimals
    #[prost(uint32, tag="20")]
    pub quote_decimals: u32,
    /// open_notional_cap defines the maximum open notional for the market
    #[prost(message, optional, tag="21")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
    /// has_disabled_minimal_protocol_fee indicates whether the minimal protocol
    /// fee is disabled for the market
    #[prost(bool, tag="22")]
    pub has_disabled_minimal_protocol_fee: bool,
    /// force_paused_info defines additional info for force paused markets, only
    /// set when status == ForcePaused
    #[prost(message, optional, tag="23")]
    pub force_paused_info: ::core::option::Option<ForcePausedInfo>,
}
/// An object describing a derivative market in the Injective Futures Protocol.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeMarket {
    /// Ticker for the derivative contract.
    #[prost(string, tag="1")]
    pub ticker: ::prost::alloc::string::String,
    /// Oracle base currency
    #[prost(string, tag="2")]
    pub oracle_base: ::prost::alloc::string::String,
    /// Oracle quote currency
    #[prost(string, tag="3")]
    pub oracle_quote: ::prost::alloc::string::String,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="4")]
    pub oracle_type: i32,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="5")]
    pub oracle_scale_factor: u32,
    /// Address of the quote currency denomination for the derivative contract
    #[prost(string, tag="6")]
    pub quote_denom: ::prost::alloc::string::String,
    /// Unique market ID.
    #[prost(string, tag="7")]
    pub market_id: ::prost::alloc::string::String,
    /// initial_margin_ratio defines the initial margin ratio of a derivative
    /// market
    #[prost(string, tag="8")]
    pub initial_margin_ratio: ::prost::alloc::string::String,
    /// maintenance_margin_ratio defines the maintenance margin ratio of a
    /// derivative market
    #[prost(string, tag="9")]
    pub maintenance_margin_ratio: ::prost::alloc::string::String,
    /// maker_fee_rate defines the maker fee rate of a derivative market
    #[prost(string, tag="10")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the taker fee rate of a derivative market
    #[prost(string, tag="11")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// relayer_fee_share_rate defines the percentage of the transaction fee shared
    /// with the relayer in a derivative market
    #[prost(string, tag="12")]
    pub relayer_fee_share_rate: ::prost::alloc::string::String,
    /// true if the market is a perpetual market. false if the market is an expiry
    /// futures market
    #[prost(bool, tag="13")]
    pub is_perpetual: bool,
    /// Status of the market
    #[prost(enumeration="MarketStatus", tag="14")]
    pub status: i32,
    /// min_price_tick_size defines the minimum tick size that the price and margin
    /// required for orders in the market (in human readable format)
    #[prost(string, tag="15")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the quantity
    /// required for orders in the market (in human readable format)
    #[prost(string, tag="16")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market (in human readable format)
    #[prost(string, tag="17")]
    pub min_notional: ::prost::alloc::string::String,
    /// current market admin
    #[prost(string, tag="18")]
    pub admin: ::prost::alloc::string::String,
    /// level of admin permissions
    #[prost(uint32, tag="19")]
    pub admin_permissions: u32,
    /// quote token decimals
    #[prost(uint32, tag="20")]
    pub quote_decimals: u32,
    /// reduce_margin_ratio defines the ratio of the margin that is reduced
    #[prost(string, tag="21")]
    pub reduce_margin_ratio: ::prost::alloc::string::String,
    /// open_notional_cap defines the maximum open notional for the market
    #[prost(message, optional, tag="22")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
    /// has_disabled_minimal_protocol_fee indicates whether the minimal protocol
    /// fee is disabled for the market
    #[prost(bool, tag="23")]
    pub has_disabled_minimal_protocol_fee: bool,
    /// force_paused_info defines additional info for force paused markets, only
    /// set when status == ForcePaused
    #[prost(message, optional, tag="24")]
    pub force_paused_info: ::core::option::Option<ForcePausedInfo>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeMarketSettlementInfo {
    /// market ID.
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// settlement_price defines the settlement price
    #[prost(string, tag="2")]
    pub settlement_price: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MarketVolume {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// the market volume
    #[prost(message, optional, tag="2")]
    pub volume: ::core::option::Option<VolumeRecord>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct VolumeRecord {
    /// the market's maker volume (in human readable format)
    #[prost(string, tag="1")]
    pub maker_volume: ::prost::alloc::string::String,
    /// the market's taker volume (in human readable format)
    #[prost(string, tag="2")]
    pub taker_volume: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ExpiryFuturesMarketInfoState {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub market_info: ::core::option::Option<ExpiryFuturesMarketInfo>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PerpetualMarketFundingState {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub funding: ::core::option::Option<PerpetualMarketFunding>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ExpiryFuturesMarketInfo {
    /// market ID.
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// expiration_timestamp defines the expiration time for a time expiry futures
    /// market.
    #[prost(int64, tag="2")]
    pub expiration_timestamp: i64,
    /// expiration_twap_start_timestamp defines the start time of the TWAP
    /// calculation window
    #[prost(int64, tag="3")]
    pub twap_start_timestamp: i64,
    /// expiration_twap_start_price_cumulative defines the cumulative price for the
    /// start of the TWAP window (in human readable format)
    /// Deprecated: For correctly calculating the expiration price using TWAP, we
    /// need to keep the cumulative price at the start of TWAP calculation
    /// separately for the base asset and the quote asset. Use
    /// expiration_twap_start_base_cumulative_price and
    /// expiration_twap_start_quote_cumulative_price instead.
    #[deprecated]
    #[prost(string, tag="4")]
    pub expiration_twap_start_price_cumulative: ::prost::alloc::string::String,
    /// settlement_price defines the settlement price for a time expiry futures
    /// market (in human readable format)
    #[prost(string, tag="5")]
    pub settlement_price: ::prost::alloc::string::String,
    /// expiration_twap_start_base_cumulative_price defines the cumulative price
    /// for the base asset at the start of the TWAP calculation window (in human
    /// readable format)
    #[prost(string, tag="6")]
    pub expiration_twap_start_base_cumulative_price: ::prost::alloc::string::String,
    /// expiration_twap_start_quote_cumulative_price defines the cumulative price
    /// for the quote asset at the start of the TWAP calculation window (in human
    /// readable format)
    #[prost(string, tag="7")]
    pub expiration_twap_start_quote_cumulative_price: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PerpetualMarketInfo {
    /// market ID.
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// hourly_funding_rate_cap defines the maximum absolute value of the hourly
    /// funding rate
    #[prost(string, tag="2")]
    pub hourly_funding_rate_cap: ::prost::alloc::string::String,
    /// hourly_interest_rate defines the hourly interest rate
    #[prost(string, tag="3")]
    pub hourly_interest_rate: ::prost::alloc::string::String,
    /// next_funding_timestamp defines the next funding timestamp in seconds of a
    /// perpetual market
    #[prost(int64, tag="4")]
    pub next_funding_timestamp: i64,
    /// funding_interval defines the next funding interval in seconds of a
    /// perpetual market.
    #[prost(int64, tag="5")]
    pub funding_interval: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PerpetualMarketFunding {
    /// cumulative_funding defines the cumulative funding of a perpetual market.
    #[prost(string, tag="1")]
    pub cumulative_funding: ::prost::alloc::string::String,
    /// cumulative_price defines the running time-integral of the perp premium
    /// ((VWAP - mark_price) / mark_price) i.e., sum(premium * seconds)
    /// used to compute the interval’s average premium for funding
    #[prost(string, tag="2")]
    pub cumulative_price: ::prost::alloc::string::String,
    /// the last funding timestamp in seconds
    #[prost(int64, tag="3")]
    pub last_timestamp: i64,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum MarketStatus {
    Unspecified = 0,
    Active = 1,
    Paused = 2,
    Demolished = 3,
    Expired = 4,
    ForcePaused = 5,
}
impl MarketStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            MarketStatus::Unspecified => "Unspecified",
            MarketStatus::Active => "Active",
            MarketStatus::Paused => "Paused",
            MarketStatus::Demolished => "Demolished",
            MarketStatus::Expired => "Expired",
            MarketStatus::ForcePaused => "ForcePaused",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Unspecified" => Some(Self::Unspecified),
            "Active" => Some(Self::Active),
            "Paused" => Some(Self::Paused),
            "Demolished" => Some(Self::Demolished),
            "Expired" => Some(Self::Expired),
            "ForcePaused" => Some(Self::ForcePaused),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum ForcePausedReason {
    QuoteDenomPaused = 0,
}
impl ForcePausedReason {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            ForcePausedReason::QuoteDenomPaused => "QuoteDenomPaused",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "QuoteDenomPaused" => Some(Self::QuoteDenomPaused),
            _ => None,
        }
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrderInfo {
    /// bytes32 subaccount ID that created the order
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// address fee_recipient address that will receive fees for the order
    #[prost(string, tag="2")]
    pub fee_recipient: ::prost::alloc::string::String,
    /// price of the order (in human readable format)
    #[prost(string, tag="3")]
    pub price: ::prost::alloc::string::String,
    /// quantity of the order (in human readable format)
    #[prost(string, tag="4")]
    pub quantity: ::prost::alloc::string::String,
    /// the client order ID (optional)
    #[prost(string, tag="5")]
    pub cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotOrder {
    /// market_id represents the unique ID of the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// order_info contains the information of the order
    #[prost(message, optional, tag="2")]
    pub order_info: ::core::option::Option<OrderInfo>,
    /// order types
    #[prost(enumeration="OrderType", tag="3")]
    pub order_type: i32,
    /// trigger_price is the trigger price used by stop/take orders (in human
    /// readable format) (optional)
    #[prost(string, tag="4")]
    pub trigger_price: ::prost::alloc::string::String,
    /// expiration block is the block number at which the order will expire
    #[prost(int64, tag="5")]
    pub expiration_block: i64,
}
/// A valid Spot market order with Metadata.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotMarketOrder {
    /// order_info contains the information of the order
    #[prost(message, optional, tag="1")]
    pub order_info: ::core::option::Option<OrderInfo>,
    #[prost(string, tag="2")]
    pub balance_hold: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="3")]
    pub order_hash: ::prost::alloc::vec::Vec<u8>,
    /// order types
    #[prost(enumeration="OrderType", tag="4")]
    pub order_type: i32,
    /// trigger_price is the trigger price used by stop/take orders
    #[prost(string, tag="5")]
    pub trigger_price: ::prost::alloc::string::String,
}
/// A valid Spot limit order with Metadata.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotLimitOrder {
    /// order_info contains the information of the order
    #[prost(message, optional, tag="1")]
    pub order_info: ::core::option::Option<OrderInfo>,
    /// order types
    #[prost(enumeration="OrderType", tag="2")]
    pub order_type: i32,
    /// the amount of the quantity remaining fillable
    #[prost(string, tag="3")]
    pub fillable: ::prost::alloc::string::String,
    /// trigger_price is the trigger price used by stop/take orders
    #[prost(string, tag="4")]
    pub trigger_price: ::prost::alloc::string::String,
    /// order hash
    #[prost(bytes="vec", tag="5")]
    pub order_hash: ::prost::alloc::vec::Vec<u8>,
    /// expiration block is the block number at which the order will expire
    #[prost(int64, tag="6")]
    pub expiration_block: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeOrder {
    /// market_id represents the unique ID of the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// order_info contains the information of the order
    #[prost(message, optional, tag="2")]
    pub order_info: ::core::option::Option<OrderInfo>,
    /// order types
    #[prost(enumeration="OrderType", tag="3")]
    pub order_type: i32,
    /// margin is the margin used by the limit order (in human readable format)
    #[prost(string, tag="4")]
    pub margin: ::prost::alloc::string::String,
    /// trigger_price is the trigger price used by stop/take orders (in human
    /// readable format) (optional)
    #[prost(string, tag="5")]
    pub trigger_price: ::prost::alloc::string::String,
    /// expiration block is the block number at which the order will expire
    #[prost(int64, tag="6")]
    pub expiration_block: i64,
}
/// A valid Derivative market order with Metadata.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeMarketOrder {
    /// order_info contains the information of the order
    #[prost(message, optional, tag="1")]
    pub order_info: ::core::option::Option<OrderInfo>,
    /// order types
    #[prost(enumeration="OrderType", tag="2")]
    pub order_type: i32,
    #[prost(string, tag="3")]
    pub margin: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub margin_hold: ::prost::alloc::string::String,
    /// trigger_price is the trigger price used by stop/take orders
    #[prost(string, tag="5")]
    pub trigger_price: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="6")]
    pub order_hash: ::prost::alloc::vec::Vec<u8>,
}
/// A valid Derivative limit order with Metadata.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeLimitOrder {
    /// order_info contains the information of the order
    #[prost(message, optional, tag="1")]
    pub order_info: ::core::option::Option<OrderInfo>,
    /// order types
    #[prost(enumeration="OrderType", tag="2")]
    pub order_type: i32,
    /// margin is the margin used by the limit order
    #[prost(string, tag="3")]
    pub margin: ::prost::alloc::string::String,
    /// the amount of the quantity remaining fillable
    #[prost(string, tag="4")]
    pub fillable: ::prost::alloc::string::String,
    /// trigger_price is the trigger price used by stop/take orders
    #[prost(string, tag="5")]
    pub trigger_price: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="6")]
    pub order_hash: ::prost::alloc::vec::Vec<u8>,
    /// expiration block is the block number at which the order will expire
    #[prost(int64, tag="7")]
    pub expiration_block: i64,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum OrderType {
    Unspecified = 0,
    Buy = 1,
    Sell = 2,
    StopBuy = 3,
    StopSell = 4,
    TakeBuy = 5,
    TakeSell = 6,
    BuyPo = 7,
    SellPo = 8,
    BuyAtomic = 9,
    SellAtomic = 10,
}
impl OrderType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            OrderType::Unspecified => "UNSPECIFIED",
            OrderType::Buy => "BUY",
            OrderType::Sell => "SELL",
            OrderType::StopBuy => "STOP_BUY",
            OrderType::StopSell => "STOP_SELL",
            OrderType::TakeBuy => "TAKE_BUY",
            OrderType::TakeSell => "TAKE_SELL",
            OrderType::BuyPo => "BUY_PO",
            OrderType::SellPo => "SELL_PO",
            OrderType::BuyAtomic => "BUY_ATOMIC",
            OrderType::SellAtomic => "SELL_ATOMIC",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "UNSPECIFIED" => Some(Self::Unspecified),
            "BUY" => Some(Self::Buy),
            "SELL" => Some(Self::Sell),
            "STOP_BUY" => Some(Self::StopBuy),
            "STOP_SELL" => Some(Self::StopSell),
            "TAKE_BUY" => Some(Self::TakeBuy),
            "TAKE_SELL" => Some(Self::TakeSell),
            "BUY_PO" => Some(Self::BuyPo),
            "SELL_PO" => Some(Self::SellPo),
            "BUY_ATOMIC" => Some(Self::BuyAtomic),
            "SELL_ATOMIC" => Some(Self::SellAtomic),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum OrderMask {
    Unused = 0,
    Any = 1,
    Regular = 2,
    Conditional = 4,
    /// for conditional orders means HIGHER
    DirectionBuyOrHigher = 8,
    /// for conditional orders means LOWER
    DirectionSellOrLower = 16,
    TypeMarket = 32,
    TypeLimit = 64,
}
impl OrderMask {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            OrderMask::Unused => "UNUSED",
            OrderMask::Any => "ANY",
            OrderMask::Regular => "REGULAR",
            OrderMask::Conditional => "CONDITIONAL",
            OrderMask::DirectionBuyOrHigher => "DIRECTION_BUY_OR_HIGHER",
            OrderMask::DirectionSellOrLower => "DIRECTION_SELL_OR_LOWER",
            OrderMask::TypeMarket => "TYPE_MARKET",
            OrderMask::TypeLimit => "TYPE_LIMIT",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "UNUSED" => Some(Self::Unused),
            "ANY" => Some(Self::Any),
            "REGULAR" => Some(Self::Regular),
            "CONDITIONAL" => Some(Self::Conditional),
            "DIRECTION_BUY_OR_HIGHER" => Some(Self::DirectionBuyOrHigher),
            "DIRECTION_SELL_OR_LOWER" => Some(Self::DirectionSellOrLower),
            "TYPE_MARKET" => Some(Self::TypeMarket),
            "TYPE_LIMIT" => Some(Self::TypeLimit),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum AtomicMarketOrderAccessLevel {
    Nobody = 0,
    /// currently unsupported
    BeginBlockerSmartContractsOnly = 1,
    SmartContractsOnly = 2,
    Everyone = 3,
}
impl AtomicMarketOrderAccessLevel {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            AtomicMarketOrderAccessLevel::Nobody => "Nobody",
            AtomicMarketOrderAccessLevel::BeginBlockerSmartContractsOnly => "BeginBlockerSmartContractsOnly",
            AtomicMarketOrderAccessLevel::SmartContractsOnly => "SmartContractsOnly",
            AtomicMarketOrderAccessLevel::Everyone => "Everyone",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Nobody" => Some(Self::Nobody),
            "BeginBlockerSmartContractsOnly" => Some(Self::BeginBlockerSmartContractsOnly),
            "SmartContractsOnly" => Some(Self::SmartContractsOnly),
            "Everyone" => Some(Self::Everyone),
            _ => None,
        }
    }
}
/// EnforcedRestrictionsContract defines a contract with its pause event
/// signature
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EnforcedRestrictionsContract {
    /// EVM address of the contract
    #[prost(string, tag="1")]
    pub contract_address: ::prost::alloc::string::String,
    /// Pause event signature for the contract (e.g. "Pause()", or
    /// "Pause(address)"). If left empty, it will default to "Pause()".
    #[prost(string, tag="2")]
    pub pause_event_signature: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Params {
    /// spot_market_instant_listing_fee defines the expedited fee in INJ required
    /// to create a spot market by bypassing governance
    #[prost(message, optional, tag="1")]
    pub spot_market_instant_listing_fee: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
    /// derivative_market_instant_listing_fee defines the expedited fee in INJ
    /// required to create a derivative market by bypassing governance
    #[prost(message, optional, tag="2")]
    pub derivative_market_instant_listing_fee: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
    /// default_spot_maker_fee defines the default exchange trade fee for makers on
    /// a spot market
    #[prost(string, tag="3")]
    pub default_spot_maker_fee_rate: ::prost::alloc::string::String,
    /// default_spot_taker_fee_rate defines the default exchange trade fee rate for
    /// takers on a new spot market
    #[prost(string, tag="4")]
    pub default_spot_taker_fee_rate: ::prost::alloc::string::String,
    /// default_derivative_maker_fee defines the default exchange trade fee for
    /// makers on a new derivative market
    #[prost(string, tag="5")]
    pub default_derivative_maker_fee_rate: ::prost::alloc::string::String,
    /// default_derivative_taker_fee defines the default exchange trade fee for
    /// takers on a new derivative market
    #[prost(string, tag="6")]
    pub default_derivative_taker_fee_rate: ::prost::alloc::string::String,
    /// default_initial_margin_ratio defines the default initial margin ratio on a
    /// new derivative market
    #[prost(string, tag="7")]
    pub default_initial_margin_ratio: ::prost::alloc::string::String,
    /// default_maintenance_margin_ratio defines the default maintenance margin
    /// ratio on a new derivative market
    #[prost(string, tag="8")]
    pub default_maintenance_margin_ratio: ::prost::alloc::string::String,
    /// default_funding_interval defines the default funding interval on a
    /// derivative market
    #[prost(int64, tag="9")]
    pub default_funding_interval: i64,
    /// funding_multiple defines the timestamp multiple that the funding timestamp
    /// should be a multiple of
    #[prost(int64, tag="10")]
    pub funding_multiple: i64,
    /// relayer_fee_share_rate defines the trade fee share percentage that goes to
    /// relayers
    #[prost(string, tag="11")]
    pub relayer_fee_share_rate: ::prost::alloc::string::String,
    /// default_hourly_funding_rate_cap defines the default maximum absolute value
    /// of the hourly funding rate
    #[prost(string, tag="12")]
    pub default_hourly_funding_rate_cap: ::prost::alloc::string::String,
    /// hourly_interest_rate defines the hourly interest rate
    #[prost(string, tag="13")]
    pub default_hourly_interest_rate: ::prost::alloc::string::String,
    /// max_derivative_order_side_count defines the maximum number of derivative
    /// active orders a subaccount can have for a given orderbook side
    #[prost(uint32, tag="14")]
    pub max_derivative_order_side_count: u32,
    /// inj_reward_staked_requirement_threshold defines the threshold on INJ
    /// rewards after which one also needs staked INJ to receive more
    #[prost(string, tag="15")]
    pub inj_reward_staked_requirement_threshold: ::prost::alloc::string::String,
    /// the trading_rewards_vesting_duration defines the vesting times for trading
    /// rewards
    #[prost(int64, tag="16")]
    pub trading_rewards_vesting_duration: i64,
    /// liquidator_reward_share_rate defines the ratio of the split of the surplus
    /// collateral that goes to the liquidator
    #[prost(string, tag="17")]
    pub liquidator_reward_share_rate: ::prost::alloc::string::String,
    /// binary_options_market_instant_listing_fee defines the expedited fee in INJ
    /// required to create a derivative market by bypassing governance
    #[prost(message, optional, tag="18")]
    pub binary_options_market_instant_listing_fee: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
    /// atomic_market_order_access_level defines the required access permissions
    /// for executing atomic market orders
    #[prost(enumeration="AtomicMarketOrderAccessLevel", tag="19")]
    pub atomic_market_order_access_level: i32,
    /// spot_atomic_market_order_fee_multiplier defines the default multiplier for
    /// executing atomic market orders in spot markets
    #[prost(string, tag="20")]
    pub spot_atomic_market_order_fee_multiplier: ::prost::alloc::string::String,
    /// derivative_atomic_market_order_fee_multiplier defines the default
    /// multiplier for executing atomic market orders in derivative markets
    #[prost(string, tag="21")]
    pub derivative_atomic_market_order_fee_multiplier: ::prost::alloc::string::String,
    /// binary_options_atomic_market_order_fee_multiplier defines the default
    /// multiplier for executing atomic market orders in binary markets
    #[prost(string, tag="22")]
    pub binary_options_atomic_market_order_fee_multiplier: ::prost::alloc::string::String,
    /// minimal_protocol_fee_rate defines the minimal protocol fee rate
    #[prost(string, tag="23")]
    pub minimal_protocol_fee_rate: ::prost::alloc::string::String,
    /// is_instant_derivative_market_launch_enabled defines whether instant
    /// derivative market launch is enabled
    #[prost(bool, tag="24")]
    pub is_instant_derivative_market_launch_enabled: bool,
    #[prost(int64, tag="25")]
    pub post_only_mode_height_threshold: i64,
    /// Maximum time in seconds since the last mark price update to allow a
    /// decrease in margin
    #[prost(int64, tag="26")]
    pub margin_decrease_price_timestamp_threshold_seconds: i64,
    /// List of addresses that are allowed to perform exchange admin operations
    #[prost(string, repeated, tag="27")]
    pub exchange_admins: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// inj_auction_max_cap defines the maximum cap for INJ sent to auction
    #[prost(string, tag="28")]
    pub inj_auction_max_cap: ::prost::alloc::string::String,
    /// fixed_gas_enabled indicates if msg server will consume fixed gas amount for
    /// certain msg types
    #[prost(bool, tag="29")]
    pub fixed_gas_enabled: bool,
    /// emit_legacy_version_events indicates if events of legacy version types
    /// should be emitted in parallel to the new version events
    #[prost(bool, tag="30")]
    pub emit_legacy_version_events: bool,
    /// default_reduce_margin_ratio defines the default reduce margin ratio on a
    /// new derivative market
    #[prost(string, tag="31")]
    pub default_reduce_margin_ratio: ::prost::alloc::string::String,
    /// post_only_mode_blocks_amount defines the amount of blocks the post only
    /// mode will be enabled after a chain upgrade
    #[prost(uint64, tag="33")]
    pub post_only_mode_blocks_amount: u64,
    /// min_post_only_mode_downtime_duration defines the minimum downtime duration
    /// that must pass before the post only mode is automatically enabled. The
    /// accepted values are the Downtime enum values from the downtime_duration
    /// module
    #[prost(string, tag="34")]
    pub min_post_only_mode_downtime_duration: ::prost::alloc::string::String,
    /// post_only_mode_blocks_amount defines the amount of blocks the post only
    /// mode will be enabled after the downtime-detector module detects a chain
    /// downtime
    #[prost(uint64, tag="35")]
    pub post_only_mode_blocks_amount_after_downtime: u64,
    /// Contracts that exchange will be listening to pause markets denominated in
    /// respective erc20: denoms, with their pause event signatures
    #[prost(message, repeated, tag="36")]
    pub enforced_restrictions_contracts: ::prost::alloc::vec::Vec<EnforcedRestrictionsContract>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct NextFundingTimestamp {
    #[prost(int64, tag="1")]
    pub next_timestamp: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MidPriceAndTob {
    /// mid price of the market (in human readable format)
    #[prost(string, tag="1")]
    pub mid_price: ::prost::alloc::string::String,
    /// best buy price of the market (in human readable format)
    #[prost(string, tag="2")]
    pub best_buy_price: ::prost::alloc::string::String,
    /// best sell price of the market (in human readable format)
    #[prost(string, tag="3")]
    pub best_sell_price: ::prost::alloc::string::String,
}
/// A subaccount's deposit for a given base currency
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Deposit {
    /// the available balance (in chain format)
    #[prost(string, tag="1")]
    pub available_balance: ::prost::alloc::string::String,
    /// the total balance (in chain format)
    #[prost(string, tag="2")]
    pub total_balance: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountTradeNonce {
    #[prost(uint32, tag="1")]
    pub nonce: u32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountOrder {
    /// price of the order
    #[prost(string, tag="1")]
    pub price: ::prost::alloc::string::String,
    /// the amount of the quantity remaining fillable
    #[prost(string, tag="2")]
    pub quantity: ::prost::alloc::string::String,
    #[prost(bool, tag="3")]
    pub is_reduce_only: bool,
    #[prost(string, tag="4")]
    pub cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountOrderData {
    #[prost(message, optional, tag="1")]
    pub order: ::core::option::Option<SubaccountOrder>,
    #[prost(bytes="vec", tag="2")]
    pub order_hash: ::prost::alloc::vec::Vec<u8>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Position {
    /// True if the position is long. False if the position is short.
    #[prost(bool, tag="1")]
    pub is_long: bool,
    /// The quantity of the position (in human readable format)
    #[prost(string, tag="2")]
    pub quantity: ::prost::alloc::string::String,
    /// The entry price of the position (in human readable format)
    #[prost(string, tag="3")]
    pub entry_price: ::prost::alloc::string::String,
    /// The margin of the position (in human readable format)
    #[prost(string, tag="4")]
    pub margin: ::prost::alloc::string::String,
    /// The cumulative funding
    #[prost(string, tag="5")]
    pub cumulative_funding_entry: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Balance {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the denom of the balance
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
    /// the token deposits details
    #[prost(message, optional, tag="3")]
    pub deposits: ::core::option::Option<Deposit>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativePosition {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// the position details
    #[prost(message, optional, tag="3")]
    pub position: ::core::option::Option<Position>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MarketOrderIndicator {
    /// market_id represents the unique ID of the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub is_buy: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradeLog {
    #[prost(string, tag="1")]
    pub quantity: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub price: ::prost::alloc::string::String,
    /// bytes32 subaccount ID that executed the trade
    #[prost(bytes="vec", tag="3")]
    pub subaccount_id: ::prost::alloc::vec::Vec<u8>,
    #[prost(string, tag="4")]
    pub fee: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="5")]
    pub order_hash: ::prost::alloc::vec::Vec<u8>,
    #[prost(bytes="vec", tag="6")]
    pub fee_recipient_address: ::prost::alloc::vec::Vec<u8>,
    #[prost(string, tag="7")]
    pub cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PositionDelta {
    #[prost(bool, tag="1")]
    pub is_long: bool,
    #[prost(string, tag="2")]
    pub execution_quantity: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub execution_margin: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub execution_price: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeTradeLog {
    #[prost(bytes="vec", tag="1")]
    pub subaccount_id: ::prost::alloc::vec::Vec<u8>,
    #[prost(message, optional, tag="2")]
    pub position_delta: ::core::option::Option<PositionDelta>,
    #[prost(string, tag="3")]
    pub payout: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub fee: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="5")]
    pub order_hash: ::prost::alloc::vec::Vec<u8>,
    #[prost(bytes="vec", tag="6")]
    pub fee_recipient_address: ::prost::alloc::vec::Vec<u8>,
    #[prost(string, tag="7")]
    pub cid: ::prost::alloc::string::String,
    #[prost(string, tag="8")]
    pub pnl: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountPosition {
    #[prost(message, optional, tag="1")]
    pub position: ::core::option::Option<Position>,
    #[prost(bytes="vec", tag="2")]
    pub subaccount_id: ::prost::alloc::vec::Vec<u8>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountDeposit {
    #[prost(bytes="vec", tag="1")]
    pub subaccount_id: ::prost::alloc::vec::Vec<u8>,
    #[prost(message, optional, tag="2")]
    pub deposit: ::core::option::Option<Deposit>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DepositUpdate {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub deposits: ::prost::alloc::vec::Vec<SubaccountDeposit>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PointsMultiplier {
    #[prost(string, tag="1")]
    pub maker_points_multiplier: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub taker_points_multiplier: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradingRewardCampaignBoostInfo {
    #[prost(string, repeated, tag="1")]
    pub boosted_spot_market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(message, repeated, tag="2")]
    pub spot_market_multipliers: ::prost::alloc::vec::Vec<PointsMultiplier>,
    #[prost(string, repeated, tag="3")]
    pub boosted_derivative_market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(message, repeated, tag="4")]
    pub derivative_market_multipliers: ::prost::alloc::vec::Vec<PointsMultiplier>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CampaignRewardPool {
    /// the campaign start timestamp in seconds
    #[prost(int64, tag="1")]
    pub start_timestamp: i64,
    /// max_campaign_rewards are the maximum reward amounts to be disbursed at the
    /// end of the campaign
    #[prost(message, repeated, tag="2")]
    pub max_campaign_rewards: ::prost::alloc::vec::Vec<super::super::super::cosmos::base::v1beta1::Coin>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradingRewardCampaignInfo {
    /// number of seconds of the duration of each campaign
    #[prost(int64, tag="1")]
    pub campaign_duration_seconds: i64,
    /// the trading fee quote denoms which will be counted for the rewards
    #[prost(string, repeated, tag="2")]
    pub quote_denoms: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// the optional boost info for markets
    #[prost(message, optional, tag="3")]
    pub trading_reward_boost_info: ::core::option::Option<TradingRewardCampaignBoostInfo>,
    /// the marketIDs which are disqualified from being rewarded
    #[prost(string, repeated, tag="4")]
    pub disqualified_market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FeeDiscountTierInfo {
    /// the maker discount rate
    #[prost(string, tag="1")]
    pub maker_discount_rate: ::prost::alloc::string::String,
    /// the taker discount rate
    #[prost(string, tag="2")]
    pub taker_discount_rate: ::prost::alloc::string::String,
    /// the staked amount required to qualify for the discount (in chain format)
    #[prost(string, tag="3")]
    pub staked_amount: ::prost::alloc::string::String,
    /// the volume required to qualify for the discount (in human readable format)
    #[prost(string, tag="4")]
    pub volume: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FeeDiscountSchedule {
    /// the bucket number
    #[prost(uint64, tag="1")]
    pub bucket_count: u64,
    /// the bucket duration in seconds
    #[prost(int64, tag="2")]
    pub bucket_duration: i64,
    /// the trading fee quote denoms which will be counted for the fee paid
    /// contribution
    #[prost(string, repeated, tag="3")]
    pub quote_denoms: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// the fee discount tiers
    #[prost(message, repeated, tag="4")]
    pub tier_infos: ::prost::alloc::vec::Vec<FeeDiscountTierInfo>,
    /// the marketIDs which are disqualified from contributing to the fee paid
    /// amount
    #[prost(string, repeated, tag="5")]
    pub disqualified_market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FeeDiscountTierTtl {
    /// the tier number
    #[prost(uint64, tag="1")]
    pub tier: u64,
    /// the TTL timestamp in seconds
    #[prost(int64, tag="2")]
    pub ttl_timestamp: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AccountRewards {
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub rewards: ::prost::alloc::vec::Vec<super::super::super::cosmos::base::v1beta1::Coin>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradeRecords {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub latest_trade_records: ::prost::alloc::vec::Vec<TradeRecord>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountIDs {
    #[prost(bytes="vec", repeated, tag="1")]
    pub subaccount_ids: ::prost::alloc::vec::Vec<::prost::alloc::vec::Vec<u8>>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradeRecord {
    /// the timestamp of the trade
    #[prost(int64, tag="1")]
    pub timestamp: i64,
    /// the price of the trade (in human readable format)
    #[prost(string, tag="2")]
    pub price: ::prost::alloc::string::String,
    /// the quantity of the trade (in human readable format)
    #[prost(string, tag="3")]
    pub quantity: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Level {
    /// price (in human readable format)
    #[prost(string, tag="1")]
    pub p: ::prost::alloc::string::String,
    /// quantity (in human readable format)
    #[prost(string, tag="2")]
    pub q: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AggregateSubaccountVolumeRecord {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the subaccount volumes for each market
    #[prost(message, repeated, tag="2")]
    pub market_volumes: ::prost::alloc::vec::Vec<MarketVolume>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AggregateAccountVolumeRecord {
    /// account the volume belongs to
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
    /// the aggregate volumes for each market
    #[prost(message, repeated, tag="2")]
    pub market_volumes: ::prost::alloc::vec::Vec<MarketVolume>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DenomDecimals {
    /// the denom of the token
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    /// the decimals of the token
    #[prost(uint64, tag="2")]
    pub decimals: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GrantAuthorization {
    /// the grantee address
    #[prost(string, tag="1")]
    pub grantee: ::prost::alloc::string::String,
    /// the amount of stake granted (INJ in chain format)
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ActiveGrant {
    #[prost(string, tag="1")]
    pub granter: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EffectiveGrant {
    #[prost(string, tag="1")]
    pub granter: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub net_granted_stake: ::prost::alloc::string::String,
    #[prost(bool, tag="3")]
    pub is_valid: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DenomMinNotional {
    /// the denom of the token
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    /// the minimum notional value for the token (in human readable format)
    #[prost(string, tag="2")]
    pub min_notional: ::prost::alloc::string::String,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum ExecutionType {
    UnspecifiedExecutionType = 0,
    Market = 1,
    LimitFill = 2,
    LimitMatchRestingOrder = 3,
    LimitMatchNewOrder = 4,
    MarketLiquidation = 5,
    ExpiryMarketSettlement = 6,
    OffsettingPosition = 7,
    Synthetic = 8,
}
impl ExecutionType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            ExecutionType::UnspecifiedExecutionType => "UnspecifiedExecutionType",
            ExecutionType::Market => "Market",
            ExecutionType::LimitFill => "LimitFill",
            ExecutionType::LimitMatchRestingOrder => "LimitMatchRestingOrder",
            ExecutionType::LimitMatchNewOrder => "LimitMatchNewOrder",
            ExecutionType::MarketLiquidation => "MarketLiquidation",
            ExecutionType::ExpiryMarketSettlement => "ExpiryMarketSettlement",
            ExecutionType::OffsettingPosition => "OffsettingPosition",
            ExecutionType::Synthetic => "Synthetic",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "UnspecifiedExecutionType" => Some(Self::UnspecifiedExecutionType),
            "Market" => Some(Self::Market),
            "LimitFill" => Some(Self::LimitFill),
            "LimitMatchRestingOrder" => Some(Self::LimitMatchRestingOrder),
            "LimitMatchNewOrder" => Some(Self::LimitMatchNewOrder),
            "MarketLiquidation" => Some(Self::MarketLiquidation),
            "ExpiryMarketSettlement" => Some(Self::ExpiryMarketSettlement),
            "OffsettingPosition" => Some(Self::OffsettingPosition),
            "Synthetic" => Some(Self::Synthetic),
            _ => None,
        }
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotMarketParamUpdateProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// maker_fee_rate defines the trade fee rate for makers on the spot market
    #[prost(string, tag="4")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the trade fee rate for takers on the spot market
    #[prost(string, tag="5")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// relayer_fee_share_rate defines the relayer fee share rate for the spot
    /// market
    #[prost(string, tag="6")]
    pub relayer_fee_share_rate: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size of the order's price and
    /// margin
    #[prost(string, tag="7")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the order's
    /// quantity
    #[prost(string, tag="8")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    #[prost(enumeration="MarketStatus", tag="9")]
    pub status: i32,
    #[prost(string, tag="10")]
    pub ticker: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market
    #[prost(string, tag="11")]
    pub min_notional: ::prost::alloc::string::String,
    #[prost(message, optional, tag="12")]
    pub admin_info: ::core::option::Option<AdminInfo>,
    /// base token decimals
    #[prost(uint32, tag="13")]
    pub base_decimals: u32,
    /// quote token decimals
    #[prost(uint32, tag="14")]
    pub quote_decimals: u32,
    /// has_disabled_minimal_protocol_fee defines whether the minimal protocol fee
    /// is disabled for the market
    #[prost(enumeration="DisableMinimalProtocolFeeUpdate", tag="15")]
    pub has_disabled_minimal_protocol_fee: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ExchangeEnableProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(enumeration="ExchangeType", tag="3")]
    pub exchange_type: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BatchExchangeModificationProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="3")]
    pub spot_market_param_update_proposals: ::prost::alloc::vec::Vec<SpotMarketParamUpdateProposal>,
    #[prost(message, repeated, tag="4")]
    pub derivative_market_param_update_proposals: ::prost::alloc::vec::Vec<DerivativeMarketParamUpdateProposal>,
    #[prost(message, repeated, tag="5")]
    pub spot_market_launch_proposals: ::prost::alloc::vec::Vec<SpotMarketLaunchProposal>,
    #[prost(message, repeated, tag="6")]
    pub perpetual_market_launch_proposals: ::prost::alloc::vec::Vec<PerpetualMarketLaunchProposal>,
    #[prost(message, repeated, tag="7")]
    pub expiry_futures_market_launch_proposals: ::prost::alloc::vec::Vec<ExpiryFuturesMarketLaunchProposal>,
    #[prost(message, optional, tag="8")]
    pub trading_reward_campaign_update_proposal: ::core::option::Option<TradingRewardCampaignUpdateProposal>,
    #[prost(message, repeated, tag="9")]
    pub binary_options_market_launch_proposals: ::prost::alloc::vec::Vec<BinaryOptionsMarketLaunchProposal>,
    #[prost(message, repeated, tag="10")]
    pub binary_options_param_update_proposals: ::prost::alloc::vec::Vec<BinaryOptionsMarketParamUpdateProposal>,
    #[prost(message, optional, tag="11")]
    pub auction_exchange_transfer_denom_decimals_update_proposal: ::core::option::Option<UpdateAuctionExchangeTransferDenomDecimalsProposal>,
    #[prost(message, optional, tag="12")]
    pub fee_discount_proposal: ::core::option::Option<FeeDiscountProposal>,
    #[prost(message, repeated, tag="13")]
    pub market_forced_settlement_proposals: ::prost::alloc::vec::Vec<MarketForcedSettlementProposal>,
    #[prost(message, optional, tag="14")]
    pub denom_min_notional_proposal: ::core::option::Option<DenomMinNotionalProposal>,
}
/// SpotMarketLaunchProposal defines a SDK message for proposing a new spot
/// market through governance
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotMarketLaunchProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    /// Ticker for the spot market.
    #[prost(string, tag="3")]
    pub ticker: ::prost::alloc::string::String,
    /// type of coin to use as the base currency
    #[prost(string, tag="4")]
    pub base_denom: ::prost::alloc::string::String,
    /// type of coin to use as the quote currency
    #[prost(string, tag="5")]
    pub quote_denom: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size of the order's price
    #[prost(string, tag="6")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the order's
    /// quantity
    #[prost(string, tag="7")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// maker_fee_rate defines the fee percentage makers pay when trading
    #[prost(string, tag="8")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the fee percentage takers pay when trading
    #[prost(string, tag="9")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional for orders in the market
    #[prost(string, tag="10")]
    pub min_notional: ::prost::alloc::string::String,
    #[prost(message, optional, tag="11")]
    pub admin_info: ::core::option::Option<AdminInfo>,
    /// base token decimals
    #[prost(uint32, tag="14")]
    pub base_decimals: u32,
    /// quote token decimals
    #[prost(uint32, tag="15")]
    pub quote_decimals: u32,
}
/// PerpetualMarketLaunchProposal defines a SDK message for proposing a new
/// perpetual futures market through governance
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PerpetualMarketLaunchProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    /// Ticker for the derivative market.
    #[prost(string, tag="3")]
    pub ticker: ::prost::alloc::string::String,
    /// type of coin to use as the base currency
    #[prost(string, tag="4")]
    pub quote_denom: ::prost::alloc::string::String,
    /// Oracle base currency
    #[prost(string, tag="5")]
    pub oracle_base: ::prost::alloc::string::String,
    /// Oracle quote currency
    #[prost(string, tag="6")]
    pub oracle_quote: ::prost::alloc::string::String,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="7")]
    pub oracle_scale_factor: u32,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="8")]
    pub oracle_type: i32,
    /// initial_margin_ratio defines the initial margin ratio for the derivative
    /// market
    #[prost(string, tag="9")]
    pub initial_margin_ratio: ::prost::alloc::string::String,
    /// maintenance_margin_ratio defines the maintenance margin ratio for the
    /// derivative market
    #[prost(string, tag="10")]
    pub maintenance_margin_ratio: ::prost::alloc::string::String,
    /// maker_fee_rate defines the exchange trade fee for makers for the derivative
    /// market
    #[prost(string, tag="11")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the exchange trade fee for takers for the derivative
    /// market
    #[prost(string, tag="12")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size of the order's price and
    /// margin
    #[prost(string, tag="13")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the order's
    /// quantity
    #[prost(string, tag="14")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market
    #[prost(string, tag="15")]
    pub min_notional: ::prost::alloc::string::String,
    #[prost(message, optional, tag="16")]
    pub admin_info: ::core::option::Option<AdminInfo>,
    /// reduce_margin_ratio defines the ratio of the margin that is reduced
    #[prost(string, tag="17")]
    pub reduce_margin_ratio: ::prost::alloc::string::String,
    /// open_notional_cap defines the maximum open notional for the market
    #[prost(message, optional, tag="18")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BinaryOptionsMarketLaunchProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    /// Ticker for the derivative contract.
    #[prost(string, tag="3")]
    pub ticker: ::prost::alloc::string::String,
    /// Oracle symbol
    #[prost(string, tag="4")]
    pub oracle_symbol: ::prost::alloc::string::String,
    /// Oracle Provider
    #[prost(string, tag="5")]
    pub oracle_provider: ::prost::alloc::string::String,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="6")]
    pub oracle_type: i32,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="7")]
    pub oracle_scale_factor: u32,
    /// expiration timestamp
    #[prost(int64, tag="8")]
    pub expiration_timestamp: i64,
    /// expiration timestamp
    #[prost(int64, tag="9")]
    pub settlement_timestamp: i64,
    /// admin of the market
    #[prost(string, tag="10")]
    pub admin: ::prost::alloc::string::String,
    /// Address of the quote currency denomination for the binary options contract
    #[prost(string, tag="11")]
    pub quote_denom: ::prost::alloc::string::String,
    /// maker_fee_rate defines the maker fee rate of a binary options market
    #[prost(string, tag="12")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the taker fee rate of a derivative market
    #[prost(string, tag="13")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size that the price and margin
    /// required for orders in the market
    #[prost(string, tag="14")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the quantity
    /// required for orders in the market
    #[prost(string, tag="15")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market
    #[prost(string, tag="16")]
    pub min_notional: ::prost::alloc::string::String,
    #[prost(uint32, tag="17")]
    pub admin_permissions: u32,
    /// open_notional_cap defines the maximum open notional for the market
    #[prost(message, optional, tag="18")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
}
/// ExpiryFuturesMarketLaunchProposal defines a SDK message for proposing a new
/// expiry futures market through governance
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ExpiryFuturesMarketLaunchProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    /// Ticker for the derivative market.
    #[prost(string, tag="3")]
    pub ticker: ::prost::alloc::string::String,
    /// type of coin to use as the quote currency
    #[prost(string, tag="4")]
    pub quote_denom: ::prost::alloc::string::String,
    /// Oracle base currency
    #[prost(string, tag="5")]
    pub oracle_base: ::prost::alloc::string::String,
    /// Oracle quote currency
    #[prost(string, tag="6")]
    pub oracle_quote: ::prost::alloc::string::String,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="7")]
    pub oracle_scale_factor: u32,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="8")]
    pub oracle_type: i32,
    /// Expiration time of the market
    #[prost(int64, tag="9")]
    pub expiry: i64,
    /// initial_margin_ratio defines the initial margin ratio for the derivative
    /// market
    #[prost(string, tag="10")]
    pub initial_margin_ratio: ::prost::alloc::string::String,
    /// maintenance_margin_ratio defines the maintenance margin ratio for the
    /// derivative market
    #[prost(string, tag="11")]
    pub maintenance_margin_ratio: ::prost::alloc::string::String,
    /// maker_fee_rate defines the exchange trade fee for makers for the derivative
    /// market
    #[prost(string, tag="12")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the exchange trade fee for takers for the derivative
    /// market
    #[prost(string, tag="13")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size of the order's price and
    /// margin
    #[prost(string, tag="14")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the order's
    /// quantity
    #[prost(string, tag="15")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market
    #[prost(string, tag="16")]
    pub min_notional: ::prost::alloc::string::String,
    #[prost(message, optional, tag="17")]
    pub admin_info: ::core::option::Option<AdminInfo>,
    /// reduce_margin_ratio defines the ratio of the margin that is reduced
    #[prost(string, tag="18")]
    pub reduce_margin_ratio: ::prost::alloc::string::String,
    /// open_notional_cap defines the maximum open notional for the market
    #[prost(message, optional, tag="19")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeMarketParamUpdateProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// initial_margin_ratio defines the initial margin ratio for the derivative
    /// market
    #[prost(string, tag="4")]
    pub initial_margin_ratio: ::prost::alloc::string::String,
    /// maintenance_margin_ratio defines the maintenance margin ratio for the
    /// derivative market
    #[prost(string, tag="5")]
    pub maintenance_margin_ratio: ::prost::alloc::string::String,
    /// maker_fee_rate defines the exchange trade fee for makers for the derivative
    /// market
    #[prost(string, tag="6")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the exchange trade fee for takers for the derivative
    /// market
    #[prost(string, tag="7")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// relayer_fee_share_rate defines the relayer fee share rate for the
    /// derivative market
    #[prost(string, tag="8")]
    pub relayer_fee_share_rate: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size of the order's price and
    /// margin
    #[prost(string, tag="9")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the order's
    /// quantity
    #[prost(string, tag="10")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// hourly_interest_rate defines the hourly interest rate
    #[prost(string, tag="11")]
    pub hourly_interest_rate: ::prost::alloc::string::String,
    /// hourly_funding_rate_cap defines the maximum absolute value of the hourly
    /// funding rate
    #[prost(string, tag="12")]
    pub hourly_funding_rate_cap: ::prost::alloc::string::String,
    #[prost(enumeration="MarketStatus", tag="13")]
    pub status: i32,
    #[prost(message, optional, tag="14")]
    pub oracle_params: ::core::option::Option<OracleParams>,
    #[prost(string, tag="15")]
    pub ticker: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market
    #[prost(string, tag="16")]
    pub min_notional: ::prost::alloc::string::String,
    #[prost(message, optional, tag="17")]
    pub admin_info: ::core::option::Option<AdminInfo>,
    /// reduce_margin_ratio defines the ratio of the margin that is reduced
    #[prost(string, tag="18")]
    pub reduce_margin_ratio: ::prost::alloc::string::String,
    /// open_notional_cap defines the maximum open notional for the market
    #[prost(message, optional, tag="19")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
    /// has_disabled_minimal_protocol_fee defines whether the minimal protocol fee
    /// is disabled for the market
    #[prost(enumeration="DisableMinimalProtocolFeeUpdate", tag="20")]
    pub has_disabled_minimal_protocol_fee: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AdminInfo {
    #[prost(string, tag="1")]
    pub admin: ::prost::alloc::string::String,
    #[prost(uint32, tag="2")]
    pub admin_permissions: u32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MarketForcedSettlementProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub settlement_price: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UpdateAuctionExchangeTransferDenomDecimalsProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="3")]
    pub denom_decimals: ::prost::alloc::vec::Vec<DenomDecimals>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BinaryOptionsMarketParamUpdateProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// maker_fee_rate defines the exchange trade fee for makers for the derivative
    /// market
    #[prost(string, tag="4")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the exchange trade fee for takers for the derivative
    /// market
    #[prost(string, tag="5")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// relayer_fee_share_rate defines the relayer fee share rate for the
    /// derivative market
    #[prost(string, tag="6")]
    pub relayer_fee_share_rate: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size of the order's price and
    /// margin
    #[prost(string, tag="7")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the order's
    /// quantity
    #[prost(string, tag="8")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// expiration timestamp
    #[prost(int64, tag="9")]
    pub expiration_timestamp: i64,
    /// expiration timestamp
    #[prost(int64, tag="10")]
    pub settlement_timestamp: i64,
    /// new price at which market will be settled
    #[prost(string, tag="11")]
    pub settlement_price: ::prost::alloc::string::String,
    /// admin of the market
    #[prost(string, tag="12")]
    pub admin: ::prost::alloc::string::String,
    #[prost(enumeration="MarketStatus", tag="13")]
    pub status: i32,
    #[prost(message, optional, tag="14")]
    pub oracle_params: ::core::option::Option<ProviderOracleParams>,
    #[prost(string, tag="15")]
    pub ticker: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market
    #[prost(string, tag="16")]
    pub min_notional: ::prost::alloc::string::String,
    /// open_notional_cap defines the maximum open notional for the market
    #[prost(message, optional, tag="17")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
    /// has_disabled_minimal_protocol_fee defines whether the minimal protocol fee
    /// is disabled for the market
    #[prost(enumeration="DisableMinimalProtocolFeeUpdate", tag="18")]
    pub has_disabled_minimal_protocol_fee: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ProviderOracleParams {
    /// Oracle base currency
    #[prost(string, tag="1")]
    pub symbol: ::prost::alloc::string::String,
    /// Oracle quote currency
    #[prost(string, tag="2")]
    pub provider: ::prost::alloc::string::String,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="3")]
    pub oracle_scale_factor: u32,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="4")]
    pub oracle_type: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OracleParams {
    /// Oracle base currency
    #[prost(string, tag="1")]
    pub oracle_base: ::prost::alloc::string::String,
    /// Oracle quote currency
    #[prost(string, tag="2")]
    pub oracle_quote: ::prost::alloc::string::String,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="3")]
    pub oracle_scale_factor: u32,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="4")]
    pub oracle_type: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradingRewardCampaignLaunchProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub campaign_info: ::core::option::Option<TradingRewardCampaignInfo>,
    #[prost(message, repeated, tag="4")]
    pub campaign_reward_pools: ::prost::alloc::vec::Vec<CampaignRewardPool>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradingRewardCampaignUpdateProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub campaign_info: ::core::option::Option<TradingRewardCampaignInfo>,
    #[prost(message, repeated, tag="4")]
    pub campaign_reward_pools_additions: ::prost::alloc::vec::Vec<CampaignRewardPool>,
    #[prost(message, repeated, tag="5")]
    pub campaign_reward_pools_updates: ::prost::alloc::vec::Vec<CampaignRewardPool>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RewardPointUpdate {
    #[prost(string, tag="1")]
    pub account_address: ::prost::alloc::string::String,
    /// new_points overwrites the current trading reward points for the account
    #[prost(string, tag="12")]
    pub new_points: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradingRewardPendingPointsUpdateProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(int64, tag="3")]
    pub pending_pool_timestamp: i64,
    #[prost(message, repeated, tag="4")]
    pub reward_point_updates: ::prost::alloc::vec::Vec<RewardPointUpdate>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FeeDiscountProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub schedule: ::core::option::Option<FeeDiscountSchedule>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BatchCommunityPoolSpendProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="3")]
    pub proposals: ::prost::alloc::vec::Vec<super::super::super::cosmos::distribution::v1beta1::CommunityPoolSpendProposal>,
}
/// AtomicMarketOrderFeeMultiplierScheduleProposal defines a SDK message for
/// proposing new atomic take fee multipliers for specified markets
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AtomicMarketOrderFeeMultiplierScheduleProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="3")]
    pub market_fee_multipliers: ::prost::alloc::vec::Vec<MarketFeeMultiplier>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DenomMinNotionalProposal {
    #[prost(string, tag="1")]
    pub title: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="3")]
    pub denom_min_notionals: ::prost::alloc::vec::Vec<DenomMinNotional>,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum DisableMinimalProtocolFeeUpdate {
    NoUpdate = 0,
    False = 1,
    True = 2,
}
impl DisableMinimalProtocolFeeUpdate {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            DisableMinimalProtocolFeeUpdate::NoUpdate => "NoUpdate",
            DisableMinimalProtocolFeeUpdate::False => "False",
            DisableMinimalProtocolFeeUpdate::True => "True",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "NoUpdate" => Some(Self::NoUpdate),
            "False" => Some(Self::False),
            "True" => Some(Self::True),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum ExchangeType {
    ExchangeUnspecified = 0,
    Spot = 1,
    Derivatives = 2,
}
impl ExchangeType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            ExchangeType::ExchangeUnspecified => "EXCHANGE_UNSPECIFIED",
            ExchangeType::Spot => "SPOT",
            ExchangeType::Derivatives => "DERIVATIVES",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "EXCHANGE_UNSPECIFIED" => Some(Self::ExchangeUnspecified),
            "SPOT" => Some(Self::Spot),
            "DERIVATIVES" => Some(Self::Derivatives),
            _ => None,
        }
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateSpotMarket {
    /// current admin address of the associated market
    #[prost(string, tag="1")]
    pub admin: ::prost::alloc::string::String,
    /// id of the market to be updated
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// (optional) updated ticker value
    #[prost(string, tag="3")]
    pub new_ticker: ::prost::alloc::string::String,
    /// (optional) updated min price tick size value (in human readable format)
    #[prost(string, tag="4")]
    pub new_min_price_tick_size: ::prost::alloc::string::String,
    /// (optional) updated min quantity tick size value (in human readable format)
    #[prost(string, tag="5")]
    pub new_min_quantity_tick_size: ::prost::alloc::string::String,
    /// (optional) updated min notional (in human readable format)
    #[prost(string, tag="6")]
    pub new_min_notional: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateSpotMarketResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateDerivativeMarket {
    /// current admin address of the associated market
    #[prost(string, tag="1")]
    pub admin: ::prost::alloc::string::String,
    /// id of the market to be updated
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// (optional) updated value for ticker
    #[prost(string, tag="3")]
    pub new_ticker: ::prost::alloc::string::String,
    /// (optional) updated value for min_price_tick_size (in human readable format)
    #[prost(string, tag="4")]
    pub new_min_price_tick_size: ::prost::alloc::string::String,
    /// (optional) updated value min_quantity_tick_size (in human readable format)
    #[prost(string, tag="5")]
    pub new_min_quantity_tick_size: ::prost::alloc::string::String,
    /// (optional) updated min notional (in human readable format)
    #[prost(string, tag="6")]
    pub new_min_notional: ::prost::alloc::string::String,
    /// (optional) updated value for initial_margin_ratio
    #[prost(string, tag="7")]
    pub new_initial_margin_ratio: ::prost::alloc::string::String,
    /// (optional) updated value for maintenance_margin_ratio
    #[prost(string, tag="8")]
    pub new_maintenance_margin_ratio: ::prost::alloc::string::String,
    /// (optional) updated value for reduce_margin_ratio
    #[prost(string, tag="9")]
    pub new_reduce_margin_ratio: ::prost::alloc::string::String,
    /// (optional) updated value for open_notional_cap
    #[prost(message, optional, tag="10")]
    pub new_open_notional_cap: ::core::option::Option<OpenNotionalCap>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateDerivativeMarketResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateParams {
    /// authority is the address of the governance account.
    #[prost(string, tag="1")]
    pub authority: ::prost::alloc::string::String,
    /// params defines the exchange parameters to update.
    ///
    /// NOTE: All parameters must be supplied.
    #[prost(message, optional, tag="2")]
    pub params: ::core::option::Option<Params>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgUpdateParamsResponse {
}
/// MsgDeposit defines a SDK message for transferring coins from the sender's
/// bank balance into the subaccount's exchange deposits
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDeposit {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// (Optional) the subaccount ID to deposit funds into. If empty, the coin
    /// will be deposited to the sender's default subaccount address.
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the amount of the deposit (in chain format)
    #[prost(message, optional, tag="3")]
    pub amount: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
}
/// MsgDepositResponse defines the Msg/Deposit response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDepositResponse {
}
/// MsgWithdraw defines a SDK message for withdrawing coins from a subaccount's
/// deposits to the user's bank balance
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgWithdraw {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the subaccount ID to withdraw funds from
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the amount of the withdrawal (in chain format)
    #[prost(message, optional, tag="3")]
    pub amount: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
}
/// MsgWithdraw defines the Msg/Withdraw response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgWithdrawResponse {
}
/// MsgCreateSpotLimitOrder defines a SDK message for creating a new spot limit
/// order.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateSpotLimitOrder {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<SpotOrder>,
}
/// MsgCreateSpotLimitOrderResponse defines the Msg/CreateSpotOrder response
/// type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateSpotLimitOrderResponse {
    #[prost(string, tag="1")]
    pub order_hash: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub cid: ::prost::alloc::string::String,
}
/// MsgBatchCreateSpotLimitOrders defines a SDK message for creating a new batch
/// of spot limit orders.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCreateSpotLimitOrders {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub orders: ::prost::alloc::vec::Vec<SpotOrder>,
}
/// MsgBatchCreateSpotLimitOrdersResponse defines the
/// Msg/BatchCreateSpotLimitOrders response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCreateSpotLimitOrdersResponse {
    #[prost(string, repeated, tag="1")]
    pub order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="2")]
    pub created_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="3")]
    pub failed_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// MsgInstantSpotMarketLaunch defines a SDK message for creating a new spot
/// market by paying listing fee without governance
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgInstantSpotMarketLaunch {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// Ticker for the spot market.
    #[prost(string, tag="2")]
    pub ticker: ::prost::alloc::string::String,
    /// type of coin to use as the base currency
    #[prost(string, tag="3")]
    pub base_denom: ::prost::alloc::string::String,
    /// type of coin to use as the quote currency
    #[prost(string, tag="4")]
    pub quote_denom: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size of the order's price (in
    /// human readable format)
    #[prost(string, tag="5")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the order's
    /// quantity (in human readable format)
    #[prost(string, tag="6")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market (in human readable format)
    #[prost(string, tag="7")]
    pub min_notional: ::prost::alloc::string::String,
    /// base token decimals
    #[prost(uint32, tag="8")]
    pub base_decimals: u32,
    /// quote token decimals
    #[prost(uint32, tag="9")]
    pub quote_decimals: u32,
}
/// MsgInstantSpotMarketLaunchResponse defines the Msg/InstantSpotMarketLaunch
/// response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgInstantSpotMarketLaunchResponse {
}
/// MsgInstantPerpetualMarketLaunch defines a SDK message for creating a new
/// perpetual futures market by paying listing fee without governance
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgInstantPerpetualMarketLaunch {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// Ticker for the derivative market.
    #[prost(string, tag="2")]
    pub ticker: ::prost::alloc::string::String,
    /// type of coin to use as the base currency
    #[prost(string, tag="3")]
    pub quote_denom: ::prost::alloc::string::String,
    /// Oracle base currency
    #[prost(string, tag="4")]
    pub oracle_base: ::prost::alloc::string::String,
    /// Oracle quote currency
    #[prost(string, tag="5")]
    pub oracle_quote: ::prost::alloc::string::String,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="6")]
    pub oracle_scale_factor: u32,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="7")]
    pub oracle_type: i32,
    /// maker_fee_rate defines the trade fee rate for makers on the perpetual
    /// market
    #[prost(string, tag="8")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the trade fee rate for takers on the perpetual
    /// market
    #[prost(string, tag="9")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// initial_margin_ratio defines the initial margin ratio for the perpetual
    /// market
    #[prost(string, tag="10")]
    pub initial_margin_ratio: ::prost::alloc::string::String,
    /// maintenance_margin_ratio defines the maintenance margin ratio for the
    /// perpetual market
    #[prost(string, tag="11")]
    pub maintenance_margin_ratio: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size of the order's price and
    /// margin (in human readable format)
    #[prost(string, tag="12")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the order's
    /// quantity (in human readable format)
    #[prost(string, tag="13")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market (in human readable format)
    #[prost(string, tag="14")]
    pub min_notional: ::prost::alloc::string::String,
    /// reduce_margin_ratio defines the ratio of the margin that is reduced
    #[prost(string, tag="15")]
    pub reduce_margin_ratio: ::prost::alloc::string::String,
    /// open_notional_cap defines the cap on the open notional
    #[prost(message, optional, tag="16")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
}
/// MsgInstantPerpetualMarketLaunchResponse defines the
/// Msg/InstantPerpetualMarketLaunchResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgInstantPerpetualMarketLaunchResponse {
}
/// MsgInstantBinaryOptionsMarketLaunch defines a SDK message for creating a new
/// perpetual futures market by paying listing fee without governance
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgInstantBinaryOptionsMarketLaunch {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// Ticker for the derivative contract.
    #[prost(string, tag="2")]
    pub ticker: ::prost::alloc::string::String,
    /// Oracle symbol
    #[prost(string, tag="3")]
    pub oracle_symbol: ::prost::alloc::string::String,
    /// Oracle Provider
    #[prost(string, tag="4")]
    pub oracle_provider: ::prost::alloc::string::String,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="5")]
    pub oracle_type: i32,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="6")]
    pub oracle_scale_factor: u32,
    /// maker_fee_rate defines the trade fee rate for makers on the perpetual
    /// market
    #[prost(string, tag="7")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the trade fee rate for takers on the perpetual
    /// market
    #[prost(string, tag="8")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// expiration timestamp
    #[prost(int64, tag="9")]
    pub expiration_timestamp: i64,
    /// expiration timestamp
    #[prost(int64, tag="10")]
    pub settlement_timestamp: i64,
    /// admin of the market
    #[prost(string, tag="11")]
    pub admin: ::prost::alloc::string::String,
    /// Address of the quote currency denomination for the binary options contract
    #[prost(string, tag="12")]
    pub quote_denom: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size that the price and margin
    /// required for orders in the market (in human readable format)
    #[prost(string, tag="13")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the quantity
    /// required for orders in the market (in human readable format)
    #[prost(string, tag="14")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market (in human readable format)
    #[prost(string, tag="15")]
    pub min_notional: ::prost::alloc::string::String,
    /// open_notional_cap defines the cap on the open notional
    #[prost(message, optional, tag="16")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
}
/// MsgInstantBinaryOptionsMarketLaunchResponse defines the
/// Msg/InstantBinaryOptionsMarketLaunchResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgInstantBinaryOptionsMarketLaunchResponse {
}
/// MsgInstantExpiryFuturesMarketLaunch defines a SDK message for creating a new
/// expiry futures market by paying listing fee without governance
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgInstantExpiryFuturesMarketLaunch {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// Ticker for the derivative market.
    #[prost(string, tag="2")]
    pub ticker: ::prost::alloc::string::String,
    /// type of coin to use as the quote currency
    #[prost(string, tag="3")]
    pub quote_denom: ::prost::alloc::string::String,
    /// Oracle base currency
    #[prost(string, tag="4")]
    pub oracle_base: ::prost::alloc::string::String,
    /// Oracle quote currency
    #[prost(string, tag="5")]
    pub oracle_quote: ::prost::alloc::string::String,
    /// Oracle type
    #[prost(enumeration="super::super::oracle::v1beta1::OracleType", tag="6")]
    pub oracle_type: i32,
    /// Scale factor for oracle prices.
    #[prost(uint32, tag="7")]
    pub oracle_scale_factor: u32,
    /// Expiration time of the market
    #[prost(int64, tag="8")]
    pub expiry: i64,
    /// maker_fee_rate defines the trade fee rate for makers on the expiry futures
    /// market
    #[prost(string, tag="9")]
    pub maker_fee_rate: ::prost::alloc::string::String,
    /// taker_fee_rate defines the trade fee rate for takers on the expiry futures
    /// market
    #[prost(string, tag="10")]
    pub taker_fee_rate: ::prost::alloc::string::String,
    /// initial_margin_ratio defines the initial margin ratio for the derivative
    /// market
    #[prost(string, tag="11")]
    pub initial_margin_ratio: ::prost::alloc::string::String,
    /// maintenance_margin_ratio defines the maintenance margin ratio for the
    /// derivative market
    #[prost(string, tag="12")]
    pub maintenance_margin_ratio: ::prost::alloc::string::String,
    /// min_price_tick_size defines the minimum tick size of the order's price and
    /// margin
    #[prost(string, tag="13")]
    pub min_price_tick_size: ::prost::alloc::string::String,
    /// min_quantity_tick_size defines the minimum tick size of the order's
    /// quantity
    #[prost(string, tag="14")]
    pub min_quantity_tick_size: ::prost::alloc::string::String,
    /// min_notional defines the minimum notional (in quote asset) required for
    /// orders in the market
    #[prost(string, tag="15")]
    pub min_notional: ::prost::alloc::string::String,
    /// reduce_margin_ratio defines the ratio of the margin that is reduced
    #[prost(string, tag="16")]
    pub reduce_margin_ratio: ::prost::alloc::string::String,
    /// open_notional_cap defines the cap on the open notional
    #[prost(message, optional, tag="17")]
    pub open_notional_cap: ::core::option::Option<OpenNotionalCap>,
}
/// MsgInstantExpiryFuturesMarketLaunchResponse defines the
/// Msg/InstantExpiryFuturesMarketLaunch response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgInstantExpiryFuturesMarketLaunchResponse {
}
/// MsgCreateSpotMarketOrder defines a SDK message for creating a new spot market
/// order.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateSpotMarketOrder {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<SpotOrder>,
}
/// MsgCreateSpotMarketOrderResponse defines the Msg/CreateSpotMarketLimitOrder
/// response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateSpotMarketOrderResponse {
    #[prost(string, tag="1")]
    pub order_hash: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub results: ::core::option::Option<SpotMarketOrderResults>,
    #[prost(string, tag="3")]
    pub cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotMarketOrderResults {
    #[prost(string, tag="1")]
    pub quantity: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub price: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub fee: ::prost::alloc::string::String,
}
/// A Cosmos-SDK MsgCreateDerivativeLimitOrder
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateDerivativeLimitOrder {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<DerivativeOrder>,
}
/// MsgCreateDerivativeLimitOrderResponse defines the
/// Msg/CreateDerivativeMarketOrder response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateDerivativeLimitOrderResponse {
    #[prost(string, tag="1")]
    pub order_hash: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub cid: ::prost::alloc::string::String,
}
/// A Cosmos-SDK MsgCreateBinaryOptionsLimitOrder
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateBinaryOptionsLimitOrder {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<DerivativeOrder>,
}
/// MsgCreateBinaryOptionsLimitOrderResponse defines the
/// Msg/CreateBinaryOptionsLimitOrder response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateBinaryOptionsLimitOrderResponse {
    #[prost(string, tag="1")]
    pub order_hash: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub cid: ::prost::alloc::string::String,
}
/// A Cosmos-SDK MsgBatchCreateDerivativeLimitOrders
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCreateDerivativeLimitOrders {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the orders to create
    #[prost(message, repeated, tag="2")]
    pub orders: ::prost::alloc::vec::Vec<DerivativeOrder>,
}
/// MsgBatchCreateDerivativeLimitOrdersResponse defines the
/// Msg/BatchCreateDerivativeLimitOrders response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCreateDerivativeLimitOrdersResponse {
    #[prost(string, repeated, tag="1")]
    pub order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="2")]
    pub created_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="3")]
    pub failed_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// MsgCancelSpotOrder defines the Msg/CancelSpotOrder response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCancelSpotOrder {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// the subaccount ID
    #[prost(string, tag="3")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the order hash (optional)
    #[prost(string, tag="4")]
    pub order_hash: ::prost::alloc::string::String,
    /// the client order ID (optional)
    #[prost(string, tag="5")]
    pub cid: ::prost::alloc::string::String,
}
/// MsgCancelSpotOrderResponse defines the Msg/CancelSpotOrder response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCancelSpotOrderResponse {
}
/// MsgBatchCancelSpotOrders defines the Msg/BatchCancelSpotOrders response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCancelSpotOrders {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub data: ::prost::alloc::vec::Vec<OrderData>,
}
/// MsgBatchCancelSpotOrdersResponse defines the Msg/BatchCancelSpotOrders
/// response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCancelSpotOrdersResponse {
    #[prost(bool, repeated, tag="1")]
    pub success: ::prost::alloc::vec::Vec<bool>,
}
/// MsgBatchCancelBinaryOptionsOrders defines the
/// Msg/BatchCancelBinaryOptionsOrders response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCancelBinaryOptionsOrders {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub data: ::prost::alloc::vec::Vec<OrderData>,
}
/// BatchCancelBinaryOptionsOrdersResponse defines the
/// Msg/BatchCancelBinaryOptionsOrders response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCancelBinaryOptionsOrdersResponse {
    #[prost(bool, repeated, tag="1")]
    pub success: ::prost::alloc::vec::Vec<bool>,
}
/// MsgBatchUpdateOrders defines the Msg/BatchUpdateOrders response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchUpdateOrders {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// subaccount_id only used for the spot_market_ids_to_cancel_all and
    /// derivative_market_ids_to_cancel_all (optional)
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs to cancel all spot orders for (optional)
    #[prost(string, repeated, tag="3")]
    pub spot_market_ids_to_cancel_all: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// the market IDs to cancel all derivative orders for (optional)
    #[prost(string, repeated, tag="4")]
    pub derivative_market_ids_to_cancel_all: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// the spot orders to cancel
    #[prost(message, repeated, tag="5")]
    pub spot_orders_to_cancel: ::prost::alloc::vec::Vec<OrderData>,
    /// the derivative orders to cancel
    #[prost(message, repeated, tag="6")]
    pub derivative_orders_to_cancel: ::prost::alloc::vec::Vec<OrderData>,
    /// the spot orders to create
    #[prost(message, repeated, tag="7")]
    pub spot_orders_to_create: ::prost::alloc::vec::Vec<SpotOrder>,
    /// the derivative orders to create
    #[prost(message, repeated, tag="8")]
    pub derivative_orders_to_create: ::prost::alloc::vec::Vec<DerivativeOrder>,
    /// the binary options orders to cancel
    #[prost(message, repeated, tag="9")]
    pub binary_options_orders_to_cancel: ::prost::alloc::vec::Vec<OrderData>,
    /// the market IDs to cancel all binary options orders for (optional)
    #[prost(string, repeated, tag="10")]
    pub binary_options_market_ids_to_cancel_all: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// the binary options orders to create
    #[prost(message, repeated, tag="11")]
    pub binary_options_orders_to_create: ::prost::alloc::vec::Vec<DerivativeOrder>,
    /// the spot market orders to create
    #[prost(message, repeated, tag="12")]
    pub spot_market_orders_to_create: ::prost::alloc::vec::Vec<SpotOrder>,
    /// the derivative market orders to create
    #[prost(message, repeated, tag="13")]
    pub derivative_market_orders_to_create: ::prost::alloc::vec::Vec<DerivativeOrder>,
    /// the binary options market orders to create
    #[prost(message, repeated, tag="14")]
    pub binary_options_market_orders_to_create: ::prost::alloc::vec::Vec<DerivativeOrder>,
}
/// MsgBatchUpdateOrdersResponse defines the Msg/BatchUpdateOrders response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchUpdateOrdersResponse {
    #[prost(bool, repeated, tag="1")]
    pub spot_cancel_success: ::prost::alloc::vec::Vec<bool>,
    #[prost(bool, repeated, tag="2")]
    pub derivative_cancel_success: ::prost::alloc::vec::Vec<bool>,
    #[prost(string, repeated, tag="3")]
    pub spot_order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="4")]
    pub derivative_order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(bool, repeated, tag="5")]
    pub binary_options_cancel_success: ::prost::alloc::vec::Vec<bool>,
    #[prost(string, repeated, tag="6")]
    pub binary_options_order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="7")]
    pub created_spot_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="8")]
    pub failed_spot_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="9")]
    pub created_derivative_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="10")]
    pub failed_derivative_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="11")]
    pub created_binary_options_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="12")]
    pub failed_binary_options_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="13")]
    pub spot_market_order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="14")]
    pub created_spot_market_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="15")]
    pub failed_spot_market_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="16")]
    pub derivative_market_order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="17")]
    pub created_derivative_market_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="18")]
    pub failed_derivative_market_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="19")]
    pub binary_options_market_order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="20")]
    pub created_binary_options_market_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="21")]
    pub failed_binary_options_market_orders_cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// A Cosmos-SDK MsgCreateDerivativeMarketOrder
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateDerivativeMarketOrder {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<DerivativeOrder>,
}
/// MsgCreateDerivativeMarketOrderResponse defines the
/// Msg/CreateDerivativeMarketOrder response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateDerivativeMarketOrderResponse {
    #[prost(string, tag="1")]
    pub order_hash: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub results: ::core::option::Option<DerivativeMarketOrderResults>,
    #[prost(string, tag="3")]
    pub cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeMarketOrderResults {
    #[prost(string, tag="1")]
    pub quantity: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub price: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub fee: ::prost::alloc::string::String,
    #[prost(message, optional, tag="4")]
    pub position_delta: ::core::option::Option<PositionDelta>,
    #[prost(string, tag="5")]
    pub payout: ::prost::alloc::string::String,
}
/// A Cosmos-SDK MsgCreateBinaryOptionsMarketOrder
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateBinaryOptionsMarketOrder {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the order details
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<DerivativeOrder>,
}
/// MsgCreateBinaryOptionsMarketOrderResponse defines the
/// Msg/CreateBinaryOptionsMarketOrder response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCreateBinaryOptionsMarketOrderResponse {
    #[prost(string, tag="1")]
    pub order_hash: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub results: ::core::option::Option<DerivativeMarketOrderResults>,
    #[prost(string, tag="3")]
    pub cid: ::prost::alloc::string::String,
}
/// MsgCancelDerivativeOrder defines the Msg/CancelDerivativeOrder response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCancelDerivativeOrder {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// the subaccount ID
    #[prost(string, tag="3")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the order hash (optional)
    #[prost(string, tag="4")]
    pub order_hash: ::prost::alloc::string::String,
    /// the order mask (bitwise combination of OrderMask enum values) (optional)
    #[prost(int32, tag="5")]
    pub order_mask: i32,
    /// the client order ID (optional)
    #[prost(string, tag="6")]
    pub cid: ::prost::alloc::string::String,
}
/// MsgCancelDerivativeOrderResponse defines the
/// Msg/CancelDerivativeOrderResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCancelDerivativeOrderResponse {
}
/// MsgCancelBinaryOptionsOrder defines the Msg/CancelBinaryOptionsOrder response
/// type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCancelBinaryOptionsOrder {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// the subaccount ID
    #[prost(string, tag="3")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the order hash (optional)
    #[prost(string, tag="4")]
    pub order_hash: ::prost::alloc::string::String,
    /// the order mask (bitwise combination of OrderMask enum values) (optional)
    #[prost(int32, tag="5")]
    pub order_mask: i32,
    /// the client order ID (optional)
    #[prost(string, tag="6")]
    pub cid: ::prost::alloc::string::String,
}
/// MsgCancelBinaryOptionsOrderResponse defines the
/// Msg/CancelBinaryOptionsOrderResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCancelBinaryOptionsOrderResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrderData {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// the subaccount ID
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the order hash (optional - either the order_hash or the cid should be
    /// provided)
    #[prost(string, tag="3")]
    pub order_hash: ::prost::alloc::string::String,
    /// the order mask (bitwise combination of OrderMask enum values)
    #[prost(int32, tag="4")]
    pub order_mask: i32,
    /// the client order ID (optional - either the order_hash or the cid should be
    /// provided)
    #[prost(string, tag="5")]
    pub cid: ::prost::alloc::string::String,
}
/// MsgBatchCancelDerivativeOrders defines the Msg/CancelDerivativeOrders
/// response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCancelDerivativeOrders {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub data: ::prost::alloc::vec::Vec<OrderData>,
}
/// MsgBatchCancelDerivativeOrdersResponse defines the
/// Msg/CancelDerivativeOrderResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCancelDerivativeOrdersResponse {
    #[prost(bool, repeated, tag="1")]
    pub success: ::prost::alloc::vec::Vec<bool>,
}
/// A Cosmos-SDK MsgSubaccountTransfer
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSubaccountTransfer {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the source subaccount ID
    #[prost(string, tag="2")]
    pub source_subaccount_id: ::prost::alloc::string::String,
    /// the destination subaccount ID
    #[prost(string, tag="3")]
    pub destination_subaccount_id: ::prost::alloc::string::String,
    /// the amount to transfer (in chain format)
    #[prost(message, optional, tag="4")]
    pub amount: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
}
/// MsgSubaccountTransferResponse defines the Msg/SubaccountTransfer response
/// type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSubaccountTransferResponse {
}
/// A Cosmos-SDK MsgExternalTransfer
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgExternalTransfer {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the source subaccount ID
    #[prost(string, tag="2")]
    pub source_subaccount_id: ::prost::alloc::string::String,
    /// the destination subaccount ID
    #[prost(string, tag="3")]
    pub destination_subaccount_id: ::prost::alloc::string::String,
    /// the amount to transfer (in chain format)
    #[prost(message, optional, tag="4")]
    pub amount: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
}
/// MsgExternalTransferResponse defines the Msg/ExternalTransfer response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgExternalTransferResponse {
}
/// A Cosmos-SDK MsgLiquidatePosition
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgLiquidatePosition {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the subaccount ID the position belongs to
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the position's market ID
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// optional order to provide for liquidation
    #[prost(message, optional, tag="4")]
    pub order: ::core::option::Option<DerivativeOrder>,
}
/// MsgLiquidatePositionResponse defines the Msg/LiquidatePosition response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgLiquidatePositionResponse {
}
/// A Cosmos-SDK MsgOffsetPosition
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgOffsetPosition {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, repeated, tag="4")]
    pub offsetting_subaccount_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// MsgOffsetPositionResponse defines the Msg/OffsetPosition
/// response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgOffsetPositionResponse {
}
/// A Cosmos-SDK MsgEmergencySettleMarket
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgEmergencySettleMarket {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the subaccount ID
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
}
/// MsgEmergencySettleMarketResponse defines the Msg/EmergencySettleMarket
/// response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgEmergencySettleMarketResponse {
}
/// A Cosmos-SDK MsgIncreasePositionMargin
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgIncreasePositionMargin {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the subaccount ID sending the funds
    #[prost(string, tag="2")]
    pub source_subaccount_id: ::prost::alloc::string::String,
    /// the subaccount ID the position belongs to
    #[prost(string, tag="3")]
    pub destination_subaccount_id: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="4")]
    pub market_id: ::prost::alloc::string::String,
    /// amount defines the amount of margin to add to the position (in human
    /// readable format)
    #[prost(string, tag="5")]
    pub amount: ::prost::alloc::string::String,
}
/// MsgIncreasePositionMarginResponse defines the Msg/IncreasePositionMargin
/// response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgIncreasePositionMarginResponse {
}
/// A Cosmos-SDK MsgDecreasePositionMargin
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDecreasePositionMargin {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the subaccount ID the position belongs to
    #[prost(string, tag="2")]
    pub source_subaccount_id: ::prost::alloc::string::String,
    /// the destination subaccount ID
    #[prost(string, tag="3")]
    pub destination_subaccount_id: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="4")]
    pub market_id: ::prost::alloc::string::String,
    /// amount defines the amount of margin to withdraw from the position (in human
    /// readable format)
    #[prost(string, tag="5")]
    pub amount: ::prost::alloc::string::String,
}
/// MsgDecreasePositionMarginResponse defines the Msg/MsgDecreasePositionMargin
/// response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDecreasePositionMarginResponse {
}
/// MsgPrivilegedExecuteContract defines the Msg/Exec message type
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgPrivilegedExecuteContract {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// funds defines the user's bank coins used to fund the execution (e.g.
    /// 100inj).
    #[prost(string, tag="2")]
    pub funds: ::prost::alloc::string::String,
    /// contract_address defines the contract address to execute
    #[prost(string, tag="3")]
    pub contract_address: ::prost::alloc::string::String,
    /// data defines the call data used when executing the contract
    #[prost(string, tag="4")]
    pub data: ::prost::alloc::string::String,
}
/// MsgPrivilegedExecuteContractResponse defines the Msg/Exec response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgPrivilegedExecuteContractResponse {
    #[prost(message, repeated, tag="1")]
    pub funds_diff: ::prost::alloc::vec::Vec<super::super::super::cosmos::base::v1beta1::Coin>,
}
/// A Cosmos-SDK MsgRewardsOptOut
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgRewardsOptOut {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
}
/// MsgRewardsOptOutResponse defines the Msg/RewardsOptOut response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgRewardsOptOutResponse {
}
/// A Cosmos-SDK MsgReclaimLockedFunds
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgReclaimLockedFunds {
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="2")]
    pub locked_account_pub_key: ::prost::alloc::vec::Vec<u8>,
    #[prost(bytes="vec", tag="3")]
    pub signature: ::prost::alloc::vec::Vec<u8>,
}
/// MsgReclaimLockedFundsResponse defines the Msg/ReclaimLockedFunds response
/// type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgReclaimLockedFundsResponse {
}
/// MsgSignData defines an arbitrary, general-purpose, off-chain message
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSignData {
    /// Signer is the sdk.AccAddress of the message signer
    #[prost(bytes="vec", tag="1")]
    pub signer: ::prost::alloc::vec::Vec<u8>,
    /// Data represents the raw bytes of the content that is signed (text, json,
    /// etc)
    #[prost(bytes="vec", tag="2")]
    pub data: ::prost::alloc::vec::Vec<u8>,
}
/// MsgSignDoc defines an arbitrary, general-purpose, off-chain message
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSignDoc {
    #[prost(string, tag="1")]
    pub sign_type: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub value: ::core::option::Option<MsgSignData>,
}
/// MsgAdminUpdateBinaryOptionsMarket is used by the market Admin to operate the
/// market
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgAdminUpdateBinaryOptionsMarket {
    /// The sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// The market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// new price at which market will be settled
    #[prost(string, tag="3")]
    pub settlement_price: ::prost::alloc::string::String,
    /// expiration timestamp
    #[prost(int64, tag="4")]
    pub expiration_timestamp: i64,
    /// expiration timestamp
    #[prost(int64, tag="5")]
    pub settlement_timestamp: i64,
    /// Status of the market
    #[prost(enumeration="MarketStatus", tag="6")]
    pub status: i32,
}
/// MsgAdminUpdateBinaryOptionsMarketResponse is the response for
/// AdminUpdateBinaryOptionsMarket rpc method
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgAdminUpdateBinaryOptionsMarketResponse {
}
/// MsgAuthorizeStakeGrants grants stakes to grantees.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgAuthorizeStakeGrants {
    /// Injective address of the stake granter
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// list of stake grants to authorize (mandatory)
    #[prost(message, repeated, tag="2")]
    pub grants: ::prost::alloc::vec::Vec<GrantAuthorization>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgAuthorizeStakeGrantsResponse {
}
/// MsgActivateStakeGrant allows a grantee to activate a stake grant.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgActivateStakeGrant {
    /// Injective address of the stake grantee
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// Injective address of the stake granter
    #[prost(string, tag="2")]
    pub granter: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgActivateStakeGrantResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchExchangeModification {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<BatchExchangeModificationProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchExchangeModificationResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSpotMarketLaunch {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<SpotMarketLaunchProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSpotMarketLaunchResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgPerpetualMarketLaunch {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<PerpetualMarketLaunchProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgPerpetualMarketLaunchResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgExpiryFuturesMarketLaunch {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<ExpiryFuturesMarketLaunchProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgExpiryFuturesMarketLaunchResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBinaryOptionsMarketLaunch {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<BinaryOptionsMarketLaunchProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBinaryOptionsMarketLaunchResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCommunityPoolSpend {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<BatchCommunityPoolSpendProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBatchCommunityPoolSpendResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSpotMarketParamUpdate {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<SpotMarketParamUpdateProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgSpotMarketParamUpdateResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDerivativeMarketParamUpdate {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<DerivativeMarketParamUpdateProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgDerivativeMarketParamUpdateResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBinaryOptionsMarketParamUpdate {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<BinaryOptionsMarketParamUpdateProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgBinaryOptionsMarketParamUpdateResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgMarketForcedSettlement {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<MarketForcedSettlementProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgMarketForcedSettlementResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgTradingRewardCampaignLaunch {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<TradingRewardCampaignLaunchProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgTradingRewardCampaignLaunchResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgExchangeEnable {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<ExchangeEnableProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgExchangeEnableResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgTradingRewardCampaignUpdate {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<TradingRewardCampaignUpdateProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgTradingRewardCampaignUpdateResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgTradingRewardPendingPointsUpdate {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<TradingRewardPendingPointsUpdateProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgTradingRewardPendingPointsUpdateResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgFeeDiscount {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<FeeDiscountProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgFeeDiscountResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgAtomicMarketOrderFeeMultiplierSchedule {
    /// message sender, that is also the TX signer
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub proposal: ::core::option::Option<AtomicMarketOrderFeeMultiplierScheduleProposal>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgAtomicMarketOrderFeeMultiplierScheduleResponse {
}
/// MsgCancelPostOnlyMode defines a message for canceling post-only mode
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCancelPostOnlyMode {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
}
/// MsgCancelPostOnlyModeResponse defines the response for MsgCancelPostOnlyMode
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgCancelPostOnlyModeResponse {
}
/// MsgActivatePostOnlyMode defines a message to turn on the post-only mode for a
/// number of blocks
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgActivatePostOnlyMode {
    /// the sender's Injective address
    #[prost(string, tag="1")]
    pub sender: ::prost::alloc::string::String,
    /// the number of blocks to activate post-only mode for
    #[prost(uint32, tag="2")]
    pub blocks_amount: u32,
}
/// MsgActivatePostOnlyModeResponse defines the response for
/// MsgActivatePostOnlyMode
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MsgActivatePostOnlyModeResponse {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventBatchSpotExecution {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub is_buy: bool,
    #[prost(enumeration="ExecutionType", tag="3")]
    pub execution_type: i32,
    #[prost(message, repeated, tag="4")]
    pub trades: ::prost::alloc::vec::Vec<TradeLog>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventBatchDerivativeExecution {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub is_buy: bool,
    #[prost(bool, tag="3")]
    pub is_liquidation: bool,
    /// nil for time expiry futures
    #[prost(string, tag="4")]
    pub cumulative_funding: ::prost::alloc::string::String,
    #[prost(enumeration="ExecutionType", tag="5")]
    pub execution_type: i32,
    #[prost(message, repeated, tag="6")]
    pub trades: ::prost::alloc::vec::Vec<DerivativeTradeLog>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventLostFundsFromLiquidation {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="2")]
    pub subaccount_id: ::prost::alloc::vec::Vec<u8>,
    #[prost(string, tag="3")]
    pub lost_funds_from_available_during_payout: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub lost_funds_from_order_cancels: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventBatchDerivativePosition {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub positions: ::prost::alloc::vec::Vec<SubaccountPosition>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventDerivativeMarketPaused {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub settle_price: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub total_missing_funds: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub missing_funds_rate: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSettledMarketBalance {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventNotSettledMarketBalance {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventMarketBeyondBankruptcy {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub settle_price: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub missing_market_funds: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventAllPositionsHaircut {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub settle_price: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub missing_funds_rate: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventBinaryOptionsMarketUpdate {
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<BinaryOptionsMarket>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventDerivativeMarketUpdate {
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<DerivativeMarket>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventNewSpotOrders {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub buy_orders: ::prost::alloc::vec::Vec<SpotLimitOrder>,
    #[prost(message, repeated, tag="3")]
    pub sell_orders: ::prost::alloc::vec::Vec<SpotLimitOrder>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventNewDerivativeOrders {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub buy_orders: ::prost::alloc::vec::Vec<DerivativeLimitOrder>,
    #[prost(message, repeated, tag="3")]
    pub sell_orders: ::prost::alloc::vec::Vec<DerivativeLimitOrder>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCancelSpotOrder {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<SpotLimitOrder>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSpotMarketUpdate {
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<SpotMarket>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventPerpetualMarketUpdate {
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<DerivativeMarket>,
    #[prost(message, optional, tag="2")]
    pub perpetual_market_info: ::core::option::Option<PerpetualMarketInfo>,
    #[prost(message, optional, tag="3")]
    pub funding: ::core::option::Option<PerpetualMarketFunding>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventExpiryFuturesMarketUpdate {
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<DerivativeMarket>,
    #[prost(message, optional, tag="3")]
    pub expiry_futures_market_info: ::core::option::Option<ExpiryFuturesMarketInfo>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventPerpetualMarketFundingUpdate {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub funding: ::core::option::Option<PerpetualMarketFunding>,
    #[prost(bool, tag="3")]
    pub is_hourly_funding: bool,
    #[prost(string, tag="4")]
    pub funding_rate: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub mark_price: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSubaccountDeposit {
    #[prost(string, tag="1")]
    pub src_address: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="2")]
    pub subaccount_id: ::prost::alloc::vec::Vec<u8>,
    #[prost(message, optional, tag="3")]
    pub amount: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSubaccountWithdraw {
    #[prost(bytes="vec", tag="1")]
    pub subaccount_id: ::prost::alloc::vec::Vec<u8>,
    #[prost(string, tag="2")]
    pub dst_address: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub amount: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSubaccountBalanceTransfer {
    #[prost(string, tag="1")]
    pub src_subaccount_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub dst_subaccount_id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub amount: ::core::option::Option<super::super::super::cosmos::base::v1beta1::Coin>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventBatchDepositUpdate {
    #[prost(message, repeated, tag="1")]
    pub deposit_updates: ::prost::alloc::vec::Vec<DepositUpdate>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeMarketOrderCancel {
    #[prost(message, optional, tag="1")]
    pub market_order: ::core::option::Option<DerivativeMarketOrder>,
    #[prost(string, tag="2")]
    pub cancel_quantity: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCancelDerivativeOrder {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub is_limit_cancel: bool,
    #[prost(message, optional, tag="3")]
    pub limit_order: ::core::option::Option<DerivativeLimitOrder>,
    #[prost(message, optional, tag="4")]
    pub market_order_cancel: ::core::option::Option<DerivativeMarketOrderCancel>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventFeeDiscountSchedule {
    #[prost(message, optional, tag="1")]
    pub schedule: ::core::option::Option<FeeDiscountSchedule>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventTradingRewardCampaignUpdate {
    #[prost(message, optional, tag="1")]
    pub campaign_info: ::core::option::Option<TradingRewardCampaignInfo>,
    #[prost(message, repeated, tag="2")]
    pub campaign_reward_pools: ::prost::alloc::vec::Vec<CampaignRewardPool>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventTradingRewardDistribution {
    #[prost(message, repeated, tag="1")]
    pub account_rewards: ::prost::alloc::vec::Vec<AccountRewards>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventNewConditionalDerivativeOrder {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub order: ::core::option::Option<DerivativeOrder>,
    #[prost(bytes="vec", tag="3")]
    pub hash: ::prost::alloc::vec::Vec<u8>,
    #[prost(bool, tag="4")]
    pub is_market: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventCancelConditionalDerivativeOrder {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub is_limit_cancel: bool,
    #[prost(message, optional, tag="3")]
    pub limit_order: ::core::option::Option<DerivativeLimitOrder>,
    #[prost(message, optional, tag="4")]
    pub market_order: ::core::option::Option<DerivativeMarketOrder>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventConditionalDerivativeOrderTrigger {
    #[prost(bytes="vec", tag="1")]
    pub market_id: ::prost::alloc::vec::Vec<u8>,
    #[prost(bool, tag="2")]
    pub is_limit_trigger: bool,
    #[prost(bytes="vec", tag="3")]
    pub triggered_order_hash: ::prost::alloc::vec::Vec<u8>,
    #[prost(bytes="vec", tag="4")]
    pub placed_order_hash: ::prost::alloc::vec::Vec<u8>,
    #[prost(string, tag="5")]
    pub triggered_order_cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventOrderFail {
    #[prost(bytes="vec", tag="1")]
    pub account: ::prost::alloc::vec::Vec<u8>,
    #[prost(bytes="vec", repeated, tag="2")]
    pub hashes: ::prost::alloc::vec::Vec<::prost::alloc::vec::Vec<u8>>,
    #[prost(uint32, repeated, tag="3")]
    pub flags: ::prost::alloc::vec::Vec<u32>,
    #[prost(string, repeated, tag="4")]
    pub cids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventAtomicMarketOrderFeeMultipliersUpdated {
    #[prost(message, repeated, tag="1")]
    pub market_fee_multipliers: ::prost::alloc::vec::Vec<MarketFeeMultiplier>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventOrderbookUpdate {
    #[prost(message, repeated, tag="1")]
    pub spot_updates: ::prost::alloc::vec::Vec<OrderbookUpdate>,
    #[prost(message, repeated, tag="2")]
    pub derivative_updates: ::prost::alloc::vec::Vec<OrderbookUpdate>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrderbookUpdate {
    #[prost(uint64, tag="1")]
    pub seq: u64,
    #[prost(message, optional, tag="2")]
    pub orderbook: ::core::option::Option<Orderbook>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Orderbook {
    #[prost(bytes="vec", tag="1")]
    pub market_id: ::prost::alloc::vec::Vec<u8>,
    #[prost(message, repeated, tag="2")]
    pub buy_levels: ::prost::alloc::vec::Vec<Level>,
    #[prost(message, repeated, tag="3")]
    pub sell_levels: ::prost::alloc::vec::Vec<Level>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventGrantAuthorizations {
    #[prost(string, tag="1")]
    pub granter: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub grants: ::prost::alloc::vec::Vec<GrantAuthorization>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventGrantActivation {
    #[prost(string, tag="1")]
    pub grantee: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub granter: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub amount: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventInvalidGrant {
    #[prost(string, tag="1")]
    pub grantee: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub granter: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventOrderCancelFail {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub order_hash: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub cid: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub description: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventDerivativeOrdersV2Migration {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub buy_order_changes: ::prost::alloc::vec::Vec<DerivativeOrderV2Changes>,
    #[prost(message, repeated, tag="3")]
    pub sell_order_changes: ::prost::alloc::vec::Vec<DerivativeOrderV2Changes>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeOrderV2Changes {
    #[prost(string, tag="1")]
    pub cid: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="2")]
    pub hash: ::prost::alloc::vec::Vec<u8>,
    /// price of the order
    #[prost(string, tag="3")]
    pub p: ::prost::alloc::string::String,
    /// quantity of the order
    #[prost(string, tag="4")]
    pub q: ::prost::alloc::string::String,
    /// margin of the order
    #[prost(string, tag="5")]
    pub m: ::prost::alloc::string::String,
    /// the amount of the quantity remaining fillable
    #[prost(string, tag="6")]
    pub f: ::prost::alloc::string::String,
    /// trigger price of the order
    #[prost(string, tag="7")]
    pub tp: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventSpotOrdersV2Migration {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub buy_order_changes: ::prost::alloc::vec::Vec<SpotOrderV2Changes>,
    #[prost(message, repeated, tag="3")]
    pub sell_order_changes: ::prost::alloc::vec::Vec<SpotOrderV2Changes>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventTriggerConditionalMarketOrderFailed {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub mark_price: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="4")]
    pub order_hash: ::prost::alloc::vec::Vec<u8>,
    #[prost(string, tag="5")]
    pub trigger_err: ::prost::alloc::string::String,
    #[prost(string, tag="6")]
    pub cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventTriggerConditionalLimitOrderFailed {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub mark_price: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="4")]
    pub order_hash: ::prost::alloc::vec::Vec<u8>,
    #[prost(string, tag="5")]
    pub trigger_err: ::prost::alloc::string::String,
    #[prost(string, tag="6")]
    pub cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotOrderV2Changes {
    #[prost(string, tag="1")]
    pub cid: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="2")]
    pub hash: ::prost::alloc::vec::Vec<u8>,
    /// price of the order
    #[prost(string, tag="3")]
    pub p: ::prost::alloc::string::String,
    /// quantity of the order
    #[prost(string, tag="4")]
    pub q: ::prost::alloc::string::String,
    /// the amount of the quantity remaining fillable
    #[prost(string, tag="5")]
    pub f: ::prost::alloc::string::String,
    /// trigger_price is the trigger price used by stop/take orders
    #[prost(string, tag="6")]
    pub tp: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventDerivativePositionV2Migration {
    #[prost(message, optional, tag="1")]
    pub position: ::core::option::Option<DerivativePosition>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EventPositionTransfer {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub source_subaccount_id: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub destination_subaccount_id: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub quantity: ::prost::alloc::string::String,
}
/// Spot Exchange Limit Orderbook
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SpotOrderBook {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub is_buy_side: bool,
    #[prost(message, repeated, tag="3")]
    pub orders: ::prost::alloc::vec::Vec<SpotLimitOrder>,
}
/// Derivative Exchange Limit Orderbook
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeOrderBook {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub is_buy_side: bool,
    #[prost(message, repeated, tag="3")]
    pub orders: ::prost::alloc::vec::Vec<DerivativeLimitOrder>,
}
/// Orderbook containing limit & market conditional orders
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ConditionalDerivativeOrderBook {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub limit_buy_orders: ::prost::alloc::vec::Vec<DerivativeLimitOrder>,
    #[prost(message, repeated, tag="3")]
    pub market_buy_orders: ::prost::alloc::vec::Vec<DerivativeMarketOrder>,
    #[prost(message, repeated, tag="4")]
    pub limit_sell_orders: ::prost::alloc::vec::Vec<DerivativeLimitOrder>,
    #[prost(message, repeated, tag="5")]
    pub market_sell_orders: ::prost::alloc::vec::Vec<DerivativeMarketOrder>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountOrderbookMetadata {
    /// The number of vanilla limit orders
    #[prost(uint32, tag="1")]
    pub vanilla_limit_order_count: u32,
    /// The number of reduce-only limit orders
    #[prost(uint32, tag="2")]
    pub reduce_only_limit_order_count: u32,
    /// The aggregate quantity of the subaccount's reduce-only limit orders (in
    /// human readable format)
    #[prost(string, tag="3")]
    pub aggregate_reduce_only_quantity: ::prost::alloc::string::String,
    /// The aggregate quantity of the subaccount's vanilla limit orders (in human
    /// readable format)
    #[prost(string, tag="4")]
    pub aggregate_vanilla_quantity: ::prost::alloc::string::String,
    /// The number of vanilla conditional orders
    #[prost(uint32, tag="5")]
    pub vanilla_conditional_order_count: u32,
    /// The number of reduce-only conditional orders
    #[prost(uint32, tag="6")]
    pub reduce_only_conditional_order_count: u32,
}
/// GenesisState defines the exchange module's genesis state.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenesisState {
    /// params defines all the parameters of related to exchange.
    #[prost(message, optional, tag="1")]
    pub params: ::core::option::Option<Params>,
    /// spot_markets is an array containing the genesis trade pairs
    #[prost(message, repeated, tag="2")]
    pub spot_markets: ::prost::alloc::vec::Vec<SpotMarket>,
    /// derivative_markets is an array containing the genesis derivative markets
    #[prost(message, repeated, tag="3")]
    pub derivative_markets: ::prost::alloc::vec::Vec<DerivativeMarket>,
    /// spot_orderbook defines the spot exchange limit orderbook active at genesis.
    #[prost(message, repeated, tag="4")]
    pub spot_orderbook: ::prost::alloc::vec::Vec<SpotOrderBook>,
    /// derivative_orderbook defines the derivative exchange limit orderbook active
    /// at genesis.
    #[prost(message, repeated, tag="5")]
    pub derivative_orderbook: ::prost::alloc::vec::Vec<DerivativeOrderBook>,
    /// balances defines the exchange users balances active at genesis.
    #[prost(message, repeated, tag="6")]
    pub balances: ::prost::alloc::vec::Vec<Balance>,
    /// positions defines the exchange derivative positions at genesis
    #[prost(message, repeated, tag="7")]
    pub positions: ::prost::alloc::vec::Vec<DerivativePosition>,
    /// subaccount_trade_nonces defines the subaccount trade nonces for the
    /// subaccounts at genesis
    #[prost(message, repeated, tag="8")]
    pub subaccount_trade_nonces: ::prost::alloc::vec::Vec<SubaccountNonce>,
    /// expiry_futures_market_info defines the market info for the expiry futures
    /// markets at genesis
    #[prost(message, repeated, tag="9")]
    pub expiry_futures_market_info_state: ::prost::alloc::vec::Vec<ExpiryFuturesMarketInfoState>,
    /// perpetual_market_info defines the market info for the perpetual derivative
    /// markets at genesis
    #[prost(message, repeated, tag="10")]
    pub perpetual_market_info: ::prost::alloc::vec::Vec<PerpetualMarketInfo>,
    /// perpetual_market_funding_state defines the funding state for the perpetual
    /// derivative markets at genesis
    #[prost(message, repeated, tag="11")]
    pub perpetual_market_funding_state: ::prost::alloc::vec::Vec<PerpetualMarketFundingState>,
    /// derivative_market_settlement_scheduled defines the scheduled markets for
    /// settlement at genesis
    #[prost(message, repeated, tag="12")]
    pub derivative_market_settlement_scheduled: ::prost::alloc::vec::Vec<DerivativeMarketSettlementInfo>,
    /// sets spot markets as enabled
    #[prost(bool, tag="13")]
    pub is_spot_exchange_enabled: bool,
    /// sets derivative markets as enabled
    #[prost(bool, tag="14")]
    pub is_derivatives_exchange_enabled: bool,
    /// the current trading reward campaign info
    #[prost(message, optional, tag="15")]
    pub trading_reward_campaign_info: ::core::option::Option<TradingRewardCampaignInfo>,
    /// the current and upcoming trading reward campaign pools
    #[prost(message, repeated, tag="16")]
    pub trading_reward_pool_campaign_schedule: ::prost::alloc::vec::Vec<CampaignRewardPool>,
    /// the current trading reward account points
    #[prost(message, repeated, tag="17")]
    pub trading_reward_campaign_account_points: ::prost::alloc::vec::Vec<TradingRewardCampaignAccountPoints>,
    /// the fee discount schedule
    #[prost(message, optional, tag="18")]
    pub fee_discount_schedule: ::core::option::Option<FeeDiscountSchedule>,
    /// the cached fee discount account tiers with TTL
    #[prost(message, repeated, tag="19")]
    pub fee_discount_account_tier_ttl: ::prost::alloc::vec::Vec<FeeDiscountAccountTierTtl>,
    /// the fee discount paid by accounts in all buckets
    #[prost(message, repeated, tag="20")]
    pub fee_discount_bucket_volume_accounts: ::prost::alloc::vec::Vec<FeeDiscountBucketVolumeAccounts>,
    /// sets the first fee cycle as finished
    #[prost(bool, tag="21")]
    pub is_first_fee_cycle_finished: bool,
    /// the current and upcoming trading reward campaign pending pools
    #[prost(message, repeated, tag="22")]
    pub pending_trading_reward_pool_campaign_schedule: ::prost::alloc::vec::Vec<CampaignRewardPool>,
    /// the pending trading reward account points
    #[prost(message, repeated, tag="23")]
    pub pending_trading_reward_campaign_account_points: ::prost::alloc::vec::Vec<TradingRewardCampaignAccountPendingPoints>,
    /// the addresses opting out of trading rewards
    #[prost(string, repeated, tag="24")]
    pub rewards_opt_out_addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(message, repeated, tag="25")]
    pub historical_trade_records: ::prost::alloc::vec::Vec<TradeRecords>,
    /// binary_options_markets is an array containing the genesis binary options
    /// markets
    #[prost(message, repeated, tag="26")]
    pub binary_options_markets: ::prost::alloc::vec::Vec<BinaryOptionsMarket>,
    /// binary_options_markets_scheduled_for_settlement contains the marketIDs of
    /// binary options markets scheduled for next-block settlement
    #[prost(string, repeated, tag="27")]
    pub binary_options_market_ids_scheduled_for_settlement: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// spot_market_ids_scheduled_to_force_close defines the scheduled markets for
    /// forced closings at genesis
    #[prost(string, repeated, tag="28")]
    pub spot_market_ids_scheduled_to_force_close: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// auction_exchange_transfer_denom_decimals defines the denom decimals for the
    /// exchange.
    #[prost(message, repeated, tag="29")]
    pub auction_exchange_transfer_denom_decimals: ::prost::alloc::vec::Vec<DenomDecimals>,
    /// conditional_derivative_orderbook contains conditional orderbooks for all
    /// markets (both lmit and market conditional orders)
    #[prost(message, repeated, tag="30")]
    pub conditional_derivative_orderbooks: ::prost::alloc::vec::Vec<ConditionalDerivativeOrderBook>,
    /// market_fee_multipliers contains any non-default atomic order fee
    /// multipliers
    #[prost(message, repeated, tag="31")]
    pub market_fee_multipliers: ::prost::alloc::vec::Vec<MarketFeeMultiplier>,
    #[prost(message, repeated, tag="32")]
    pub orderbook_sequences: ::prost::alloc::vec::Vec<OrderbookSequence>,
    #[prost(message, repeated, tag="33")]
    pub subaccount_volumes: ::prost::alloc::vec::Vec<AggregateSubaccountVolumeRecord>,
    #[prost(message, repeated, tag="34")]
    pub market_volumes: ::prost::alloc::vec::Vec<MarketVolume>,
    #[prost(message, repeated, tag="35")]
    pub grant_authorizations: ::prost::alloc::vec::Vec<FullGrantAuthorizations>,
    #[prost(message, repeated, tag="36")]
    pub active_grants: ::prost::alloc::vec::Vec<FullActiveGrant>,
    #[prost(message, repeated, tag="37")]
    pub denom_min_notionals: ::prost::alloc::vec::Vec<DenomMinNotional>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrderbookSequence {
    #[prost(uint64, tag="1")]
    pub sequence: u64,
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FeeDiscountAccountTierTtl {
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub tier_ttl: ::core::option::Option<FeeDiscountTierTtl>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FeeDiscountBucketVolumeAccounts {
    #[prost(int64, tag="1")]
    pub bucket_start_timestamp: i64,
    #[prost(message, repeated, tag="2")]
    pub account_volume: ::prost::alloc::vec::Vec<AccountVolume>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AccountVolume {
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub volume: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradingRewardCampaignAccountPoints {
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub points: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradingRewardCampaignAccountPendingPoints {
    #[prost(int64, tag="1")]
    pub reward_pool_start_timestamp: i64,
    #[prost(message, repeated, tag="2")]
    pub account_points: ::prost::alloc::vec::Vec<TradingRewardCampaignAccountPoints>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountNonce {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the subaccount trade nonce
    #[prost(message, optional, tag="2")]
    pub subaccount_trade_nonce: ::core::option::Option<SubaccountTradeNonce>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FullGrantAuthorizations {
    #[prost(string, tag="1")]
    pub granter: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub total_grant_amount: ::prost::alloc::string::String,
    #[prost(int64, tag="3")]
    pub last_delegations_checked_time: i64,
    #[prost(message, repeated, tag="4")]
    pub grants: ::prost::alloc::vec::Vec<GrantAuthorization>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FullActiveGrant {
    #[prost(string, tag="1")]
    pub grantee: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub active_grant: ::core::option::Option<ActiveGrant>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Subaccount {
    /// the subaccount's trader address
    #[prost(string, tag="1")]
    pub trader: ::prost::alloc::string::String,
    /// the subaccount's nonce number
    #[prost(uint32, tag="2")]
    pub subaccount_nonce: u32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountOrdersRequest {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountOrdersResponse {
    #[prost(message, repeated, tag="1")]
    pub buy_orders: ::prost::alloc::vec::Vec<SubaccountOrderData>,
    #[prost(message, repeated, tag="2")]
    pub sell_orders: ::prost::alloc::vec::Vec<SubaccountOrderData>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SubaccountOrderbookMetadataWithMarket {
    /// the subaccount orderbook details
    #[prost(message, optional, tag="1")]
    pub metadata: ::core::option::Option<SubaccountOrderbookMetadata>,
    /// the market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// true if the orderbook is for a buy orders
    #[prost(bool, tag="3")]
    pub is_buy: bool,
}
/// QueryExchangeParamsRequest is the request type for the Query/ExchangeParams
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryExchangeParamsRequest {
}
/// QueryExchangeParamsRequest is the response type for the Query/ExchangeParams
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryExchangeParamsResponse {
    #[prost(message, optional, tag="1")]
    pub params: ::core::option::Option<Params>,
}
/// QuerySubaccountDepositsRequest is the request type for the
/// Query/SubaccountDeposits RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountDepositsRequest {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the subaccount details
    #[prost(message, optional, tag="2")]
    pub subaccount: ::core::option::Option<Subaccount>,
}
/// QuerySubaccountDepositsResponse is the response type for the
/// Query/SubaccountDeposits RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountDepositsResponse {
    #[prost(map="string, message", tag="1")]
    pub deposits: ::std::collections::HashMap<::prost::alloc::string::String, Deposit>,
}
/// QueryExchangeBalancesRequest is the request type for the
/// Query/ExchangeBalances RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryExchangeBalancesRequest {
}
/// QuerySubaccountDepositsResponse is the response type for the
/// Query/SubaccountDeposits RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryExchangeBalancesResponse {
    #[prost(message, repeated, tag="1")]
    pub balances: ::prost::alloc::vec::Vec<Balance>,
}
/// QueryAggregateVolumeRequest is the request type for the Query/AggregateVolume
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAggregateVolumeRequest {
    /// can either be an address or a subaccount
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
}
/// QueryAggregateVolumeResponse is the response type for the
/// Query/AggregateVolume RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAggregateVolumeResponse {
    /// if an address is specified, then the aggregate_volumes will aggregate the
    /// volumes across all subaccounts for the address
    #[prost(message, repeated, tag="1")]
    pub aggregate_volumes: ::prost::alloc::vec::Vec<MarketVolume>,
}
/// QueryAggregateVolumesRequest is the request type for the
/// Query/AggregateVolumes RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAggregateVolumesRequest {
    #[prost(string, repeated, tag="1")]
    pub accounts: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QueryAggregateVolumesResponse is the response type for the
/// Query/AggregateVolumes RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAggregateVolumesResponse {
    /// the aggregate volume records for the accounts specified
    #[prost(message, repeated, tag="1")]
    pub aggregate_account_volumes: ::prost::alloc::vec::Vec<AggregateAccountVolumeRecord>,
    /// the aggregate volumes for the markets specified
    #[prost(message, repeated, tag="2")]
    pub aggregate_market_volumes: ::prost::alloc::vec::Vec<MarketVolume>,
}
/// QueryAggregateMarketVolumeRequest is the request type for the
/// Query/AggregateMarketVolume RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAggregateMarketVolumeRequest {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QueryAggregateMarketVolumeResponse is the response type for the
/// Query/AggregateMarketVolume RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAggregateMarketVolumeResponse {
    #[prost(message, optional, tag="1")]
    pub volume: ::core::option::Option<VolumeRecord>,
}
/// QueryAuctionExchangeTransferDenomDecimalRequest is the request type for the
/// Query/DenomDecimal RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAuctionExchangeTransferDenomDecimalRequest {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
}
/// QueryDenomDecimalResponse is the response type for the Query/DenomDecimal RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAuctionExchangeTransferDenomDecimalResponse {
    #[prost(uint64, tag="1")]
    pub decimal: u64,
}
/// QueryDenomDecimalsRequest is the request type for the Query/DenomDecimals RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAuctionExchangeTransferDenomDecimalsRequest {
    /// denoms can be empty to query all denom decimals
    #[prost(string, repeated, tag="1")]
    pub denoms: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QueryDenomDecimalsRequest is the response type for the Query/DenomDecimals
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAuctionExchangeTransferDenomDecimalsResponse {
    #[prost(message, repeated, tag="1")]
    pub denom_decimals: ::prost::alloc::vec::Vec<DenomDecimals>,
}
/// QueryAggregateMarketVolumesRequest is the request type for the
/// Query/AggregateMarketVolumes RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAggregateMarketVolumesRequest {
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QueryAggregateMarketVolumesResponse is the response type for the
/// Query/AggregateMarketVolumes RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAggregateMarketVolumesResponse {
    /// the aggregate volumes for the entire market
    #[prost(message, repeated, tag="1")]
    pub volumes: ::prost::alloc::vec::Vec<MarketVolume>,
}
/// QuerySubaccountDepositsRequest is the request type for the
/// Query/SubaccountDeposits RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountDepositRequest {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the token denom
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
}
/// QuerySubaccountDepositsResponse is the response type for the
/// Query/SubaccountDeposits RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountDepositResponse {
    #[prost(message, optional, tag="1")]
    pub deposits: ::core::option::Option<Deposit>,
}
/// QuerySpotMarketsRequest is the request type for the Query/SpotMarkets RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotMarketsRequest {
    /// Status of the market, for convenience it is set to string - not enum
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
    /// Filter by market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QuerySpotMarketsResponse is the response type for the Query/SpotMarkets RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotMarketsResponse {
    #[prost(message, repeated, tag="1")]
    pub markets: ::prost::alloc::vec::Vec<SpotMarket>,
}
/// QuerySpotMarketRequest is the request type for the Query/SpotMarket RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotMarketRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QuerySpotMarketResponse is the response type for the Query/SpotMarket RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotMarketResponse {
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<SpotMarket>,
}
/// QuerySpotOrderbookRequest is the request type for the Query/SpotOrderbook RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotOrderbookRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// the maximum number of orderbook entries to return per side (optional)
    #[prost(uint64, tag="2")]
    pub limit: u64,
    /// the order side to return the orderbook entries for (optional)
    #[prost(enumeration="OrderSide", tag="3")]
    pub order_side: i32,
    /// limits the number of entries to return per side based on the cumulative
    /// notional (in human readable format)
    #[prost(string, tag="4")]
    pub limit_cumulative_notional: ::prost::alloc::string::String,
    /// limits the number of entries to return per side based on the cumulative
    /// quantity (in human readable format)
    #[prost(string, tag="5")]
    pub limit_cumulative_quantity: ::prost::alloc::string::String,
}
/// QuerySpotOrderbookResponse is the response type for the Query/SpotOrderbook
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotOrderbookResponse {
    #[prost(message, repeated, tag="1")]
    pub buys_price_level: ::prost::alloc::vec::Vec<Level>,
    #[prost(message, repeated, tag="2")]
    pub sells_price_level: ::prost::alloc::vec::Vec<Level>,
    /// the current orderbook sequence number
    #[prost(uint64, tag="3")]
    pub seq: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FullSpotMarket {
    /// spot market details
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<SpotMarket>,
    /// mid_price_and_tob defines the mid price for this market and the best ask
    /// and bid orders
    #[prost(message, optional, tag="2")]
    pub mid_price_and_tob: ::core::option::Option<MidPriceAndTob>,
}
/// QueryFullSpotMarketsRequest is the request type for the Query/FullSpotMarkets
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFullSpotMarketsRequest {
    /// Status of the market, for convenience it is set to string - not enum
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
    /// Filter by market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// Flag to return the markets mid price and top of the book buy and sell
    /// orders.
    #[prost(bool, tag="3")]
    pub with_mid_price_and_tob: bool,
}
/// QueryFullSpotMarketsResponse is the response type for the
/// Query/FullSpotMarkets RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFullSpotMarketsResponse {
    #[prost(message, repeated, tag="1")]
    pub markets: ::prost::alloc::vec::Vec<FullSpotMarket>,
}
/// QuerySpotMarketRequest is the request type for the Query/SpotMarket RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFullSpotMarketRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// Flag to return the markets mid price and top of the book buy and sell
    /// orders.
    #[prost(bool, tag="2")]
    pub with_mid_price_and_tob: bool,
}
/// QuerySpotMarketResponse is the response type for the Query/SpotMarket RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFullSpotMarketResponse {
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<FullSpotMarket>,
}
/// QuerySpotOrdersByHashesRequest is the request type for the
/// Query/SpotOrdersByHashes RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotOrdersByHashesRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// SubaccountID of the trader
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the order hashes
    #[prost(string, repeated, tag="3")]
    pub order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QuerySpotOrdersByHashesResponse is the response type for the
/// Query/SpotOrdersByHashes RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotOrdersByHashesResponse {
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<TrimmedSpotLimitOrder>,
}
/// QueryTraderSpotOrdersRequest is the request type for the
/// Query/TraderSpotOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTraderSpotOrdersRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// SubaccountID of the trader
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
}
/// QueryAccountAddressSpotOrdersRequest is the request type for the
/// Query/AccountAddressSpotOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAccountAddressSpotOrdersRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// Account address of the trader
    #[prost(string, tag="2")]
    pub account_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TrimmedSpotLimitOrder {
    /// price of the order (in human readable format)
    #[prost(string, tag="1")]
    pub price: ::prost::alloc::string::String,
    /// quantity of the order (in human readable format)
    #[prost(string, tag="2")]
    pub quantity: ::prost::alloc::string::String,
    /// the amount of the quantity remaining fillable (in human readable format)
    #[prost(string, tag="3")]
    pub fillable: ::prost::alloc::string::String,
    /// true if the order is a buy
    #[prost(bool, tag="4")]
    pub is_buy: bool,
    /// the order hash (optional)
    #[prost(string, tag="5")]
    pub order_hash: ::prost::alloc::string::String,
    /// the client order ID (optional)
    #[prost(string, tag="6")]
    pub cid: ::prost::alloc::string::String,
}
/// QueryTraderSpotOrdersResponse is the response type for the
/// Query/TraderSpotOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTraderSpotOrdersResponse {
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<TrimmedSpotLimitOrder>,
}
/// QueryAccountAddressSpotOrdersResponse is the response type for the
/// Query/AccountAddressSpotOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAccountAddressSpotOrdersResponse {
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<TrimmedSpotLimitOrder>,
}
/// QuerySpotMidPriceAndTOBRequest is the request type for the
/// Query/SpotMidPriceAndTOB RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotMidPriceAndTobRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QuerySpotMidPriceAndTOBResponse is the response type for the
/// Query/SpotMidPriceAndTOB RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySpotMidPriceAndTobResponse {
    /// mid price of the market (in human readable format)
    #[prost(string, tag="1")]
    pub mid_price: ::prost::alloc::string::String,
    /// best buy price of the market (in human readable format)
    #[prost(string, tag="2")]
    pub best_buy_price: ::prost::alloc::string::String,
    /// best sell price of the market
    #[prost(string, tag="3")]
    pub best_sell_price: ::prost::alloc::string::String,
}
/// QueryDerivativeMidPriceAndTOBRequest is the request type for the
/// Query/GetDerivativeMidPriceAndTOB RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeMidPriceAndTobRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QueryDerivativeMidPriceAndTOBResponse is the response type for the
/// Query/GetDerivativeMidPriceAndTOB RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeMidPriceAndTobResponse {
    /// mid price of the market
    #[prost(string, tag="1")]
    pub mid_price: ::prost::alloc::string::String,
    /// best buy price of the market
    #[prost(string, tag="2")]
    pub best_buy_price: ::prost::alloc::string::String,
    /// best sell price of the market
    #[prost(string, tag="3")]
    pub best_sell_price: ::prost::alloc::string::String,
}
/// QueryDerivativeOrderbookRequest is the request type for the
/// Query/DerivativeOrderbook RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeOrderbookRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    #[prost(uint64, tag="2")]
    pub limit: u64,
    #[prost(string, tag="3")]
    pub limit_cumulative_notional: ::prost::alloc::string::String,
}
/// QueryDerivativeOrderbookResponse is the response type for the
/// Query/DerivativeOrderbook RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeOrderbookResponse {
    #[prost(message, repeated, tag="1")]
    pub buys_price_level: ::prost::alloc::vec::Vec<Level>,
    #[prost(message, repeated, tag="2")]
    pub sells_price_level: ::prost::alloc::vec::Vec<Level>,
    /// the current orderbook sequence number
    #[prost(uint64, tag="3")]
    pub seq: u64,
}
/// QueryTraderSpotOrdersToCancelUpToAmountRequest is the request type for the
/// Query/TraderSpotOrdersToCancelUpToAmountRequest RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTraderSpotOrdersToCancelUpToAmountRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// SubaccountID of the trader
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the base amount to cancel (free up)
    #[prost(string, tag="3")]
    pub base_amount: ::prost::alloc::string::String,
    /// the quote amount to cancel (free up)
    #[prost(string, tag="4")]
    pub quote_amount: ::prost::alloc::string::String,
    /// The cancellation strategy
    #[prost(enumeration="CancellationStrategy", tag="5")]
    pub strategy: i32,
    /// The reference price for the cancellation strategy, e.g. mid price or mark
    /// price
    #[prost(string, tag="6")]
    pub reference_price: ::prost::alloc::string::String,
}
/// QueryTraderDerivativeOrdersToCancelUpToAmountRequest is the request type for
/// the Query/TraderDerivativeOrdersToCancelUpToAmountRequest RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTraderDerivativeOrdersToCancelUpToAmountRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// SubaccountID of the trader
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the quote amount to cancel (free up)
    #[prost(string, tag="3")]
    pub quote_amount: ::prost::alloc::string::String,
    /// The cancellation strategy
    #[prost(enumeration="CancellationStrategy", tag="4")]
    pub strategy: i32,
    /// The reference price for the cancellation strategy, e.g. mid price or mark
    /// price
    #[prost(string, tag="5")]
    pub reference_price: ::prost::alloc::string::String,
}
/// QueryTraderDerivativeOrdersRequest is the request type for the
/// Query/TraderDerivativeOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTraderDerivativeOrdersRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// SubaccountID of the trader
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
}
/// QueryAccountAddressSpotOrdersRequest is the request type for the
/// Query/AccountAddressDerivativeOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAccountAddressDerivativeOrdersRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// Account address of the trader
    #[prost(string, tag="2")]
    pub account_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TrimmedDerivativeLimitOrder {
    /// price of the order (in human readable format)
    #[prost(string, tag="1")]
    pub price: ::prost::alloc::string::String,
    /// quantity of the order (in human readable format)
    #[prost(string, tag="2")]
    pub quantity: ::prost::alloc::string::String,
    /// margin of the order (in human readable format)
    #[prost(string, tag="3")]
    pub margin: ::prost::alloc::string::String,
    /// the amount of the quantity remaining fillable (in human readable format)
    #[prost(string, tag="4")]
    pub fillable: ::prost::alloc::string::String,
    /// true if the order is a buy
    #[prost(bool, tag="5")]
    pub is_buy: bool,
    /// the order hash (optional)
    #[prost(string, tag="6")]
    pub order_hash: ::prost::alloc::string::String,
    /// the client order ID (optional)
    #[prost(string, tag="7")]
    pub cid: ::prost::alloc::string::String,
}
/// QueryTraderDerivativeOrdersResponse is the response type for the
/// Query/TraderDerivativeOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTraderDerivativeOrdersResponse {
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<TrimmedDerivativeLimitOrder>,
}
/// QueryAccountAddressDerivativeOrdersResponse is the response type for the
/// Query/AccountAddressDerivativeOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryAccountAddressDerivativeOrdersResponse {
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<TrimmedDerivativeLimitOrder>,
}
/// QueryTraderDerivativeOrdersRequest is the request type for the
/// Query/TraderDerivativeOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeOrdersByHashesRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// SubaccountID of the trader
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the order hashes
    #[prost(string, repeated, tag="3")]
    pub order_hashes: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QueryDerivativeOrdersByHashesResponse is the response type for the
/// Query/DerivativeOrdersByHashes RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeOrdersByHashesResponse {
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<TrimmedDerivativeLimitOrder>,
}
/// QueryDerivativeMarketsRequest is the request type for the
/// Query/DerivativeMarkets RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeMarketsRequest {
    /// Status of the market, for convenience it is set to string - not enum
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
    /// Filter by market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// Flag to return the markets mid price and top of the book buy and sell
    /// orders.
    #[prost(bool, tag="3")]
    pub with_mid_price_and_tob: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PriceLevel {
    #[prost(string, tag="1")]
    pub price: ::prost::alloc::string::String,
    /// quantity
    #[prost(string, tag="2")]
    pub quantity: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PerpetualMarketState {
    #[prost(message, optional, tag="1")]
    pub market_info: ::core::option::Option<PerpetualMarketInfo>,
    #[prost(message, optional, tag="2")]
    pub funding_info: ::core::option::Option<PerpetualMarketFunding>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FullDerivativeMarket {
    /// derivative market details
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<DerivativeMarket>,
    /// mark price (in human readable format)
    #[prost(string, tag="4")]
    pub mark_price: ::prost::alloc::string::String,
    /// mid_price_and_tob defines the mid price for this market and the best ask
    /// and bid orders
    #[prost(message, optional, tag="5")]
    pub mid_price_and_tob: ::core::option::Option<MidPriceAndTob>,
    /// perpetual market state or expiry futures market state
    #[prost(oneof="full_derivative_market::Info", tags="2, 3")]
    pub info: ::core::option::Option<full_derivative_market::Info>,
}
/// Nested message and enum types in `FullDerivativeMarket`.
pub mod full_derivative_market {
    /// perpetual market state or expiry futures market state
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Info {
        /// perpetual market info
        #[prost(message, tag="2")]
        PerpetualInfo(super::PerpetualMarketState),
        /// expiry futures market info
        #[prost(message, tag="3")]
        FuturesInfo(super::ExpiryFuturesMarketInfo),
    }
}
/// QueryDerivativeMarketsResponse is the response type for the
/// Query/DerivativeMarkets RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeMarketsResponse {
    #[prost(message, repeated, tag="1")]
    pub markets: ::prost::alloc::vec::Vec<FullDerivativeMarket>,
}
/// QueryDerivativeMarketRequest is the request type for the
/// Query/DerivativeMarket RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeMarketRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QueryDerivativeMarketResponse is the response type for the
/// Query/DerivativeMarket RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeMarketResponse {
    #[prost(message, optional, tag="1")]
    pub market: ::core::option::Option<FullDerivativeMarket>,
}
/// QueryDerivativeMarketAddressRequest is the request type for the
/// Query/DerivativeMarketAddress RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeMarketAddressRequest {
    /// Market ID for the market
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QueryDerivativeMarketAddressResponse is the response type for the
/// Query/DerivativeMarketAddress RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDerivativeMarketAddressResponse {
    /// address for the market
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    /// subaccountID for the market
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
}
/// QuerySubaccountTradeNonceRequest is the request type for the
/// Query/SubaccountTradeNonce RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountTradeNonceRequest {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
}
/// QueryPositionsInMarketRequest is the request type for the
/// Query/PositionsInMarket RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryPositionsInMarketRequest {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QueryPositionsInMarketResponse is the response type for the
/// Query/PositionsInMarket RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryPositionsInMarketResponse {
    #[prost(message, repeated, tag="1")]
    pub state: ::prost::alloc::vec::Vec<DerivativePosition>,
}
/// QuerySubaccountPositionsRequest is the request type for the
/// Query/SubaccountPositions RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountPositionsRequest {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
}
/// QuerySubaccountPositionInMarketRequest is the request type for the
/// Query/SubaccountPositionInMarket RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountPositionInMarketRequest {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
}
/// QuerySubaccountEffectivePositionInMarketRequest is the request type for the
/// Query/SubaccountEffectivePositionInMarket RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountEffectivePositionInMarketRequest {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
}
/// QuerySubaccountOrderMetadataRequest is the request type for the
/// Query/SubaccountOrderMetadata RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountOrderMetadataRequest {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
}
/// QuerySubaccountPositionsResponse is the response type for the
/// Query/SubaccountPositions RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountPositionsResponse {
    #[prost(message, repeated, tag="1")]
    pub state: ::prost::alloc::vec::Vec<DerivativePosition>,
}
/// QuerySubaccountPositionInMarketResponse is the response type for the
/// Query/SubaccountPositionInMarket RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountPositionInMarketResponse {
    #[prost(message, optional, tag="1")]
    pub state: ::core::option::Option<Position>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EffectivePosition {
    /// whether the position is long or short
    #[prost(bool, tag="1")]
    pub is_long: bool,
    /// the quantity of the position (in human readable format)
    #[prost(string, tag="2")]
    pub quantity: ::prost::alloc::string::String,
    /// the entry price of the position (in human readable format)
    #[prost(string, tag="3")]
    pub entry_price: ::prost::alloc::string::String,
    /// the effective margin of the position (in human readable format)
    #[prost(string, tag="4")]
    pub effective_margin: ::prost::alloc::string::String,
}
/// QuerySubaccountEffectivePositionInMarketResponse is the response type for the
/// Query/SubaccountEffectivePositionInMarket RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountEffectivePositionInMarketResponse {
    #[prost(message, optional, tag="1")]
    pub state: ::core::option::Option<EffectivePosition>,
}
/// QueryPerpetualMarketInfoRequest is the request type for the
/// Query/PerpetualMarketInfo RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryPerpetualMarketInfoRequest {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QueryPerpetualMarketInfoResponse is the response type for the
/// Query/PerpetualMarketInfo RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryPerpetualMarketInfoResponse {
    #[prost(message, optional, tag="1")]
    pub info: ::core::option::Option<PerpetualMarketInfo>,
}
/// QueryExpiryFuturesMarketInfoRequest is the request type for the Query/
/// ExpiryFuturesMarketInfo RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryExpiryFuturesMarketInfoRequest {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QueryExpiryFuturesMarketInfoResponse is the response type for the Query/
/// ExpiryFuturesMarketInfo RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryExpiryFuturesMarketInfoResponse {
    #[prost(message, optional, tag="1")]
    pub info: ::core::option::Option<ExpiryFuturesMarketInfo>,
}
/// QueryPerpetualMarketFundingRequest is the request type for the
/// Query/PerpetualMarketFunding RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryPerpetualMarketFundingRequest {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
/// QueryPerpetualMarketFundingResponse is the response type for the
/// Query/PerpetualMarketFunding RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryPerpetualMarketFundingResponse {
    #[prost(message, optional, tag="1")]
    pub state: ::core::option::Option<PerpetualMarketFunding>,
}
/// QuerySubaccountOrderMetadataResponse is the response type for the
/// Query/SubaccountOrderMetadata RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountOrderMetadataResponse {
    #[prost(message, repeated, tag="1")]
    pub metadata: ::prost::alloc::vec::Vec<SubaccountOrderbookMetadataWithMarket>,
}
/// QuerySubaccountTradeNonceResponse is the response type for the
/// Query/SubaccountTradeNonce RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuerySubaccountTradeNonceResponse {
    #[prost(uint32, tag="1")]
    pub nonce: u32,
}
/// QueryModuleStateRequest is the request type for the Query/ExchangeModuleState
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryModuleStateRequest {
}
/// QueryModuleStateResponse is the response type for the
/// Query/ExchangeModuleState RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryModuleStateResponse {
    #[prost(message, optional, tag="1")]
    pub state: ::core::option::Option<GenesisState>,
}
/// QueryPositionsRequest is the request type for the Query/Positions RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryPositionsRequest {
}
/// QueryPositionsResponse is the response type for the Query/Positions RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryPositionsResponse {
    #[prost(message, repeated, tag="1")]
    pub state: ::prost::alloc::vec::Vec<DerivativePosition>,
}
/// QueryTradeRewardPointsRequest is the request type for the
/// Query/TradeRewardPoints RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTradeRewardPointsRequest {
    #[prost(string, repeated, tag="1")]
    pub accounts: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(int64, tag="2")]
    pub pending_pool_timestamp: i64,
}
/// QueryTradeRewardPointsResponse is the response type for the
/// Query/TradeRewardPoints RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTradeRewardPointsResponse {
    #[prost(string, repeated, tag="1")]
    pub account_trade_reward_points: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QueryTradeRewardCampaignRequest is the request type for the
/// Query/TradeRewardCampaign RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTradeRewardCampaignRequest {
}
/// QueryTradeRewardCampaignResponse is the response type for the
/// Query/TradeRewardCampaign RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTradeRewardCampaignResponse {
    #[prost(message, optional, tag="1")]
    pub trading_reward_campaign_info: ::core::option::Option<TradingRewardCampaignInfo>,
    #[prost(message, repeated, tag="2")]
    pub trading_reward_pool_campaign_schedule: ::prost::alloc::vec::Vec<CampaignRewardPool>,
    #[prost(string, tag="3")]
    pub total_trade_reward_points: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="4")]
    pub pending_trading_reward_pool_campaign_schedule: ::prost::alloc::vec::Vec<CampaignRewardPool>,
    #[prost(string, repeated, tag="5")]
    pub pending_total_trade_reward_points: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QueryIsRegisteredDMMRequest is the request type for the Query/IsRegisteredDMM
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIsOptedOutOfRewardsRequest {
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
}
/// QueryIsRegisteredDMMResponse is the response type for the
/// Query/IsRegisteredDMM RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryIsOptedOutOfRewardsResponse {
    #[prost(bool, tag="1")]
    pub is_opted_out: bool,
}
/// QueryRegisteredDMMsRequest is the request type for the Query/RegisteredDMMs
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryOptedOutOfRewardsAccountsRequest {
}
/// QueryRegisteredDMMsResponse is the response type for the Query/RegisteredDMMs
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryOptedOutOfRewardsAccountsResponse {
    #[prost(string, repeated, tag="1")]
    pub accounts: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QueryFeeDiscountAccountInfoRequest is the request type for the
/// Query/FeeDiscountAccountInfo RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFeeDiscountAccountInfoRequest {
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
}
/// QueryFeeDiscountAccountInfoResponse is the response type for the
/// Query/FeeDiscountAccountInfo RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFeeDiscountAccountInfoResponse {
    #[prost(uint64, tag="1")]
    pub tier_level: u64,
    #[prost(message, optional, tag="2")]
    pub account_info: ::core::option::Option<FeeDiscountTierInfo>,
    #[prost(message, optional, tag="3")]
    pub account_ttl: ::core::option::Option<FeeDiscountTierTtl>,
}
/// QueryFeeDiscountScheduleRequest is the request type for the
/// Query/FeeDiscountSchedule RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFeeDiscountScheduleRequest {
}
/// QueryFeeDiscountScheduleResponse is the response type for the
/// Query/FeeDiscountSchedule RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFeeDiscountScheduleResponse {
    #[prost(message, optional, tag="1")]
    pub fee_discount_schedule: ::core::option::Option<FeeDiscountSchedule>,
}
/// QueryBalanceMismatchesRequest is the request type for the
/// Query/QueryBalanceMismatches RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryBalanceMismatchesRequest {
    #[prost(int64, tag="1")]
    pub dust_factor: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BalanceMismatch {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the denom of the balance
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
    /// the available balance
    #[prost(string, tag="3")]
    pub available: ::prost::alloc::string::String,
    /// the total balance
    #[prost(string, tag="4")]
    pub total: ::prost::alloc::string::String,
    /// the balance hold
    #[prost(string, tag="5")]
    pub balance_hold: ::prost::alloc::string::String,
    /// the expected total balance
    #[prost(string, tag="6")]
    pub expected_total: ::prost::alloc::string::String,
    /// the difference between the total balance and the expected total balance
    #[prost(string, tag="7")]
    pub difference: ::prost::alloc::string::String,
}
/// QueryBalanceMismatchesResponse is the response type for the
/// Query/QueryBalanceMismatches RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryBalanceMismatchesResponse {
    #[prost(message, repeated, tag="1")]
    pub balance_mismatches: ::prost::alloc::vec::Vec<BalanceMismatch>,
}
/// QueryBalanceWithBalanceHoldsRequest is the request type for the
/// Query/QueryBalanceWithBalanceHolds RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryBalanceWithBalanceHoldsRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BalanceWithMarginHold {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the denom of the balance
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
    /// the available balance
    #[prost(string, tag="3")]
    pub available: ::prost::alloc::string::String,
    /// the total balance
    #[prost(string, tag="4")]
    pub total: ::prost::alloc::string::String,
    /// the balance on hold
    #[prost(string, tag="5")]
    pub balance_hold: ::prost::alloc::string::String,
}
/// QueryBalanceWithBalanceHoldsResponse is the response type for the
/// Query/QueryBalanceWithBalanceHolds RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryBalanceWithBalanceHoldsResponse {
    #[prost(message, repeated, tag="1")]
    pub balance_with_balance_holds: ::prost::alloc::vec::Vec<BalanceWithMarginHold>,
}
/// QueryFeeDiscountTierStatisticsRequest is the request type for the
/// Query/QueryFeeDiscountTierStatistics RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFeeDiscountTierStatisticsRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TierStatistic {
    #[prost(uint64, tag="1")]
    pub tier: u64,
    #[prost(uint64, tag="2")]
    pub count: u64,
}
/// QueryFeeDiscountTierStatisticsResponse is the response type for the
/// Query/QueryFeeDiscountTierStatistics RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFeeDiscountTierStatisticsResponse {
    #[prost(message, repeated, tag="1")]
    pub statistics: ::prost::alloc::vec::Vec<TierStatistic>,
}
/// MitoVaultInfosRequest is the request type for the Query/MitoVaultInfos RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MitoVaultInfosRequest {
}
/// MitoVaultInfosResponse is the response type for the Query/MitoVaultInfos RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MitoVaultInfosResponse {
    /// list of master addresses
    #[prost(string, repeated, tag="1")]
    pub master_addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// list of derivative addresses
    #[prost(string, repeated, tag="2")]
    pub derivative_addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// list of spot addresses
    #[prost(string, repeated, tag="3")]
    pub spot_addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// list of cw20 addresses
    #[prost(string, repeated, tag="4")]
    pub cw20_addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// QueryMarketIDFromVaultRequest is the request type for the
/// Query/QueryMarketIDFromVault RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketIdFromVaultRequest {
    #[prost(string, tag="1")]
    pub vault_address: ::prost::alloc::string::String,
}
/// QueryMarketIDFromVaultResponse is the response type for the
/// Query/QueryMarketIDFromVault RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketIdFromVaultResponse {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryHistoricalTradeRecordsRequest {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryHistoricalTradeRecordsResponse {
    #[prost(message, repeated, tag="1")]
    pub trade_records: ::prost::alloc::vec::Vec<TradeRecords>,
}
/// TradeHistoryOptions are the optional params for Query/MarketVolatility RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradeHistoryOptions {
    /// TradeGroupingSec of 0 means use the chain's default grouping
    #[prost(uint64, tag="1")]
    pub trade_grouping_sec: u64,
    /// MaxAge restricts the trade records oldest age in seconds from the current
    /// block time to consider. A value of 0 means use all the records present on
    /// the chain.
    #[prost(uint64, tag="2")]
    pub max_age: u64,
    /// If IncludeRawHistory is true, the raw underlying data used for the
    /// computation is included in the response
    #[prost(bool, tag="4")]
    pub include_raw_history: bool,
    /// If IncludeMetadata is true, metadata on the computation is included in the
    /// response
    #[prost(bool, tag="5")]
    pub include_metadata: bool,
}
/// QueryMarketVolatilityRequest are the request params for the
/// Query/MarketVolatility RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketVolatilityRequest {
    /// the market ID to query volatility for
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// the trade history options
    #[prost(message, optional, tag="2")]
    pub trade_history_options: ::core::option::Option<TradeHistoryOptions>,
}
/// QueryMarketVolatilityResponse is the response type for the
/// Query/MarketVolatility RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketVolatilityResponse {
    #[prost(string, tag="1")]
    pub volatility: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub history_metadata: ::core::option::Option<super::super::oracle::v1beta1::MetadataStatistics>,
    #[prost(message, repeated, tag="3")]
    pub raw_history: ::prost::alloc::vec::Vec<TradeRecord>,
}
/// QuerBinaryMarketsRequest is the request type for the Query/BinaryMarkets RPC
/// method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryBinaryMarketsRequest {
    /// Status of the market, for convenience it is set to string - not enum
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
}
/// QueryBinaryMarketsResponse is the response type for the Query/BinaryMarkets
/// RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryBinaryMarketsResponse {
    #[prost(message, repeated, tag="1")]
    pub markets: ::prost::alloc::vec::Vec<BinaryOptionsMarket>,
}
/// QueryConditionalOrdersRequest is the request type for the
/// Query/ConditionalOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTraderDerivativeConditionalOrdersRequest {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TrimmedDerivativeConditionalOrder {
    /// price of the order (in human readable format)
    #[prost(string, tag="1")]
    pub price: ::prost::alloc::string::String,
    /// quantity of the order (in human readable format)
    #[prost(string, tag="2")]
    pub quantity: ::prost::alloc::string::String,
    /// margin of the order (in human readable format)
    #[prost(string, tag="3")]
    pub margin: ::prost::alloc::string::String,
    /// price to trigger the order (in human readable format)
    #[prost(string, tag="4")]
    pub trigger_price: ::prost::alloc::string::String,
    /// true if the order is a buy
    #[prost(bool, tag="5")]
    pub is_buy: bool,
    /// true if the order is a limit order
    #[prost(bool, tag="6")]
    pub is_limit: bool,
    /// the order hash
    #[prost(string, tag="7")]
    pub order_hash: ::prost::alloc::string::String,
    /// the client ID
    #[prost(string, tag="8")]
    pub cid: ::prost::alloc::string::String,
}
/// QueryTraderDerivativeOrdersResponse is the response type for the
/// Query/TraderDerivativeOrders RPC method.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTraderDerivativeConditionalOrdersResponse {
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<TrimmedDerivativeConditionalOrder>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFullSpotOrderbookRequest {
    /// market id
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFullSpotOrderbookResponse {
    #[prost(message, repeated, tag="1")]
    pub bids: ::prost::alloc::vec::Vec<TrimmedLimitOrder>,
    #[prost(message, repeated, tag="2")]
    pub asks: ::prost::alloc::vec::Vec<TrimmedLimitOrder>,
    /// the current orderbook sequence number
    #[prost(uint64, tag="3")]
    pub seq: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFullDerivativeOrderbookRequest {
    /// market id
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryFullDerivativeOrderbookResponse {
    #[prost(message, repeated, tag="1")]
    pub bids: ::prost::alloc::vec::Vec<TrimmedLimitOrder>,
    #[prost(message, repeated, tag="2")]
    pub asks: ::prost::alloc::vec::Vec<TrimmedLimitOrder>,
    /// the current orderbook sequence number
    #[prost(uint64, tag="3")]
    pub seq: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TrimmedLimitOrder {
    /// price of the order (in human readable format)
    #[prost(string, tag="1")]
    pub price: ::prost::alloc::string::String,
    /// quantity of the order (in human readable format)
    #[prost(string, tag="2")]
    pub quantity: ::prost::alloc::string::String,
    /// the order hash
    #[prost(string, tag="3")]
    pub order_hash: ::prost::alloc::string::String,
    /// the subaccount ID
    #[prost(string, tag="4")]
    pub subaccount_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketAtomicExecutionFeeMultiplierRequest {
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketAtomicExecutionFeeMultiplierResponse {
    #[prost(string, tag="1")]
    pub multiplier: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryActiveStakeGrantRequest {
    #[prost(string, tag="1")]
    pub grantee: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryActiveStakeGrantResponse {
    #[prost(message, optional, tag="1")]
    pub grant: ::core::option::Option<ActiveGrant>,
    #[prost(message, optional, tag="2")]
    pub effective_grant: ::core::option::Option<EffectiveGrant>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryGrantAuthorizationRequest {
    #[prost(string, tag="1")]
    pub granter: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub grantee: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryGrantAuthorizationResponse {
    #[prost(string, tag="1")]
    pub amount: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryGrantAuthorizationsRequest {
    #[prost(string, tag="1")]
    pub granter: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryGrantAuthorizationsResponse {
    #[prost(string, tag="1")]
    pub total_grant_amount: ::prost::alloc::string::String,
    #[prost(message, repeated, tag="2")]
    pub grants: ::prost::alloc::vec::Vec<GrantAuthorization>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketBalanceRequest {
    /// market id
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketBalanceResponse {
    #[prost(message, optional, tag="1")]
    pub balance: ::core::option::Option<MarketBalance>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketBalancesRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryMarketBalancesResponse {
    #[prost(message, repeated, tag="1")]
    pub balances: ::prost::alloc::vec::Vec<MarketBalance>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MarketBalance {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// the current balance of the market
    #[prost(string, tag="2")]
    pub balance: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDenomMinNotionalRequest {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDenomMinNotionalResponse {
    /// the minimum notional amount for the denom (in human readable format)
    #[prost(string, tag="1")]
    pub amount: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDenomMinNotionalsRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryDenomMinNotionalsResponse {
    #[prost(message, repeated, tag="1")]
    pub denom_min_notionals: ::prost::alloc::vec::Vec<DenomMinNotional>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OpenInterest {
    /// the market ID
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
    /// the open interest of the market
    #[prost(string, tag="2")]
    pub balance: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryOpenInterestRequest {
    /// market id
    #[prost(string, tag="1")]
    pub market_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryOpenInterestResponse {
    #[prost(message, optional, tag="1")]
    pub amount: ::core::option::Option<OpenInterest>,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum OrderSide {
    /// will return both
    SideUnspecified = 0,
    Buy = 1,
    Sell = 2,
}
impl OrderSide {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            OrderSide::SideUnspecified => "Side_Unspecified",
            OrderSide::Buy => "Buy",
            OrderSide::Sell => "Sell",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Side_Unspecified" => Some(Self::SideUnspecified),
            "Buy" => Some(Self::Buy),
            "Sell" => Some(Self::Sell),
            _ => None,
        }
    }
}
/// CancellationStrategy is the list of cancellation strategies.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum CancellationStrategy {
    /// just cancelling in random order in most efficient way
    UnspecifiedOrder = 0,
    /// e.g. for buy orders from lowest to highest price
    FromWorstToBest = 1,
    /// e.g. for buy orders from higest to lowest price
    FromBestToWorst = 2,
}
impl CancellationStrategy {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            CancellationStrategy::UnspecifiedOrder => "UnspecifiedOrder",
            CancellationStrategy::FromWorstToBest => "FromWorstToBest",
            CancellationStrategy::FromBestToWorst => "FromBestToWorst",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "UnspecifiedOrder" => Some(Self::UnspecifiedOrder),
            "FromWorstToBest" => Some(Self::FromWorstToBest),
            "FromBestToWorst" => Some(Self::FromBestToWorst),
            _ => None,
        }
    }
}
/// spot authz messages
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CreateSpotLimitOrderAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CreateSpotMarketOrderAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BatchCreateSpotLimitOrdersAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CancelSpotOrderAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BatchCancelSpotOrdersAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// derivative authz messages
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CreateDerivativeLimitOrderAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CreateDerivativeMarketOrderAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BatchCreateDerivativeLimitOrdersAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CancelDerivativeOrderAuthz {
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BatchCancelDerivativeOrdersAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// common authz message used in both spot & derivative markets
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BatchUpdateOrdersAuthz {
    /// the subaccount ID
    #[prost(string, tag="1")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// the spot market IDs
    #[prost(string, repeated, tag="2")]
    pub spot_markets: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// the derivative market IDs
    #[prost(string, repeated, tag="3")]
    pub derivative_markets: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// GenericExchangeAuthorization gives the grantee permissions to execute
/// the provided Exchange method on behalf of the granter's account.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenericExchangeAuthorization {
    /// Msg, identified by it's type URL, to grant permissions to the grantee
    #[prost(string, tag="1")]
    pub msg: ::prost::alloc::string::String,
    /// SpendLimit is the maximum amount of tokens that the grantee can spend on
    /// behalf of the granter. If not set, there is no spend limit.
    #[prost(message, repeated, tag="2")]
    pub spend_limit: ::prost::alloc::vec::Vec<super::super::super::cosmos::base::v1beta1::Coin>,
}
include!("injective.exchange.v2.tonic.rs");
// @@protoc_insertion_point(module)

// @generated
/// AddressVoucher pairs a bech32 address with its outstanding voucher coin.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AddressVoucher {
    /// The bech32 address of the voucher holder.
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    /// The outstanding voucher coin.
    #[prost(message, optional, tag="2")]
    pub voucher: ::core::option::Option<super::super::super::super::cosmos::base::v1beta1::Coin>,
}
// @@protoc_insertion_point(module)

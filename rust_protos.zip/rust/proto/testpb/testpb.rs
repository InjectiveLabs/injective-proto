// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ExampleTable {
    /// Valid key fields:
    #[prost(uint32, tag="1")]
    pub u32: u32,
    #[prost(uint64, tag="2")]
    pub u64: u64,
    #[prost(string, tag="3")]
    pub str: ::prost::alloc::string::String,
    #[prost(bytes="vec", tag="4")]
    pub bz: ::prost::alloc::vec::Vec<u8>,
    #[prost(message, optional, tag="5")]
    pub ts: ::core::option::Option<::prost_types::Timestamp>,
    #[prost(message, optional, tag="6")]
    pub dur: ::core::option::Option<::prost_types::Duration>,
    #[prost(int32, tag="7")]
    pub i32: i32,
    #[prost(sint32, tag="8")]
    pub s32: i32,
    #[prost(sfixed32, tag="9")]
    pub sf32: i32,
    #[prost(int64, tag="10")]
    pub i64: i64,
    #[prost(sint64, tag="11")]
    pub s64: i64,
    #[prost(sfixed64, tag="12")]
    pub sf64: i64,
    #[prost(fixed32, tag="13")]
    pub f32: u32,
    #[prost(fixed64, tag="14")]
    pub f64: u64,
    #[prost(bool, tag="15")]
    pub b: bool,
    #[prost(enumeration="Enum", tag="16")]
    pub e: i32,
    /// Invalid key fields:
    #[prost(uint32, repeated, tag="17")]
    pub repeated: ::prost::alloc::vec::Vec<u32>,
    #[prost(map="string, uint32", tag="18")]
    pub map: ::std::collections::HashMap<::prost::alloc::string::String, u32>,
    #[prost(message, optional, tag="19")]
    pub msg: ::core::option::Option<example_table::ExampleMessage>,
    #[prost(oneof="example_table::Sum", tags="20")]
    pub sum: ::core::option::Option<example_table::Sum>,
}
/// Nested message and enum types in `ExampleTable`.
pub mod example_table {
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct ExampleMessage {
        #[prost(string, tag="1")]
        pub foo: ::prost::alloc::string::String,
        #[prost(int32, tag="2")]
        pub bar: i32,
    }
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Sum {
        #[prost(uint32, tag="20")]
        Oneof(u32),
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ExampleAutoIncrementTable {
    #[prost(uint64, tag="1")]
    pub id: u64,
    #[prost(string, tag="2")]
    pub x: ::prost::alloc::string::String,
    #[prost(int32, tag="3")]
    pub y: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ExampleSingleton {
    #[prost(string, tag="1")]
    pub foo: ::prost::alloc::string::String,
    #[prost(int32, tag="2")]
    pub bar: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ExampleTimestamp {
    #[prost(uint64, tag="1")]
    pub id: u64,
    #[prost(string, tag="2")]
    pub name: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub ts: ::core::option::Option<::prost_types::Timestamp>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SimpleExample {
    #[prost(string, tag="1")]
    pub name: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub unique: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub not_unique: ::prost::alloc::string::String,
}
/// ExampleAutoIncFieldName is a table for testing InsertReturning<FieldName>.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ExampleAutoIncFieldName {
    #[prost(uint64, tag="1")]
    pub foo: u64,
    #[prost(uint64, tag="2")]
    pub bar: u64,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum Enum {
    Unspecified = 0,
    One = 1,
    Two = 2,
    Five = 5,
    NegThree = -3,
}
impl Enum {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            Enum::Unspecified => "ENUM_UNSPECIFIED",
            Enum::One => "ENUM_ONE",
            Enum::Two => "ENUM_TWO",
            Enum::Five => "ENUM_FIVE",
            Enum::NegThree => "ENUM_NEG_THREE",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "ENUM_UNSPECIFIED" => Some(Self::Unspecified),
            "ENUM_ONE" => Some(Self::One),
            "ENUM_TWO" => Some(Self::Two),
            "ENUM_FIVE" => Some(Self::Five),
            "ENUM_NEG_THREE" => Some(Self::NegThree),
            _ => None,
        }
    }
}
/// GetExampleTableRequest is the TestSchemaQuery/GetExampleTableRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleTableRequest {
    /// u32 specifies the value of the u32 field in the primary key.
    #[prost(uint32, tag="1")]
    pub u32: u32,
    /// i64 specifies the value of the i64 field in the primary key.
    #[prost(int64, tag="2")]
    pub i64: i64,
    /// str specifies the value of the str field in the primary key.
    #[prost(string, tag="3")]
    pub str: ::prost::alloc::string::String,
}
/// GetExampleTableResponse is the TestSchemaQuery/GetExampleTableResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleTableResponse {
    /// value is the response value.
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<ExampleTable>,
}
/// GetExampleTableByU64StrRequest is the TestSchemaQuery/GetExampleTableByU64StrRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleTableByU64StrRequest {
    #[prost(uint64, tag="1")]
    pub u64: u64,
    #[prost(string, tag="2")]
    pub str: ::prost::alloc::string::String,
}
/// GetExampleTableByU64StrResponse is the TestSchemaQuery/GetExampleTableByU64StrResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleTableByU64StrResponse {
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<ExampleTable>,
}
/// ListExampleTableRequest is the TestSchemaQuery/ListExampleTableRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListExampleTableRequest {
    /// pagination specifies optional pagination parameters.
    #[prost(message, optional, tag="3")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageRequest>,
    /// query specifies the type of query - either a prefix or range query.
    #[prost(oneof="list_example_table_request::Query", tags="1, 2")]
    pub query: ::core::option::Option<list_example_table_request::Query>,
}
/// Nested message and enum types in `ListExampleTableRequest`.
pub mod list_example_table_request {
    /// IndexKey specifies the value of an index key to use in prefix and range queries.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct IndexKey {
        /// key specifies the index key value.
        #[prost(oneof="index_key::Key", tags="1, 2, 3, 4")]
        pub key: ::core::option::Option<index_key::Key>,
    }
    /// Nested message and enum types in `IndexKey`.
    pub mod index_key {
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct U32i64Str {
            /// u32 is the value of the u32 field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(uint32, optional, tag="1")]
            pub u32: ::core::option::Option<u32>,
            /// i64 is the value of the i64 field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(int64, optional, tag="2")]
            pub i64: ::core::option::Option<i64>,
            /// str is the value of the str field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="3")]
            pub str: ::core::option::Option<::prost::alloc::string::String>,
        }
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct U64Str {
            /// u64 is the value of the u64 field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(uint64, optional, tag="1")]
            pub u64: ::core::option::Option<u64>,
            /// str is the value of the str field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="2")]
            pub str: ::core::option::Option<::prost::alloc::string::String>,
        }
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct StrU32 {
            /// str is the value of the str field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="1")]
            pub str: ::core::option::Option<::prost::alloc::string::String>,
            /// u32 is the value of the u32 field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(uint32, optional, tag="2")]
            pub u32: ::core::option::Option<u32>,
        }
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct BzStr {
            /// bz is the value of the bz field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(bytes="vec", optional, tag="1")]
            pub bz: ::core::option::Option<::prost::alloc::vec::Vec<u8>>,
            /// str is the value of the str field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="2")]
            pub str: ::core::option::Option<::prost::alloc::string::String>,
        }
        /// key specifies the index key value.
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
        pub enum Key {
            /// u_32_i_64_str specifies the value of the U32I64Str index key to use in the query.
            #[prost(message, tag="1")]
            U32I64Str(U32i64Str),
            /// u_64_str specifies the value of the U64Str index key to use in the query.
            #[prost(message, tag="2")]
            U64Str(U64Str),
            /// str_u_32 specifies the value of the StrU32 index key to use in the query.
            #[prost(message, tag="3")]
            StrU32(StrU32),
            /// bz_str specifies the value of the BzStr index key to use in the query.
            #[prost(message, tag="4")]
            BzStr(BzStr),
        }
    }
    /// RangeQuery specifies the from/to index keys for a range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct RangeQuery {
        /// from is the index key to use for the start of the range query.
        /// To query from the start of an index, specify an index key for that index with empty values.
        #[prost(message, optional, tag="1")]
        pub from: ::core::option::Option<IndexKey>,
        /// to is the index key to use for the end of the range query.
        /// The index key type MUST be the same as the index key type used for from.
        /// To query from to the end of an index it can be omitted.
        #[prost(message, optional, tag="2")]
        pub to: ::core::option::Option<IndexKey>,
    }
    /// query specifies the type of query - either a prefix or range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Query {
        /// prefix_query specifies the index key value to use for the prefix query.
        #[prost(message, tag="1")]
        PrefixQuery(IndexKey),
        /// range_query specifies the index key from/to values to use for the range query.
        #[prost(message, tag="2")]
        RangeQuery(RangeQuery),
    }
}
/// ListExampleTableResponse is the TestSchemaQuery/ListExampleTableResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListExampleTableResponse {
    /// values are the results of the query.
    #[prost(message, repeated, tag="1")]
    pub values: ::prost::alloc::vec::Vec<ExampleTable>,
    /// pagination is the pagination response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageResponse>,
}
/// GetExampleAutoIncrementTableRequest is the TestSchemaQuery/GetExampleAutoIncrementTableRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleAutoIncrementTableRequest {
    /// id specifies the value of the id field in the primary key.
    #[prost(uint64, tag="1")]
    pub id: u64,
}
/// GetExampleAutoIncrementTableResponse is the TestSchemaQuery/GetExampleAutoIncrementTableResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleAutoIncrementTableResponse {
    /// value is the response value.
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<ExampleAutoIncrementTable>,
}
/// GetExampleAutoIncrementTableByXRequest is the TestSchemaQuery/GetExampleAutoIncrementTableByXRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleAutoIncrementTableByXRequest {
    #[prost(string, tag="1")]
    pub x: ::prost::alloc::string::String,
}
/// GetExampleAutoIncrementTableByXResponse is the TestSchemaQuery/GetExampleAutoIncrementTableByXResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleAutoIncrementTableByXResponse {
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<ExampleAutoIncrementTable>,
}
/// ListExampleAutoIncrementTableRequest is the TestSchemaQuery/ListExampleAutoIncrementTableRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListExampleAutoIncrementTableRequest {
    /// pagination specifies optional pagination parameters.
    #[prost(message, optional, tag="3")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageRequest>,
    /// query specifies the type of query - either a prefix or range query.
    #[prost(oneof="list_example_auto_increment_table_request::Query", tags="1, 2")]
    pub query: ::core::option::Option<list_example_auto_increment_table_request::Query>,
}
/// Nested message and enum types in `ListExampleAutoIncrementTableRequest`.
pub mod list_example_auto_increment_table_request {
    /// IndexKey specifies the value of an index key to use in prefix and range queries.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct IndexKey {
        /// key specifies the index key value.
        #[prost(oneof="index_key::Key", tags="1, 2")]
        pub key: ::core::option::Option<index_key::Key>,
    }
    /// Nested message and enum types in `IndexKey`.
    pub mod index_key {
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct Id {
            /// id is the value of the id field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(uint64, optional, tag="1")]
            pub id: ::core::option::Option<u64>,
        }
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct X {
            /// x is the value of the x field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="1")]
            pub x: ::core::option::Option<::prost::alloc::string::String>,
        }
        /// key specifies the index key value.
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
        pub enum Key {
            /// id specifies the value of the Id index key to use in the query.
            #[prost(message, tag="1")]
            Id(Id),
            /// x specifies the value of the X index key to use in the query.
            #[prost(message, tag="2")]
            X(X),
        }
    }
    /// RangeQuery specifies the from/to index keys for a range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct RangeQuery {
        /// from is the index key to use for the start of the range query.
        /// To query from the start of an index, specify an index key for that index with empty values.
        #[prost(message, optional, tag="1")]
        pub from: ::core::option::Option<IndexKey>,
        /// to is the index key to use for the end of the range query.
        /// The index key type MUST be the same as the index key type used for from.
        /// To query from to the end of an index it can be omitted.
        #[prost(message, optional, tag="2")]
        pub to: ::core::option::Option<IndexKey>,
    }
    /// query specifies the type of query - either a prefix or range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Query {
        /// prefix_query specifies the index key value to use for the prefix query.
        #[prost(message, tag="1")]
        PrefixQuery(IndexKey),
        /// range_query specifies the index key from/to values to use for the range query.
        #[prost(message, tag="2")]
        RangeQuery(RangeQuery),
    }
}
/// ListExampleAutoIncrementTableResponse is the TestSchemaQuery/ListExampleAutoIncrementTableResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListExampleAutoIncrementTableResponse {
    /// values are the results of the query.
    #[prost(message, repeated, tag="1")]
    pub values: ::prost::alloc::vec::Vec<ExampleAutoIncrementTable>,
    /// pagination is the pagination response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageResponse>,
}
/// GetExampleSingletonRequest is the TestSchemaQuery/GetExampleSingletonRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleSingletonRequest {
}
/// GetExampleSingletonResponse is the TestSchemaQuery/GetExampleSingletonResponse request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleSingletonResponse {
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<ExampleSingleton>,
}
/// GetExampleTimestampRequest is the TestSchemaQuery/GetExampleTimestampRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleTimestampRequest {
    /// id specifies the value of the id field in the primary key.
    #[prost(uint64, tag="1")]
    pub id: u64,
}
/// GetExampleTimestampResponse is the TestSchemaQuery/GetExampleTimestampResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleTimestampResponse {
    /// value is the response value.
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<ExampleTimestamp>,
}
/// ListExampleTimestampRequest is the TestSchemaQuery/ListExampleTimestampRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListExampleTimestampRequest {
    /// pagination specifies optional pagination parameters.
    #[prost(message, optional, tag="3")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageRequest>,
    /// query specifies the type of query - either a prefix or range query.
    #[prost(oneof="list_example_timestamp_request::Query", tags="1, 2")]
    pub query: ::core::option::Option<list_example_timestamp_request::Query>,
}
/// Nested message and enum types in `ListExampleTimestampRequest`.
pub mod list_example_timestamp_request {
    /// IndexKey specifies the value of an index key to use in prefix and range queries.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct IndexKey {
        /// key specifies the index key value.
        #[prost(oneof="index_key::Key", tags="1, 2")]
        pub key: ::core::option::Option<index_key::Key>,
    }
    /// Nested message and enum types in `IndexKey`.
    pub mod index_key {
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct Id {
            /// id is the value of the id field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(uint64, optional, tag="1")]
            pub id: ::core::option::Option<u64>,
        }
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct Ts {
            /// ts is the value of the ts field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(message, optional, tag="1")]
            pub ts: ::core::option::Option<::prost_types::Timestamp>,
        }
        /// key specifies the index key value.
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
        pub enum Key {
            /// id specifies the value of the Id index key to use in the query.
            #[prost(message, tag="1")]
            Id(Id),
            /// ts specifies the value of the Ts index key to use in the query.
            #[prost(message, tag="2")]
            Ts(Ts),
        }
    }
    /// RangeQuery specifies the from/to index keys for a range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct RangeQuery {
        /// from is the index key to use for the start of the range query.
        /// To query from the start of an index, specify an index key for that index with empty values.
        #[prost(message, optional, tag="1")]
        pub from: ::core::option::Option<IndexKey>,
        /// to is the index key to use for the end of the range query.
        /// The index key type MUST be the same as the index key type used for from.
        /// To query from to the end of an index it can be omitted.
        #[prost(message, optional, tag="2")]
        pub to: ::core::option::Option<IndexKey>,
    }
    /// query specifies the type of query - either a prefix or range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Query {
        /// prefix_query specifies the index key value to use for the prefix query.
        #[prost(message, tag="1")]
        PrefixQuery(IndexKey),
        /// range_query specifies the index key from/to values to use for the range query.
        #[prost(message, tag="2")]
        RangeQuery(RangeQuery),
    }
}
/// ListExampleTimestampResponse is the TestSchemaQuery/ListExampleTimestampResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListExampleTimestampResponse {
    /// values are the results of the query.
    #[prost(message, repeated, tag="1")]
    pub values: ::prost::alloc::vec::Vec<ExampleTimestamp>,
    /// pagination is the pagination response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageResponse>,
}
/// GetSimpleExampleRequest is the TestSchemaQuery/GetSimpleExampleRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetSimpleExampleRequest {
    /// name specifies the value of the name field in the primary key.
    #[prost(string, tag="1")]
    pub name: ::prost::alloc::string::String,
}
/// GetSimpleExampleResponse is the TestSchemaQuery/GetSimpleExampleResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetSimpleExampleResponse {
    /// value is the response value.
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<SimpleExample>,
}
/// GetSimpleExampleByUniqueRequest is the TestSchemaQuery/GetSimpleExampleByUniqueRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetSimpleExampleByUniqueRequest {
    #[prost(string, tag="1")]
    pub unique: ::prost::alloc::string::String,
}
/// GetSimpleExampleByUniqueResponse is the TestSchemaQuery/GetSimpleExampleByUniqueResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetSimpleExampleByUniqueResponse {
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<SimpleExample>,
}
/// ListSimpleExampleRequest is the TestSchemaQuery/ListSimpleExampleRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSimpleExampleRequest {
    /// pagination specifies optional pagination parameters.
    #[prost(message, optional, tag="3")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageRequest>,
    /// query specifies the type of query - either a prefix or range query.
    #[prost(oneof="list_simple_example_request::Query", tags="1, 2")]
    pub query: ::core::option::Option<list_simple_example_request::Query>,
}
/// Nested message and enum types in `ListSimpleExampleRequest`.
pub mod list_simple_example_request {
    /// IndexKey specifies the value of an index key to use in prefix and range queries.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct IndexKey {
        /// key specifies the index key value.
        #[prost(oneof="index_key::Key", tags="1, 2")]
        pub key: ::core::option::Option<index_key::Key>,
    }
    /// Nested message and enum types in `IndexKey`.
    pub mod index_key {
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct Name {
            /// name is the value of the name field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="1")]
            pub name: ::core::option::Option<::prost::alloc::string::String>,
        }
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct Unique {
            /// unique is the value of the unique field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="1")]
            pub unique: ::core::option::Option<::prost::alloc::string::String>,
        }
        /// key specifies the index key value.
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
        pub enum Key {
            /// name specifies the value of the Name index key to use in the query.
            #[prost(message, tag="1")]
            Name(Name),
            /// unique specifies the value of the Unique index key to use in the query.
            #[prost(message, tag="2")]
            Unique(Unique),
        }
    }
    /// RangeQuery specifies the from/to index keys for a range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct RangeQuery {
        /// from is the index key to use for the start of the range query.
        /// To query from the start of an index, specify an index key for that index with empty values.
        #[prost(message, optional, tag="1")]
        pub from: ::core::option::Option<IndexKey>,
        /// to is the index key to use for the end of the range query.
        /// The index key type MUST be the same as the index key type used for from.
        /// To query from to the end of an index it can be omitted.
        #[prost(message, optional, tag="2")]
        pub to: ::core::option::Option<IndexKey>,
    }
    /// query specifies the type of query - either a prefix or range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Query {
        /// prefix_query specifies the index key value to use for the prefix query.
        #[prost(message, tag="1")]
        PrefixQuery(IndexKey),
        /// range_query specifies the index key from/to values to use for the range query.
        #[prost(message, tag="2")]
        RangeQuery(RangeQuery),
    }
}
/// ListSimpleExampleResponse is the TestSchemaQuery/ListSimpleExampleResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSimpleExampleResponse {
    /// values are the results of the query.
    #[prost(message, repeated, tag="1")]
    pub values: ::prost::alloc::vec::Vec<SimpleExample>,
    /// pagination is the pagination response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageResponse>,
}
/// GetExampleAutoIncFieldNameRequest is the TestSchemaQuery/GetExampleAutoIncFieldNameRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleAutoIncFieldNameRequest {
    /// foo specifies the value of the foo field in the primary key.
    #[prost(uint64, tag="1")]
    pub foo: u64,
}
/// GetExampleAutoIncFieldNameResponse is the TestSchemaQuery/GetExampleAutoIncFieldNameResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetExampleAutoIncFieldNameResponse {
    /// value is the response value.
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<ExampleAutoIncFieldName>,
}
/// ListExampleAutoIncFieldNameRequest is the TestSchemaQuery/ListExampleAutoIncFieldNameRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListExampleAutoIncFieldNameRequest {
    /// pagination specifies optional pagination parameters.
    #[prost(message, optional, tag="3")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageRequest>,
    /// query specifies the type of query - either a prefix or range query.
    #[prost(oneof="list_example_auto_inc_field_name_request::Query", tags="1, 2")]
    pub query: ::core::option::Option<list_example_auto_inc_field_name_request::Query>,
}
/// Nested message and enum types in `ListExampleAutoIncFieldNameRequest`.
pub mod list_example_auto_inc_field_name_request {
    /// IndexKey specifies the value of an index key to use in prefix and range queries.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct IndexKey {
        /// key specifies the index key value.
        #[prost(oneof="index_key::Key", tags="1")]
        pub key: ::core::option::Option<index_key::Key>,
    }
    /// Nested message and enum types in `IndexKey`.
    pub mod index_key {
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct Foo {
            /// foo is the value of the foo field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(uint64, optional, tag="1")]
            pub foo: ::core::option::Option<u64>,
        }
        /// key specifies the index key value.
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
        pub enum Key {
            /// foo specifies the value of the Foo index key to use in the query.
            #[prost(message, tag="1")]
            Foo(Foo),
        }
    }
    /// RangeQuery specifies the from/to index keys for a range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct RangeQuery {
        /// from is the index key to use for the start of the range query.
        /// To query from the start of an index, specify an index key for that index with empty values.
        #[prost(message, optional, tag="1")]
        pub from: ::core::option::Option<IndexKey>,
        /// to is the index key to use for the end of the range query.
        /// The index key type MUST be the same as the index key type used for from.
        /// To query from to the end of an index it can be omitted.
        #[prost(message, optional, tag="2")]
        pub to: ::core::option::Option<IndexKey>,
    }
    /// query specifies the type of query - either a prefix or range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Query {
        /// prefix_query specifies the index key value to use for the prefix query.
        #[prost(message, tag="1")]
        PrefixQuery(IndexKey),
        /// range_query specifies the index key from/to values to use for the range query.
        #[prost(message, tag="2")]
        RangeQuery(RangeQuery),
    }
}
/// ListExampleAutoIncFieldNameResponse is the TestSchemaQuery/ListExampleAutoIncFieldNameResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListExampleAutoIncFieldNameResponse {
    /// values are the results of the query.
    #[prost(message, repeated, tag="1")]
    pub values: ::prost::alloc::vec::Vec<ExampleAutoIncFieldName>,
    /// pagination is the pagination response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageResponse>,
}
// This is a simulated bank schema used for testing.

#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Balance {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
    #[prost(uint64, tag="3")]
    pub amount: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Supply {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    #[prost(uint64, tag="2")]
    pub amount: u64,
}
/// GetBalanceRequest is the BankQuery/GetBalanceRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBalanceRequest {
    /// address specifies the value of the address field in the primary key.
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    /// denom specifies the value of the denom field in the primary key.
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
}
/// GetBalanceResponse is the BankQuery/GetBalanceResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBalanceResponse {
    /// value is the response value.
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<Balance>,
}
/// ListBalanceRequest is the BankQuery/ListBalanceRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListBalanceRequest {
    /// pagination specifies optional pagination parameters.
    #[prost(message, optional, tag="3")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageRequest>,
    /// query specifies the type of query - either a prefix or range query.
    #[prost(oneof="list_balance_request::Query", tags="1, 2")]
    pub query: ::core::option::Option<list_balance_request::Query>,
}
/// Nested message and enum types in `ListBalanceRequest`.
pub mod list_balance_request {
    /// IndexKey specifies the value of an index key to use in prefix and range queries.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct IndexKey {
        /// key specifies the index key value.
        #[prost(oneof="index_key::Key", tags="1, 2")]
        pub key: ::core::option::Option<index_key::Key>,
    }
    /// Nested message and enum types in `IndexKey`.
    pub mod index_key {
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct AddressDenom {
            /// address is the value of the address field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="1")]
            pub address: ::core::option::Option<::prost::alloc::string::String>,
            /// denom is the value of the denom field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="2")]
            pub denom: ::core::option::Option<::prost::alloc::string::String>,
        }
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct Denom {
            /// denom is the value of the denom field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="1")]
            pub denom: ::core::option::Option<::prost::alloc::string::String>,
        }
        /// key specifies the index key value.
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
        pub enum Key {
            /// address_denom specifies the value of the AddressDenom index key to use in the query.
            #[prost(message, tag="1")]
            AddressDenom(AddressDenom),
            /// denom specifies the value of the Denom index key to use in the query.
            #[prost(message, tag="2")]
            Denom(Denom),
        }
    }
    /// RangeQuery specifies the from/to index keys for a range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct RangeQuery {
        /// from is the index key to use for the start of the range query.
        /// To query from the start of an index, specify an index key for that index with empty values.
        #[prost(message, optional, tag="1")]
        pub from: ::core::option::Option<IndexKey>,
        /// to is the index key to use for the end of the range query.
        /// The index key type MUST be the same as the index key type used for from.
        /// To query from to the end of an index it can be omitted.
        #[prost(message, optional, tag="2")]
        pub to: ::core::option::Option<IndexKey>,
    }
    /// query specifies the type of query - either a prefix or range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Query {
        /// prefix_query specifies the index key value to use for the prefix query.
        #[prost(message, tag="1")]
        PrefixQuery(IndexKey),
        /// range_query specifies the index key from/to values to use for the range query.
        #[prost(message, tag="2")]
        RangeQuery(RangeQuery),
    }
}
/// ListBalanceResponse is the BankQuery/ListBalanceResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListBalanceResponse {
    /// values are the results of the query.
    #[prost(message, repeated, tag="1")]
    pub values: ::prost::alloc::vec::Vec<Balance>,
    /// pagination is the pagination response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageResponse>,
}
/// GetSupplyRequest is the BankQuery/GetSupplyRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetSupplyRequest {
    /// denom specifies the value of the denom field in the primary key.
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
}
/// GetSupplyResponse is the BankQuery/GetSupplyResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetSupplyResponse {
    /// value is the response value.
    #[prost(message, optional, tag="1")]
    pub value: ::core::option::Option<Supply>,
}
/// ListSupplyRequest is the BankQuery/ListSupplyRequest request type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSupplyRequest {
    /// pagination specifies optional pagination parameters.
    #[prost(message, optional, tag="3")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageRequest>,
    /// query specifies the type of query - either a prefix or range query.
    #[prost(oneof="list_supply_request::Query", tags="1, 2")]
    pub query: ::core::option::Option<list_supply_request::Query>,
}
/// Nested message and enum types in `ListSupplyRequest`.
pub mod list_supply_request {
    /// IndexKey specifies the value of an index key to use in prefix and range queries.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct IndexKey {
        /// key specifies the index key value.
        #[prost(oneof="index_key::Key", tags="1")]
        pub key: ::core::option::Option<index_key::Key>,
    }
    /// Nested message and enum types in `IndexKey`.
    pub mod index_key {
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
        pub struct Denom {
            /// denom is the value of the denom field in the index.
            /// It can be omitted to query for all valid values of that field in this segment of the index.
            #[prost(string, optional, tag="1")]
            pub denom: ::core::option::Option<::prost::alloc::string::String>,
        }
        /// key specifies the index key value.
        #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
        pub enum Key {
            /// denom specifies the value of the Denom index key to use in the query.
            #[prost(message, tag="1")]
            Denom(Denom),
        }
    }
    /// RangeQuery specifies the from/to index keys for a range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct RangeQuery {
        /// from is the index key to use for the start of the range query.
        /// To query from the start of an index, specify an index key for that index with empty values.
        #[prost(message, optional, tag="1")]
        pub from: ::core::option::Option<IndexKey>,
        /// to is the index key to use for the end of the range query.
        /// The index key type MUST be the same as the index key type used for from.
        /// To query from to the end of an index it can be omitted.
        #[prost(message, optional, tag="2")]
        pub to: ::core::option::Option<IndexKey>,
    }
    /// query specifies the type of query - either a prefix or range query.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Query {
        /// prefix_query specifies the index key value to use for the prefix query.
        #[prost(message, tag="1")]
        PrefixQuery(IndexKey),
        /// range_query specifies the index key from/to values to use for the range query.
        #[prost(message, tag="2")]
        RangeQuery(RangeQuery),
    }
}
/// ListSupplyResponse is the BankQuery/ListSupplyResponse response type.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSupplyResponse {
    /// values are the results of the query.
    #[prost(message, repeated, tag="1")]
    pub values: ::prost::alloc::vec::Vec<Supply>,
    /// pagination is the pagination response.
    #[prost(message, optional, tag="2")]
    pub pagination: ::core::option::Option<super::cosmos::base::query::v1beta1::PageResponse>,
}
include!("testpb.tonic.rs");
// @@protoc_insertion_point(module)

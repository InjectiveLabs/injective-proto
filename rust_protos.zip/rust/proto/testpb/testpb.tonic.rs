// @generated
/// Generated client implementations.
pub mod test_schema_query_service_client {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    #[derive(Debug, Clone)]
    pub struct TestSchemaQueryServiceClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl TestSchemaQueryServiceClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> TestSchemaQueryServiceClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::BoxBody>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> TestSchemaQueryServiceClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::BoxBody>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
            >>::Error: Into<StdError> + Send + Sync,
        {
            TestSchemaQueryServiceClient::new(
                InterceptedService::new(inner, interceptor),
            )
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        pub async fn get_example_table(
            &mut self,
            request: impl tonic::IntoRequest<super::GetExampleTableRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleTableResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/GetExampleTable",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("testpb.TestSchemaQueryService", "GetExampleTable"),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_example_table_by_u64_str(
            &mut self,
            request: impl tonic::IntoRequest<super::GetExampleTableByU64StrRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleTableByU64StrResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/GetExampleTableByU64Str",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "GetExampleTableByU64Str",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn list_example_table(
            &mut self,
            request: impl tonic::IntoRequest<super::ListExampleTableRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListExampleTableResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/ListExampleTable",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("testpb.TestSchemaQueryService", "ListExampleTable"),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_example_auto_increment_table(
            &mut self,
            request: impl tonic::IntoRequest<super::GetExampleAutoIncrementTableRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleAutoIncrementTableResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/GetExampleAutoIncrementTable",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "GetExampleAutoIncrementTable",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_example_auto_increment_table_by_x(
            &mut self,
            request: impl tonic::IntoRequest<
                super::GetExampleAutoIncrementTableByXRequest,
            >,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleAutoIncrementTableByXResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/GetExampleAutoIncrementTableByX",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "GetExampleAutoIncrementTableByX",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn list_example_auto_increment_table(
            &mut self,
            request: impl tonic::IntoRequest<super::ListExampleAutoIncrementTableRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListExampleAutoIncrementTableResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/ListExampleAutoIncrementTable",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "ListExampleAutoIncrementTable",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_example_singleton(
            &mut self,
            request: impl tonic::IntoRequest<super::GetExampleSingletonRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleSingletonResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/GetExampleSingleton",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "GetExampleSingleton",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_example_timestamp(
            &mut self,
            request: impl tonic::IntoRequest<super::GetExampleTimestampRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleTimestampResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/GetExampleTimestamp",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "GetExampleTimestamp",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn list_example_timestamp(
            &mut self,
            request: impl tonic::IntoRequest<super::ListExampleTimestampRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListExampleTimestampResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/ListExampleTimestamp",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "ListExampleTimestamp",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_simple_example(
            &mut self,
            request: impl tonic::IntoRequest<super::GetSimpleExampleRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetSimpleExampleResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/GetSimpleExample",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("testpb.TestSchemaQueryService", "GetSimpleExample"),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_simple_example_by_unique(
            &mut self,
            request: impl tonic::IntoRequest<super::GetSimpleExampleByUniqueRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetSimpleExampleByUniqueResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/GetSimpleExampleByUnique",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "GetSimpleExampleByUnique",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn list_simple_example(
            &mut self,
            request: impl tonic::IntoRequest<super::ListSimpleExampleRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListSimpleExampleResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/ListSimpleExample",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("testpb.TestSchemaQueryService", "ListSimpleExample"),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_example_auto_inc_field_name(
            &mut self,
            request: impl tonic::IntoRequest<super::GetExampleAutoIncFieldNameRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleAutoIncFieldNameResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/GetExampleAutoIncFieldName",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "GetExampleAutoIncFieldName",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn list_example_auto_inc_field_name(
            &mut self,
            request: impl tonic::IntoRequest<super::ListExampleAutoIncFieldNameRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListExampleAutoIncFieldNameResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.TestSchemaQueryService/ListExampleAutoIncFieldName",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "testpb.TestSchemaQueryService",
                        "ListExampleAutoIncFieldName",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod test_schema_query_service_server {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with TestSchemaQueryServiceServer.
    #[async_trait]
    pub trait TestSchemaQueryService: Send + Sync + 'static {
        async fn get_example_table(
            &self,
            request: tonic::Request<super::GetExampleTableRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleTableResponse>,
            tonic::Status,
        >;
        async fn get_example_table_by_u64_str(
            &self,
            request: tonic::Request<super::GetExampleTableByU64StrRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleTableByU64StrResponse>,
            tonic::Status,
        >;
        async fn list_example_table(
            &self,
            request: tonic::Request<super::ListExampleTableRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListExampleTableResponse>,
            tonic::Status,
        >;
        async fn get_example_auto_increment_table(
            &self,
            request: tonic::Request<super::GetExampleAutoIncrementTableRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleAutoIncrementTableResponse>,
            tonic::Status,
        >;
        async fn get_example_auto_increment_table_by_x(
            &self,
            request: tonic::Request<super::GetExampleAutoIncrementTableByXRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleAutoIncrementTableByXResponse>,
            tonic::Status,
        >;
        async fn list_example_auto_increment_table(
            &self,
            request: tonic::Request<super::ListExampleAutoIncrementTableRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListExampleAutoIncrementTableResponse>,
            tonic::Status,
        >;
        async fn get_example_singleton(
            &self,
            request: tonic::Request<super::GetExampleSingletonRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleSingletonResponse>,
            tonic::Status,
        >;
        async fn get_example_timestamp(
            &self,
            request: tonic::Request<super::GetExampleTimestampRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleTimestampResponse>,
            tonic::Status,
        >;
        async fn list_example_timestamp(
            &self,
            request: tonic::Request<super::ListExampleTimestampRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListExampleTimestampResponse>,
            tonic::Status,
        >;
        async fn get_simple_example(
            &self,
            request: tonic::Request<super::GetSimpleExampleRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetSimpleExampleResponse>,
            tonic::Status,
        >;
        async fn get_simple_example_by_unique(
            &self,
            request: tonic::Request<super::GetSimpleExampleByUniqueRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetSimpleExampleByUniqueResponse>,
            tonic::Status,
        >;
        async fn list_simple_example(
            &self,
            request: tonic::Request<super::ListSimpleExampleRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListSimpleExampleResponse>,
            tonic::Status,
        >;
        async fn get_example_auto_inc_field_name(
            &self,
            request: tonic::Request<super::GetExampleAutoIncFieldNameRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetExampleAutoIncFieldNameResponse>,
            tonic::Status,
        >;
        async fn list_example_auto_inc_field_name(
            &self,
            request: tonic::Request<super::ListExampleAutoIncFieldNameRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListExampleAutoIncFieldNameResponse>,
            tonic::Status,
        >;
    }
    #[derive(Debug)]
    pub struct TestSchemaQueryServiceServer<T: TestSchemaQueryService> {
        inner: _Inner<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    struct _Inner<T>(Arc<T>);
    impl<T: TestSchemaQueryService> TestSchemaQueryServiceServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            let inner = _Inner(inner);
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>>
    for TestSchemaQueryServiceServer<T>
    where
        T: TestSchemaQueryService,
        B: Body + Send + 'static,
        B::Error: Into<StdError> + Send + 'static,
    {
        type Response = http::Response<tonic::body::BoxBody>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            let inner = self.inner.clone();
            match req.uri().path() {
                "/testpb.TestSchemaQueryService/GetExampleTable" => {
                    #[allow(non_camel_case_types)]
                    struct GetExampleTableSvc<T: TestSchemaQueryService>(pub Arc<T>);
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<super::GetExampleTableRequest>
                    for GetExampleTableSvc<T> {
                        type Response = super::GetExampleTableResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetExampleTableRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_example_table(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetExampleTableSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/GetExampleTableByU64Str" => {
                    #[allow(non_camel_case_types)]
                    struct GetExampleTableByU64StrSvc<T: TestSchemaQueryService>(
                        pub Arc<T>,
                    );
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<super::GetExampleTableByU64StrRequest>
                    for GetExampleTableByU64StrSvc<T> {
                        type Response = super::GetExampleTableByU64StrResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::GetExampleTableByU64StrRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_example_table_by_u64_str(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetExampleTableByU64StrSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/ListExampleTable" => {
                    #[allow(non_camel_case_types)]
                    struct ListExampleTableSvc<T: TestSchemaQueryService>(pub Arc<T>);
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<super::ListExampleTableRequest>
                    for ListExampleTableSvc<T> {
                        type Response = super::ListExampleTableResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ListExampleTableRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).list_example_table(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ListExampleTableSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/GetExampleAutoIncrementTable" => {
                    #[allow(non_camel_case_types)]
                    struct GetExampleAutoIncrementTableSvc<T: TestSchemaQueryService>(
                        pub Arc<T>,
                    );
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<
                        super::GetExampleAutoIncrementTableRequest,
                    > for GetExampleAutoIncrementTableSvc<T> {
                        type Response = super::GetExampleAutoIncrementTableResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::GetExampleAutoIncrementTableRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_example_auto_increment_table(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetExampleAutoIncrementTableSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/GetExampleAutoIncrementTableByX" => {
                    #[allow(non_camel_case_types)]
                    struct GetExampleAutoIncrementTableByXSvc<T: TestSchemaQueryService>(
                        pub Arc<T>,
                    );
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<
                        super::GetExampleAutoIncrementTableByXRequest,
                    > for GetExampleAutoIncrementTableByXSvc<T> {
                        type Response = super::GetExampleAutoIncrementTableByXResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::GetExampleAutoIncrementTableByXRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner)
                                    .get_example_auto_increment_table_by_x(request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetExampleAutoIncrementTableByXSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/ListExampleAutoIncrementTable" => {
                    #[allow(non_camel_case_types)]
                    struct ListExampleAutoIncrementTableSvc<T: TestSchemaQueryService>(
                        pub Arc<T>,
                    );
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<
                        super::ListExampleAutoIncrementTableRequest,
                    > for ListExampleAutoIncrementTableSvc<T> {
                        type Response = super::ListExampleAutoIncrementTableResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::ListExampleAutoIncrementTableRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).list_example_auto_increment_table(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ListExampleAutoIncrementTableSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/GetExampleSingleton" => {
                    #[allow(non_camel_case_types)]
                    struct GetExampleSingletonSvc<T: TestSchemaQueryService>(pub Arc<T>);
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<super::GetExampleSingletonRequest>
                    for GetExampleSingletonSvc<T> {
                        type Response = super::GetExampleSingletonResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetExampleSingletonRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_example_singleton(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetExampleSingletonSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/GetExampleTimestamp" => {
                    #[allow(non_camel_case_types)]
                    struct GetExampleTimestampSvc<T: TestSchemaQueryService>(pub Arc<T>);
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<super::GetExampleTimestampRequest>
                    for GetExampleTimestampSvc<T> {
                        type Response = super::GetExampleTimestampResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetExampleTimestampRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_example_timestamp(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetExampleTimestampSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/ListExampleTimestamp" => {
                    #[allow(non_camel_case_types)]
                    struct ListExampleTimestampSvc<T: TestSchemaQueryService>(
                        pub Arc<T>,
                    );
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<super::ListExampleTimestampRequest>
                    for ListExampleTimestampSvc<T> {
                        type Response = super::ListExampleTimestampResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ListExampleTimestampRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).list_example_timestamp(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ListExampleTimestampSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/GetSimpleExample" => {
                    #[allow(non_camel_case_types)]
                    struct GetSimpleExampleSvc<T: TestSchemaQueryService>(pub Arc<T>);
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<super::GetSimpleExampleRequest>
                    for GetSimpleExampleSvc<T> {
                        type Response = super::GetSimpleExampleResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetSimpleExampleRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_simple_example(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetSimpleExampleSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/GetSimpleExampleByUnique" => {
                    #[allow(non_camel_case_types)]
                    struct GetSimpleExampleByUniqueSvc<T: TestSchemaQueryService>(
                        pub Arc<T>,
                    );
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<super::GetSimpleExampleByUniqueRequest>
                    for GetSimpleExampleByUniqueSvc<T> {
                        type Response = super::GetSimpleExampleByUniqueResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::GetSimpleExampleByUniqueRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_simple_example_by_unique(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetSimpleExampleByUniqueSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/ListSimpleExample" => {
                    #[allow(non_camel_case_types)]
                    struct ListSimpleExampleSvc<T: TestSchemaQueryService>(pub Arc<T>);
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<super::ListSimpleExampleRequest>
                    for ListSimpleExampleSvc<T> {
                        type Response = super::ListSimpleExampleResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ListSimpleExampleRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).list_simple_example(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ListSimpleExampleSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/GetExampleAutoIncFieldName" => {
                    #[allow(non_camel_case_types)]
                    struct GetExampleAutoIncFieldNameSvc<T: TestSchemaQueryService>(
                        pub Arc<T>,
                    );
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<
                        super::GetExampleAutoIncFieldNameRequest,
                    > for GetExampleAutoIncFieldNameSvc<T> {
                        type Response = super::GetExampleAutoIncFieldNameResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::GetExampleAutoIncFieldNameRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_example_auto_inc_field_name(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetExampleAutoIncFieldNameSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.TestSchemaQueryService/ListExampleAutoIncFieldName" => {
                    #[allow(non_camel_case_types)]
                    struct ListExampleAutoIncFieldNameSvc<T: TestSchemaQueryService>(
                        pub Arc<T>,
                    );
                    impl<
                        T: TestSchemaQueryService,
                    > tonic::server::UnaryService<
                        super::ListExampleAutoIncFieldNameRequest,
                    > for ListExampleAutoIncFieldNameSvc<T> {
                        type Response = super::ListExampleAutoIncFieldNameResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::ListExampleAutoIncFieldNameRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).list_example_auto_inc_field_name(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ListExampleAutoIncFieldNameSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        Ok(
                            http::Response::builder()
                                .status(200)
                                .header("grpc-status", "12")
                                .header("content-type", "application/grpc")
                                .body(empty_body())
                                .unwrap(),
                        )
                    })
                }
            }
        }
    }
    impl<T: TestSchemaQueryService> Clone for TestSchemaQueryServiceServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    impl<T: TestSchemaQueryService> Clone for _Inner<T> {
        fn clone(&self) -> Self {
            Self(Arc::clone(&self.0))
        }
    }
    impl<T: std::fmt::Debug> std::fmt::Debug for _Inner<T> {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(f, "{:?}", self.0)
        }
    }
    impl<T: TestSchemaQueryService> tonic::server::NamedService
    for TestSchemaQueryServiceServer<T> {
        const NAME: &'static str = "testpb.TestSchemaQueryService";
    }
}
/// Generated client implementations.
pub mod bank_query_service_client {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    #[derive(Debug, Clone)]
    pub struct BankQueryServiceClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl BankQueryServiceClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> BankQueryServiceClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::BoxBody>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> BankQueryServiceClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::BoxBody>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
            >>::Error: Into<StdError> + Send + Sync,
        {
            BankQueryServiceClient::new(InterceptedService::new(inner, interceptor))
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        pub async fn get_balance(
            &mut self,
            request: impl tonic::IntoRequest<super::GetBalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBalanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.BankQueryService/GetBalance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("testpb.BankQueryService", "GetBalance"));
            self.inner.unary(req, path, codec).await
        }
        pub async fn list_balance(
            &mut self,
            request: impl tonic::IntoRequest<super::ListBalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListBalanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.BankQueryService/ListBalance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("testpb.BankQueryService", "ListBalance"));
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_supply(
            &mut self,
            request: impl tonic::IntoRequest<super::GetSupplyRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetSupplyResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.BankQueryService/GetSupply",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("testpb.BankQueryService", "GetSupply"));
            self.inner.unary(req, path, codec).await
        }
        pub async fn list_supply(
            &mut self,
            request: impl tonic::IntoRequest<super::ListSupplyRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListSupplyResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/testpb.BankQueryService/ListSupply",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("testpb.BankQueryService", "ListSupply"));
            self.inner.unary(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod bank_query_service_server {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with BankQueryServiceServer.
    #[async_trait]
    pub trait BankQueryService: Send + Sync + 'static {
        async fn get_balance(
            &self,
            request: tonic::Request<super::GetBalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBalanceResponse>,
            tonic::Status,
        >;
        async fn list_balance(
            &self,
            request: tonic::Request<super::ListBalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListBalanceResponse>,
            tonic::Status,
        >;
        async fn get_supply(
            &self,
            request: tonic::Request<super::GetSupplyRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetSupplyResponse>,
            tonic::Status,
        >;
        async fn list_supply(
            &self,
            request: tonic::Request<super::ListSupplyRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListSupplyResponse>,
            tonic::Status,
        >;
    }
    #[derive(Debug)]
    pub struct BankQueryServiceServer<T: BankQueryService> {
        inner: _Inner<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    struct _Inner<T>(Arc<T>);
    impl<T: BankQueryService> BankQueryServiceServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            let inner = _Inner(inner);
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>> for BankQueryServiceServer<T>
    where
        T: BankQueryService,
        B: Body + Send + 'static,
        B::Error: Into<StdError> + Send + 'static,
    {
        type Response = http::Response<tonic::body::BoxBody>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            let inner = self.inner.clone();
            match req.uri().path() {
                "/testpb.BankQueryService/GetBalance" => {
                    #[allow(non_camel_case_types)]
                    struct GetBalanceSvc<T: BankQueryService>(pub Arc<T>);
                    impl<
                        T: BankQueryService,
                    > tonic::server::UnaryService<super::GetBalanceRequest>
                    for GetBalanceSvc<T> {
                        type Response = super::GetBalanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetBalanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move { (*inner).get_balance(request).await };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetBalanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.BankQueryService/ListBalance" => {
                    #[allow(non_camel_case_types)]
                    struct ListBalanceSvc<T: BankQueryService>(pub Arc<T>);
                    impl<
                        T: BankQueryService,
                    > tonic::server::UnaryService<super::ListBalanceRequest>
                    for ListBalanceSvc<T> {
                        type Response = super::ListBalanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ListBalanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).list_balance(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ListBalanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.BankQueryService/GetSupply" => {
                    #[allow(non_camel_case_types)]
                    struct GetSupplySvc<T: BankQueryService>(pub Arc<T>);
                    impl<
                        T: BankQueryService,
                    > tonic::server::UnaryService<super::GetSupplyRequest>
                    for GetSupplySvc<T> {
                        type Response = super::GetSupplyResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetSupplyRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move { (*inner).get_supply(request).await };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetSupplySvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/testpb.BankQueryService/ListSupply" => {
                    #[allow(non_camel_case_types)]
                    struct ListSupplySvc<T: BankQueryService>(pub Arc<T>);
                    impl<
                        T: BankQueryService,
                    > tonic::server::UnaryService<super::ListSupplyRequest>
                    for ListSupplySvc<T> {
                        type Response = super::ListSupplyResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ListSupplyRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move { (*inner).list_supply(request).await };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ListSupplySvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        Ok(
                            http::Response::builder()
                                .status(200)
                                .header("grpc-status", "12")
                                .header("content-type", "application/grpc")
                                .body(empty_body())
                                .unwrap(),
                        )
                    })
                }
            }
        }
    }
    impl<T: BankQueryService> Clone for BankQueryServiceServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    impl<T: BankQueryService> Clone for _Inner<T> {
        fn clone(&self) -> Self {
            Self(Arc::clone(&self.0))
        }
    }
    impl<T: std::fmt::Debug> std::fmt::Debug for _Inner<T> {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(f, "{:?}", self.0)
        }
    }
    impl<T: BankQueryService> tonic::server::NamedService for BankQueryServiceServer<T> {
        const NAME: &'static str = "testpb.BankQueryService";
    }
}

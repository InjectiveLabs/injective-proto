// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetVaultRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetVaultResponse {
    /// The vault
    #[prost(message, optional, tag="1")]
    pub vault: ::core::option::Option<Vault>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Vault {
    /// Contract address
    #[prost(string, tag="1")]
    pub contract_address: ::prost::alloc::string::String,
    /// Contract name
    #[prost(string, tag="2")]
    pub contract_name: ::prost::alloc::string::String,
    /// Contract version
    #[prost(string, tag="3")]
    pub contract_version: ::prost::alloc::string::String,
    /// Admin
    #[prost(string, tag="4")]
    pub admin: ::prost::alloc::string::String,
    /// LP denom
    #[prost(string, tag="5")]
    pub lp_denom: ::prost::alloc::string::String,
    /// Quote denom
    #[prost(string, tag="6")]
    pub quote_denom: ::prost::alloc::string::String,
    /// Total amount
    #[prost(string, tag="7")]
    pub total_amount: ::prost::alloc::string::String,
    /// Total amount of LP token
    #[prost(string, tag="8")]
    pub total_lp_amount: ::prost::alloc::string::String,
    /// Operators
    #[prost(message, repeated, tag="9")]
    pub operators: ::prost::alloc::vec::Vec<Operator>,
    /// Block height when the vault was created.
    #[prost(sint64, tag="10")]
    pub created_height: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="11")]
    pub created_at: i64,
    /// Block height when the vault was updated.
    #[prost(sint64, tag="12")]
    pub updated_height: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="13")]
    pub updated_at: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Operator {
    /// Operator address
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    /// Contract name
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
    /// Block height when the operator was updated.
    #[prost(sint64, tag="3")]
    pub updated_height: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="4")]
    pub updated_at: i64,
}
include!("injective_megavault_rpc.tonic.rs");
// @@protoc_insertion_point(module)

// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetVaultRequest {
    /// Vault address
    #[prost(string, tag="1")]
    pub vault_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetVaultResponse {
    /// The vault
    #[prost(message, optional, tag="1")]
    pub vault: ::core::option::Option<Vault>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Vault {
    /// Contract address
    #[prost(string, tag="1")]
    pub contract_address: ::prost::alloc::string::String,
    /// Contract name
    #[prost(string, tag="2")]
    pub contract_name: ::prost::alloc::string::String,
    /// Contract version
    #[prost(string, tag="3")]
    pub contract_version: ::prost::alloc::string::String,
    /// Admin
    #[prost(string, tag="4")]
    pub admin: ::prost::alloc::string::String,
    /// LP denom
    #[prost(string, tag="5")]
    pub lp_denom: ::prost::alloc::string::String,
    /// Quote denom
    #[prost(string, tag="6")]
    pub quote_denom: ::prost::alloc::string::String,
    /// Operators
    #[prost(message, repeated, tag="7")]
    pub operators: ::prost::alloc::vec::Vec<Operator>,
    /// Incentives
    #[prost(message, optional, tag="8")]
    pub incentives: ::core::option::Option<Incentives>,
    /// TargetApr
    #[prost(message, optional, tag="9")]
    pub target_apr: ::core::option::Option<TargetApr>,
    /// Operators
    #[prost(message, optional, tag="10")]
    pub stats: ::core::option::Option<VaultStats>,
    /// Block height when the vault was created.
    #[prost(sint64, tag="11")]
    pub created_height: i64,
    /// CreatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="12")]
    pub created_at: i64,
    /// Block height when the vault was updated.
    #[prost(sint64, tag="13")]
    pub updated_height: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="14")]
    pub updated_at: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Operator {
    /// Operator address
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    /// Total amount
    #[prost(string, tag="2")]
    pub total_amount: ::prost::alloc::string::String,
    /// Total liquid amount
    #[prost(string, tag="3")]
    pub total_liquid_amount: ::prost::alloc::string::String,
    /// Block height when the operator was updated.
    #[prost(sint64, tag="4")]
    pub updated_height: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="5")]
    pub updated_at: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Incentives {
    /// Operator address
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    /// Amount
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
    /// Block height when the target APR was updated.
    #[prost(sint64, tag="3")]
    pub updated_height: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="4")]
    pub updated_at: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TargetApr {
    /// APR
    #[prost(string, tag="1")]
    pub apr: ::prost::alloc::string::String,
    /// Upper threshold
    #[prost(string, tag="2")]
    pub upper_threshold: ::prost::alloc::string::String,
    /// Lower threshold
    #[prost(string, tag="3")]
    pub lower_threshold: ::prost::alloc::string::String,
    /// Block height when the target APR was updated.
    #[prost(sint64, tag="4")]
    pub updated_height: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="5")]
    pub updated_at: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct VaultStats {
    /// Total subscribed amount in the vault
    #[prost(string, tag="1")]
    pub total_subscribed_amount: ::prost::alloc::string::String,
    /// Total redeemed amount in the vault
    #[prost(string, tag="2")]
    pub total_redeemed_amount: ::prost::alloc::string::String,
    /// Current amount in the vault
    #[prost(string, tag="3")]
    pub current_amount: ::prost::alloc::string::String,
    /// Current amount in the vault without taking into account the incentives
    #[prost(string, tag="4")]
    pub current_amount_without_incentives: ::prost::alloc::string::String,
    /// Current amount of LP tokens in the vault
    #[prost(string, tag="5")]
    pub current_lp_amount: ::prost::alloc::string::String,
    /// Current LP price
    #[prost(string, tag="6")]
    pub current_lp_price: ::prost::alloc::string::String,
    /// PnL statistics
    #[prost(message, optional, tag="7")]
    pub pnl: ::core::option::Option<PnlStats>,
    /// Volatility statistics
    #[prost(message, optional, tag="8")]
    pub volatility: ::core::option::Option<VolatilityStats>,
    /// APR statistics
    #[prost(message, optional, tag="9")]
    pub apr: ::core::option::Option<AprStats>,
    /// Max drawdown
    #[prost(message, optional, tag="10")]
    pub max_drawdown: ::core::option::Option<MaxDrawdown>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PnlStats {
    /// Unrealized PnL
    #[prost(message, optional, tag="1")]
    pub unrealized: ::core::option::Option<UnrealizedPnl>,
    /// All-time PnL
    #[prost(message, optional, tag="2")]
    pub all_time: ::core::option::Option<Pnl>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UnrealizedPnl {
    /// Unrealized PnL value
    #[prost(string, tag="1")]
    pub value: ::prost::alloc::string::String,
    /// Unrealized PnL percentage
    #[prost(string, tag="2")]
    pub percentage: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Pnl {
    /// PnL value
    #[prost(string, tag="1")]
    pub value: ::prost::alloc::string::String,
    /// PnL percentage
    #[prost(string, tag="2")]
    pub percentage: ::prost::alloc::string::String,
    /// Total amount subscribed
    #[prost(string, tag="3")]
    pub total_amount_subscribed: ::prost::alloc::string::String,
    /// Total amount redeemed
    #[prost(string, tag="4")]
    pub total_amount_redeemed: ::prost::alloc::string::String,
    /// Current amount
    #[prost(string, tag="5")]
    pub current_amount: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct VolatilityStats {
    /// 30-days volatility
    #[prost(message, optional, tag="1")]
    pub thirty_days: ::core::option::Option<Volatility>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Volatility {
    /// Volatility value
    #[prost(string, tag="1")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AprStats {
    /// 30-day APR
    #[prost(message, optional, tag="1")]
    pub thirty_days: ::core::option::Option<Apr>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Apr {
    /// APR value
    #[prost(string, tag="1")]
    pub value: ::prost::alloc::string::String,
    /// Original LP price
    #[prost(string, tag="2")]
    pub original_lp_price: ::prost::alloc::string::String,
    /// Current LP price
    #[prost(string, tag="3")]
    pub current_lp_price: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MaxDrawdown {
    /// Max drawdown value
    #[prost(string, tag="1")]
    pub value: ::prost::alloc::string::String,
    /// Latest PnL peak
    #[prost(string, tag="2")]
    pub latest_pn_l_peak: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetUserRequest {
    /// Vault address
    #[prost(string, tag="1")]
    pub vault_address: ::prost::alloc::string::String,
    /// User address
    #[prost(string, tag="2")]
    pub user_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetUserResponse {
    /// The user
    #[prost(message, optional, tag="1")]
    pub user: ::core::option::Option<User>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct User {
    /// User address
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    /// Contract address
    #[prost(string, tag="2")]
    pub contract_address: ::prost::alloc::string::String,
    /// User stats
    #[prost(message, optional, tag="3")]
    pub stats: ::core::option::Option<UserStats>,
    /// Block height when the vault was updated.
    #[prost(sint64, tag="4")]
    pub updated_height: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="5")]
    pub updated_at: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UserStats {
    /// Current subscribed amount in the vault
    #[prost(string, tag="1")]
    pub current_amount: ::prost::alloc::string::String,
    /// Current amount of LP tokens in the vault
    #[prost(string, tag="2")]
    pub current_lp_amount: ::prost::alloc::string::String,
    /// PnL statistics
    #[prost(message, optional, tag="3")]
    pub pnl: ::core::option::Option<PnlStats>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSubscriptionsRequest {
    /// Vault address
    #[prost(string, tag="1")]
    pub vault_address: ::prost::alloc::string::String,
    /// User address
    #[prost(string, tag="2")]
    pub user_address: ::prost::alloc::string::String,
    /// Status of the redemption
    #[prost(string, tag="3")]
    pub status: ::prost::alloc::string::String,
    #[prost(sint32, tag="4")]
    pub per_page: i32,
    #[prost(string, tag="5")]
    pub token: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSubscriptionsResponse {
    /// List of subscriptions
    #[prost(message, repeated, tag="1")]
    pub subscriptions: ::prost::alloc::vec::Vec<Subscription>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Subscription {
    /// Contract address
    #[prost(string, tag="1")]
    pub contract_address: ::prost::alloc::string::String,
    /// User
    #[prost(string, tag="2")]
    pub user: ::prost::alloc::string::String,
    /// Index number of the subscription
    #[prost(sint64, tag="3")]
    pub index: i64,
    /// Amount of LP tokens given to the user for the subscription
    #[prost(string, tag="4")]
    pub lp_amount: ::prost::alloc::string::String,
    /// Amount in USDT the user gave for the subscription
    #[prost(string, tag="5")]
    pub amount: ::prost::alloc::string::String,
    /// Status of the subscription
    #[prost(string, tag="6")]
    pub status: ::prost::alloc::string::String,
    /// Block height when the subscription was created.
    #[prost(sint64, tag="7")]
    pub created_height: i64,
    /// CreatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="8")]
    pub created_at: i64,
    /// Block height when the subscription was executed.
    #[prost(sint64, tag="9")]
    pub executed_height: i64,
    /// ExecutedAt timestamp in UNIX millis.
    #[prost(sint64, tag="10")]
    pub executed_at: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListRedemptionsRequest {
    /// Vault address
    #[prost(string, tag="1")]
    pub vault_address: ::prost::alloc::string::String,
    /// User address
    #[prost(string, tag="2")]
    pub user_address: ::prost::alloc::string::String,
    /// Status of the redemption
    #[prost(string, tag="3")]
    pub status: ::prost::alloc::string::String,
    #[prost(sint32, tag="4")]
    pub per_page: i32,
    #[prost(string, tag="5")]
    pub token: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListRedemptionsResponse {
    /// List of subscriptions
    #[prost(message, repeated, tag="1")]
    pub redemptions: ::prost::alloc::vec::Vec<Redemption>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Redemption {
    /// Contract address
    #[prost(string, tag="1")]
    pub contract_address: ::prost::alloc::string::String,
    /// User
    #[prost(string, tag="2")]
    pub user: ::prost::alloc::string::String,
    /// Index number of the redemption
    #[prost(sint64, tag="3")]
    pub index: i64,
    /// Amount of LP tokens given to the user for the redemption
    #[prost(string, tag="4")]
    pub lp_amount: ::prost::alloc::string::String,
    /// Amount in USDT the user gave for the redemption
    #[prost(string, tag="5")]
    pub amount: ::prost::alloc::string::String,
    /// Status of the subscription
    #[prost(string, tag="6")]
    pub status: ::prost::alloc::string::String,
    /// DueAt timestamp in UNIX millis.
    #[prost(sint64, tag="7")]
    pub due_at: i64,
    /// Block height when the subscription was created.
    #[prost(sint64, tag="8")]
    pub created_height: i64,
    /// CreatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="9")]
    pub created_at: i64,
    /// Block height when the subscription was executed.
    #[prost(sint64, tag="10")]
    pub executed_height: i64,
    /// ExecutedAt timestamp in UNIX millis.
    #[prost(sint64, tag="11")]
    pub executed_at: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetOperatorRedemptionBucketsRequest {
    /// Vault address
    #[prost(string, tag="1")]
    pub vault_address: ::prost::alloc::string::String,
    /// Operator address
    #[prost(string, tag="2")]
    pub operator_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetOperatorRedemptionBucketsResponse {
    /// The redemption buckets
    #[prost(message, repeated, tag="1")]
    pub buckets: ::prost::alloc::vec::Vec<RedemptionBucket>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RedemptionBucket {
    /// Bucket
    #[prost(string, tag="1")]
    pub bucket: ::prost::alloc::string::String,
    /// Amount of LP tokens to redeem
    #[prost(string, tag="2")]
    pub lp_amount_to_redeem: ::prost::alloc::string::String,
    /// Amount needed to cover all the redemptions in the bucket
    #[prost(string, tag="3")]
    pub needed_amount: ::prost::alloc::string::String,
    /// Amount of liquidity missing needed to cover all the redemptions in the bucket
    #[prost(string, tag="4")]
    pub missing_liquidity: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TvlHistoryRequest {
    /// Vault address
    #[prost(string, tag="1")]
    pub vault_address: ::prost::alloc::string::String,
    /// timestamp from which to start the query in milliseconds (UTC)
    #[prost(sint64, tag="2")]
    pub since: i64,
    /// amount of data points to return
    #[prost(sint32, tag="3")]
    pub max_data_points: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TvlHistoryResponse {
    #[prost(message, repeated, tag="1")]
    pub history: ::prost::alloc::vec::Vec<HistoricalTvl>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct HistoricalTvl {
    /// Time, Unix timestamp in milliseconds (UTC)
    #[prost(sint32, tag="1")]
    pub t: i32,
    /// TVL Value
    #[prost(string, tag="2")]
    pub v: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PnlHistoryRequest {
    /// Vault address
    #[prost(string, tag="1")]
    pub vault_address: ::prost::alloc::string::String,
    /// timestamp from which to start the query in milliseconds (UTC)
    #[prost(sint64, tag="2")]
    pub since: i64,
    /// amount of data points to return
    #[prost(sint32, tag="3")]
    pub max_data_points: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PnlHistoryResponse {
    #[prost(message, repeated, tag="1")]
    pub history: ::prost::alloc::vec::Vec<HistoricalPnL>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct HistoricalPnL {
    /// Time, Unix timestamp in milliseconds (UTC)
    #[prost(sint32, tag="1")]
    pub t: i32,
    /// PnL Value
    #[prost(string, tag="2")]
    pub v: ::prost::alloc::string::String,
}
include!("injective_megavault_rpc.tonic.rs");
// @@protoc_insertion_point(module)

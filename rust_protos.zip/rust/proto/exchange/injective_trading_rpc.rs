// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListTradingStrategiesRequest {
    #[prost(string, tag="1")]
    pub state: ::prost::alloc::string::String,
    /// MarketId of the trading strategy
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// subaccount ID to filter by
    #[prost(string, tag="3")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// Account address
    #[prost(string, tag="4")]
    pub account_address: ::prost::alloc::string::String,
    /// Indicates whether the trading strategy is pending execution
    #[prost(bool, tag="5")]
    pub pending_execution: bool,
    /// The starting timestamp in UNIX milliseconds for the creation time of the
    /// trading strategy
    #[prost(sint64, tag="6")]
    pub start_time: i64,
    /// The ending timestamp in UNIX milliseconds for the creation time of the
    /// trading strategy
    #[prost(sint64, tag="7")]
    pub end_time: i64,
    #[prost(sint32, tag="8")]
    pub limit: i32,
    #[prost(uint64, tag="9")]
    pub skip: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListTradingStrategiesResponse {
    /// The trading strategies
    #[prost(message, repeated, tag="1")]
    pub strategies: ::prost::alloc::vec::Vec<TradingStrategy>,
    #[prost(message, optional, tag="2")]
    pub paging: ::core::option::Option<Paging>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradingStrategy {
    #[prost(string, tag="1")]
    pub state: ::prost::alloc::string::String,
    /// MarketId of the trading strategy
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// subaccount ID of the trading strategy
    #[prost(string, tag="3")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// Account address
    #[prost(string, tag="4")]
    pub account_address: ::prost::alloc::string::String,
    /// Contract address
    #[prost(string, tag="5")]
    pub contract_address: ::prost::alloc::string::String,
    /// Execution price of the trading strategy
    #[prost(string, tag="6")]
    pub execution_price: ::prost::alloc::string::String,
    /// Base quantity of the trading strategy
    #[prost(string, tag="7")]
    pub base_quantity: ::prost::alloc::string::String,
    /// Quote quantity of the trading strategy
    #[prost(string, tag="20")]
    pub quote_quantity: ::prost::alloc::string::String,
    /// Lower bound of the trading strategy
    #[prost(string, tag="8")]
    pub lower_bound: ::prost::alloc::string::String,
    /// Upper bound of the trading strategy
    #[prost(string, tag="9")]
    pub upper_bound: ::prost::alloc::string::String,
    /// Stop loss limit of the trading strategy
    #[prost(string, tag="10")]
    pub stop_loss: ::prost::alloc::string::String,
    /// Take profit limit of the trading strategy
    #[prost(string, tag="11")]
    pub take_profit: ::prost::alloc::string::String,
    /// Swap fee of the trading strategy
    #[prost(string, tag="12")]
    pub swap_fee: ::prost::alloc::string::String,
    /// Base deposit at the time of closing the trading strategy
    #[prost(string, tag="17")]
    pub base_deposit: ::prost::alloc::string::String,
    /// Quote deposit at the time of closing the trading strategy
    #[prost(string, tag="18")]
    pub quote_deposit: ::prost::alloc::string::String,
    /// Market mid price at the time of closing the trading strategy
    #[prost(string, tag="19")]
    pub market_mid_price: ::prost::alloc::string::String,
    /// Subscription quote quantity of the trading strategy
    #[prost(string, tag="21")]
    pub subscription_quote_quantity: ::prost::alloc::string::String,
    /// Subscription base quantity of the trading strategy
    #[prost(string, tag="22")]
    pub subscription_base_quantity: ::prost::alloc::string::String,
    /// Number of grid levels of the trading strategy
    #[prost(string, tag="23")]
    pub number_of_grid_levels: ::prost::alloc::string::String,
    /// Indicates whether the trading strategy should exit with quote only
    #[prost(bool, tag="24")]
    pub should_exit_with_quote_only: bool,
    /// Indicates the reason for stopping the trading strategy
    #[prost(string, tag="25")]
    pub stop_reason: ::prost::alloc::string::String,
    /// Indicates whether the trading strategy is pending execution
    #[prost(bool, tag="26")]
    pub pending_execution: bool,
    /// Block height when the strategy was created.
    #[prost(sint64, tag="13")]
    pub created_height: i64,
    /// Block height when the strategy was removed.
    #[prost(sint64, tag="14")]
    pub removed_height: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="15")]
    pub created_at: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="16")]
    pub updated_at: i64,
}
/// Paging defines the structure for required params for handling pagination
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Paging {
    /// total number of txs saved in database
    #[prost(sint64, tag="1")]
    pub total: i64,
    /// can be either block height or index num
    #[prost(sint32, tag="2")]
    pub from: i32,
    /// can be either block height or index num
    #[prost(sint32, tag="3")]
    pub to: i32,
    /// count entries by subaccount, serving some places on helix
    #[prost(sint64, tag="4")]
    pub count_by_subaccount: i64,
    /// array of tokens to navigate to the next pages
    #[prost(string, repeated, tag="5")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
include!("injective_trading_rpc.tonic.rs");
// @@protoc_insertion_point(module)

// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RequestRequest {
    /// RFQ request to create
    #[prost(message, optional, tag="1")]
    pub request: ::core::option::Option<RfqRequestInputType>,
}
/// RFQ request
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqRequestInputType {
    /// Client ID
    #[prost(string, tag="1")]
    pub client_id: ::prost::alloc::string::String,
    /// Market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Direction (long/short)
    #[prost(string, tag="3")]
    pub direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="4")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="5")]
    pub quantity: ::prost::alloc::string::String,
    /// Worst acceptable price
    #[prost(string, tag="6")]
    pub worst_price: ::prost::alloc::string::String,
    /// Requester address
    #[prost(string, tag="7")]
    pub request_address: ::prost::alloc::string::String,
    /// Expiry timestamp in milliseconds
    #[prost(uint64, tag="8")]
    pub expiry: u64,
    /// Transaction time timestamp
    #[prost(uint64, tag="9")]
    pub transaction_time: u64,
    /// Whether the request is for price check only
    #[prost(bool, tag="10")]
    pub price_check: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RequestResponse {
    /// Status of the operation
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
    /// Client ID
    #[prost(string, tag="2")]
    pub client_id: ::prost::alloc::string::String,
    /// Generated RFQ ID
    #[prost(uint64, tag="3")]
    pub rfq_id: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamRequestRequest {
    /// Filter by market IDs
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamRequestResponse {
    /// RFQ request update
    #[prost(message, optional, tag="1")]
    pub request: ::core::option::Option<RfqRequestType>,
    /// Operation type (insert, update, delete)
    #[prost(string, tag="2")]
    pub stream_operation: ::prost::alloc::string::String,
}
/// RFQ request
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqRequestType {
    /// Client ID
    #[prost(string, tag="1")]
    pub client_id: ::prost::alloc::string::String,
    /// RFQ ID
    #[prost(uint64, tag="2")]
    pub rfq_id: u64,
    /// Market ID
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// Direction (long/short)
    #[prost(string, tag="4")]
    pub direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="5")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="6")]
    pub quantity: ::prost::alloc::string::String,
    /// Worst acceptable price
    #[prost(string, tag="7")]
    pub worst_price: ::prost::alloc::string::String,
    /// Requester address
    #[prost(string, tag="8")]
    pub request_address: ::prost::alloc::string::String,
    /// Expiry timestamp in milliseconds
    #[prost(uint64, tag="9")]
    pub expiry: u64,
    /// Status (open, cancelled, completed)
    #[prost(string, tag="10")]
    pub status: ::prost::alloc::string::String,
    /// Creation timestamp
    #[prost(sint64, tag="11")]
    pub created_at: i64,
    /// Last update timestamp
    #[prost(sint64, tag="12")]
    pub updated_at: i64,
    /// Transaction time timestamp
    #[prost(uint64, tag="13")]
    pub transaction_time: u64,
    /// Block height
    #[prost(uint64, tag="14")]
    pub height: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuoteRequest {
    /// RFQ quote to create
    #[prost(message, optional, tag="1")]
    pub quote: ::core::option::Option<RfqQuoteType>,
}
/// RFQ quote
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqQuoteType {
    /// Chain ID
    #[prost(string, tag="1")]
    pub chain_id: ::prost::alloc::string::String,
    /// Contract address
    #[prost(string, tag="2")]
    pub contract_address: ::prost::alloc::string::String,
    /// Market ID
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// RFQ ID
    #[prost(uint64, tag="4")]
    pub rfq_id: u64,
    /// Taker direction (long/short)
    #[prost(string, tag="5")]
    pub taker_direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="6")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="7")]
    pub quantity: ::prost::alloc::string::String,
    /// Price
    #[prost(string, tag="8")]
    pub price: ::prost::alloc::string::String,
    /// Expiry timestamp and height
    #[prost(message, optional, tag="9")]
    pub expiry: ::core::option::Option<RfqExpiryType>,
    /// Maker address
    #[prost(string, tag="10")]
    pub maker: ::prost::alloc::string::String,
    /// Taker address
    #[prost(string, tag="11")]
    pub taker: ::prost::alloc::string::String,
    /// Signature
    #[prost(string, tag="12")]
    pub signature: ::prost::alloc::string::String,
    /// Status (pending, accepted, rejected, expired)
    #[prost(string, tag="13")]
    pub status: ::prost::alloc::string::String,
    /// Creation timestamp
    #[prost(sint64, tag="14")]
    pub created_at: i64,
    /// Last update timestamp
    #[prost(sint64, tag="15")]
    pub updated_at: i64,
    /// Block height
    #[prost(uint64, tag="16")]
    pub height: u64,
    /// Event time timestamp
    #[prost(uint64, tag="17")]
    pub event_time: u64,
    /// Transaction time timestamp
    #[prost(uint64, tag="18")]
    pub transaction_time: u64,
    /// Maker subaccount nonce used in quote signature
    #[prost(uint64, tag="19")]
    pub maker_subaccount_nonce: u64,
    /// Optional minimum fill quantity used in quote signature
    #[prost(string, tag="20")]
    pub min_fill_quantity: ::prost::alloc::string::String,
    /// Whether the quote is for price check only
    #[prost(bool, tag="21")]
    pub price_check: bool,
    /// Client ID from the originating request
    #[prost(string, tag="22")]
    pub client_id: ::prost::alloc::string::String,
}
/// Expiry with timestamp and block height
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqExpiryType {
    /// Expiry timestamp in milliseconds
    #[prost(uint64, tag="1")]
    pub timestamp: u64,
    /// Expiry block height
    #[prost(uint64, tag="2")]
    pub height: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuoteResponse {
    /// Status of the operation
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamQuoteRequest {
    /// Filter by addresses
    #[prost(string, repeated, tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// Filter by market IDs
    #[prost(string, repeated, tag="2")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamQuoteResponse {
    /// RFQ quote update
    #[prost(message, optional, tag="1")]
    pub quote: ::core::option::Option<RfqProcessedQuoteType>,
    /// Operation type (insert, update, delete)
    #[prost(string, tag="2")]
    pub stream_operation: ::prost::alloc::string::String,
}
/// RFQ quote result streamed in real-time
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqProcessedQuoteType {
    /// Error message if quote is rejected
    #[prost(string, tag="50")]
    pub error: ::prost::alloc::string::String,
    /// Executed quantity for the quote, if successful
    #[prost(string, tag="51")]
    pub executed_quantity: ::prost::alloc::string::String,
    /// Executed margin for the quote, if successful
    #[prost(string, tag="52")]
    pub executed_margin: ::prost::alloc::string::String,
    /// Chain ID
    #[prost(string, tag="1")]
    pub chain_id: ::prost::alloc::string::String,
    /// Contract address
    #[prost(string, tag="2")]
    pub contract_address: ::prost::alloc::string::String,
    /// Market ID
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// RFQ ID
    #[prost(uint64, tag="4")]
    pub rfq_id: u64,
    /// Taker direction (long/short)
    #[prost(string, tag="5")]
    pub taker_direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="6")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="7")]
    pub quantity: ::prost::alloc::string::String,
    /// Price
    #[prost(string, tag="8")]
    pub price: ::prost::alloc::string::String,
    /// Expiry timestamp and height
    #[prost(message, optional, tag="9")]
    pub expiry: ::core::option::Option<RfqExpiryType>,
    /// Maker address
    #[prost(string, tag="10")]
    pub maker: ::prost::alloc::string::String,
    /// Taker address
    #[prost(string, tag="11")]
    pub taker: ::prost::alloc::string::String,
    /// Signature
    #[prost(string, tag="12")]
    pub signature: ::prost::alloc::string::String,
    /// Status (pending, accepted, rejected, expired)
    #[prost(string, tag="13")]
    pub status: ::prost::alloc::string::String,
    /// Creation timestamp
    #[prost(sint64, tag="14")]
    pub created_at: i64,
    /// Last update timestamp
    #[prost(sint64, tag="15")]
    pub updated_at: i64,
    /// Block height
    #[prost(uint64, tag="16")]
    pub height: u64,
    /// Event time timestamp
    #[prost(uint64, tag="17")]
    pub event_time: u64,
    /// Transaction time timestamp
    #[prost(uint64, tag="18")]
    pub transaction_time: u64,
    /// Maker subaccount nonce used in quote signature
    #[prost(uint64, tag="19")]
    pub maker_subaccount_nonce: u64,
    /// Optional minimum fill quantity used in quote signature
    #[prost(string, tag="20")]
    pub min_fill_quantity: ::prost::alloc::string::String,
    /// Whether the quote is for price check only
    #[prost(bool, tag="21")]
    pub price_check: bool,
    /// Client ID from the originating request
    #[prost(string, tag="22")]
    pub client_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSettlementRequest {
    /// Filter by taker addresses
    #[prost(string, repeated, tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// Number of records per page
    #[prost(sint32, tag="2")]
    pub per_page: i32,
    /// Pagination token
    #[prost(string, tag="3")]
    pub token: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSettlementResponse {
    /// List of RFQ settlements
    #[prost(message, repeated, tag="1")]
    pub settlements: ::prost::alloc::vec::Vec<RfqSettlementType>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// RFQ settlement
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementType {
    /// RFQ ID
    #[prost(uint64, tag="1")]
    pub rfq_id: u64,
    /// Market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Taker address
    #[prost(string, tag="3")]
    pub taker: ::prost::alloc::string::String,
    /// Direction (long/short)
    #[prost(string, tag="4")]
    pub direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="5")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="6")]
    pub quantity: ::prost::alloc::string::String,
    /// Worst acceptable price
    #[prost(string, tag="7")]
    pub worst_price: ::prost::alloc::string::String,
    /// Unfilled action details
    #[prost(message, optional, tag="8")]
    pub unfilled_action: ::core::option::Option<RfqSettlementUnfilledActionType>,
    /// Fallback quantity
    #[prost(string, tag="9")]
    pub fallback_quantity: ::prost::alloc::string::String,
    /// Fallback margin
    #[prost(string, tag="10")]
    pub fallback_margin: ::prost::alloc::string::String,
    /// Transaction time timestamp
    #[prost(uint64, tag="11")]
    pub transaction_time: u64,
    /// Creation timestamp
    #[prost(sint64, tag="12")]
    pub created_at: i64,
    /// Last update timestamp
    #[prost(sint64, tag="13")]
    pub updated_at: i64,
    /// Event time timestamp
    #[prost(uint64, tag="14")]
    pub event_time: u64,
    /// Block height
    #[prost(uint64, tag="15")]
    pub height: u64,
    /// Settlement CID
    #[prost(string, tag="16")]
    pub cid: ::prost::alloc::string::String,
}
/// Action to take for unfilled quantity - only one field should be set
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementUnfilledActionType {
    /// Limit order action
    #[prost(message, optional, tag="1")]
    pub limit: ::core::option::Option<RfqSettlementLimitActionType>,
    /// Market order action
    #[prost(message, optional, tag="2")]
    pub market: ::core::option::Option<RfqSettlementMarketActionType>,
}
/// Limit order action for unfilled quantity
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementLimitActionType {
    /// Limit price
    #[prost(string, tag="1")]
    pub price: ::prost::alloc::string::String,
}
/// Market order action for unfilled quantity
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementMarketActionType {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamSettlementRequest {
    /// Filter by addresses
    #[prost(string, repeated, tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamSettlementResponse {
    /// RFQ settlement update
    #[prost(message, optional, tag="1")]
    pub settlement: ::core::option::Option<RfqSettlementType>,
    /// Operation type (insert, update, delete)
    #[prost(string, tag="2")]
    pub stream_operation: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CreateConditionalOrderRequest {
    /// Conditional order fields
    #[prost(message, optional, tag="1")]
    pub order: ::core::option::Option<ConditionalOrderInput>,
    /// Hex-encoded 65-byte ECDSA recoverable signature (r‖s‖v). To produce: build
    /// the canonical JSON object with these fields in exact order, no omitted keys,
    /// null for absent values:
    /// version              (uint8)   — protocol version
    /// chain_id             (string)  — e.g. "injective-1"
    /// contract_address     (string)  — RFQ contract bech32 address
    /// taker               (string)  — taker bech32 address
    /// epoch               (uint64)  — taker's current epoch
    /// rfq_id              (uint64)  — unique order ID
    /// market_id           (string)  — derivative market ID hex
    /// subaccount_nonce    (uint32)  — taker subaccount index
    /// lane_version        (uint64)  — lane version for replay protection
    /// deadline_ms         (uint64)  — expiry timestamp in milliseconds
    /// direction           (string)  — "Long" or "Short"
    /// quantity            (string)  — FPDecimal e.g. "1", "4.9"
    /// margin              (string)  — collateral amount as FPDecimal
    /// worst_price         (string)  — FPDecimal worst acceptable price
    /// min_total_fill_quantity (string) — FPDecimal minimum fill
    /// trigger             (enum)    — {"MarkPriceGte":"<price>"} or
    /// {"MarkPriceLte":"<price>"}
    /// unfilled_action     (null)    — always null in v1
    /// cid                 (*string) — optional client ID, or null
    /// allowed_relayer     (*string) — optional relayer address, or null
    /// Then: signature = secp256k1_sign(Keccak256(canonical_json),
    /// taker_private_key)
    #[prost(string, tag="2")]
    pub signature: ::prost::alloc::string::String,
}
/// Conditional order input matching the contract's SignedTakerIntent payload
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ConditionalOrderInput {
    /// Protocol version
    #[prost(uint32, tag="1")]
    pub version: u32,
    /// Chain ID (e.g. injective-1)
    #[prost(string, tag="2")]
    pub chain_id: ::prost::alloc::string::String,
    /// RFQ contract address
    #[prost(string, tag="3")]
    pub contract_address: ::prost::alloc::string::String,
    /// Taker address (bech32)
    #[prost(string, tag="4")]
    pub taker: ::prost::alloc::string::String,
    /// Taker's current epoch (replay protection)
    #[prost(uint64, tag="5")]
    pub epoch: u64,
    /// Unique RFQ order ID
    #[prost(uint64, tag="6")]
    pub rfq_id: u64,
    /// Derivative market ID
    #[prost(string, tag="7")]
    pub market_id: ::prost::alloc::string::String,
    /// Taker subaccount index
    #[prost(uint32, tag="8")]
    pub subaccount_nonce: u32,
    /// Lane version (replay + OCO protection)
    #[prost(uint64, tag="9")]
    pub lane_version: u64,
    /// Expiry timestamp in milliseconds
    #[prost(uint64, tag="10")]
    pub deadline_ms: u64,
    /// Trade direction
    #[prost(string, tag="11")]
    pub direction: ::prost::alloc::string::String,
    /// FPDecimal quantity (e.g. "1", "4.9")
    #[prost(string, tag="12")]
    pub quantity: ::prost::alloc::string::String,
    /// Collateral amount as FPDecimal
    #[prost(string, tag="13")]
    pub margin: ::prost::alloc::string::String,
    /// FPDecimal worst acceptable price
    #[prost(string, tag="14")]
    pub worst_price: ::prost::alloc::string::String,
    /// FPDecimal minimum total fill quantity
    #[prost(string, tag="15")]
    pub min_total_fill_quantity: ::prost::alloc::string::String,
    /// Trigger condition type
    #[prost(string, tag="16")]
    pub trigger_type: ::prost::alloc::string::String,
    /// Mark price threshold for the trigger condition
    #[prost(string, tag="17")]
    pub trigger_price: ::prost::alloc::string::String,
    /// Post-unfilled action JSON (optional)
    #[prost(string, tag="18")]
    pub unfilled_action: ::prost::alloc::string::String,
    /// Optional client ID
    #[prost(string, tag="19")]
    pub cid: ::prost::alloc::string::String,
    /// Optional relayer restriction
    #[prost(string, tag="20")]
    pub allowed_relayer: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CreateConditionalOrderResponse {
    /// Created conditional order
    #[prost(message, optional, tag="1")]
    pub order: ::core::option::Option<ConditionalOrderResponseType>,
}
/// Conditional TP/SL order
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ConditionalOrderResponseType {
    /// RFQ order ID
    #[prost(uint64, tag="1")]
    pub rfq_id: u64,
    /// Derivative market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Exit direction (long/short)
    #[prost(string, tag="3")]
    pub direction: ::prost::alloc::string::String,
    /// Collateral amount
    #[prost(string, tag="4")]
    pub margin: ::prost::alloc::string::String,
    /// Contract quantity
    #[prost(string, tag="5")]
    pub quantity: ::prost::alloc::string::String,
    /// Worst acceptable price
    #[prost(string, tag="6")]
    pub worst_price: ::prost::alloc::string::String,
    /// Taker address
    #[prost(string, tag="7")]
    pub request_address: ::prost::alloc::string::String,
    /// Mark price threshold
    #[prost(string, tag="8")]
    pub trigger_price: ::prost::alloc::string::String,
    /// Order status
    #[prost(string, tag="9")]
    pub status: ::prost::alloc::string::String,
    /// Creation timestamp in milliseconds
    #[prost(sint64, tag="10")]
    pub created_at: i64,
    /// Last update timestamp in milliseconds
    #[prost(sint64, tag="11")]
    pub updated_at: i64,
    /// Expiry timestamp in milliseconds
    #[prost(sint64, tag="12")]
    pub expires_at: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListConditionalOrdersRequest {
    /// Taker address
    #[prost(string, tag="1")]
    pub request_address: ::prost::alloc::string::String,
    /// Filter by status
    #[prost(string, tag="2")]
    pub status: ::prost::alloc::string::String,
    /// Filter by market ID
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// Number of records per page
    #[prost(sint32, tag="4")]
    pub per_page: i32,
    /// Pagination token
    #[prost(string, tag="5")]
    pub token: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListConditionalOrdersResponse {
    /// List of conditional orders
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<ConditionalOrderResponseType>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// Message sent by taker in bidirectional stream
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TakerStreamStreamingRequest {
    /// Type: 'request', 'ping', 'conditional_order'
    #[prost(string, tag="1")]
    pub message_type: ::prost::alloc::string::String,
    /// RFQ request to create
    #[prost(message, optional, tag="2")]
    pub request: ::core::option::Option<CreateRfqRequestType>,
    /// Conditional order to create
    #[prost(message, optional, tag="3")]
    pub conditional_order: ::core::option::Option<ConditionalOrderInput>,
    /// Signature for the conditional order
    #[prost(string, tag="4")]
    pub conditional_order_signature: ::prost::alloc::string::String,
}
/// RFQ request
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CreateRfqRequestType {
    /// Client ID
    #[prost(string, tag="1")]
    pub client_id: ::prost::alloc::string::String,
    /// Market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Direction (long/short)
    #[prost(string, tag="3")]
    pub direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="4")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="5")]
    pub quantity: ::prost::alloc::string::String,
    /// Worst acceptable price
    #[prost(string, tag="6")]
    pub worst_price: ::prost::alloc::string::String,
    /// Expiry timestamp in milliseconds
    #[prost(uint64, tag="7")]
    pub expiry: u64,
    /// Whether the request is for price check only
    #[prost(bool, tag="8")]
    pub price_check: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TakerStreamResponse {
    /// Type: 'quote', 'request_ack', 'error', 'pong', 'conditional_order_ack'
    #[prost(string, tag="1")]
    pub message_type: ::prost::alloc::string::String,
    /// Quote from market maker
    #[prost(message, optional, tag="2")]
    pub quote: ::core::option::Option<RfqQuoteType>,
    /// Acknowledgment for request creation
    #[prost(message, optional, tag="3")]
    pub request_ack: ::core::option::Option<RequestStreamAck>,
    /// Error message
    #[prost(message, optional, tag="4")]
    pub error: ::core::option::Option<StreamError>,
    /// Acknowledgment for conditional order creation
    #[prost(message, optional, tag="5")]
    pub conditional_order_ack: ::core::option::Option<ConditionalOrderAck>,
}
/// Acknowledgment for stream operations
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RequestStreamAck {
    /// RFQ ID
    #[prost(uint64, tag="1")]
    pub rfq_id: u64,
    /// Client ID
    #[prost(string, tag="2")]
    pub client_id: ::prost::alloc::string::String,
    /// Status of the operation
    #[prost(string, tag="3")]
    pub status: ::prost::alloc::string::String,
}
/// Error message in stream
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamError {
    /// Error code
    #[prost(string, tag="1")]
    pub code: ::prost::alloc::string::String,
    /// Error message
    #[prost(string, tag="2")]
    pub message: ::prost::alloc::string::String,
}
/// Acknowledgment for conditional order creation
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ConditionalOrderAck {
    /// Created conditional order
    #[prost(message, optional, tag="1")]
    pub order: ::core::option::Option<ConditionalOrderResponseType>,
}
/// Message sent by maker in bidirectional stream
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MakerStreamStreamingRequest {
    /// Type: 'quote', 'ping'
    #[prost(string, tag="1")]
    pub message_type: ::prost::alloc::string::String,
    /// Quote to submit
    #[prost(message, optional, tag="2")]
    pub quote: ::core::option::Option<RfqQuoteType>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MakerStreamResponse {
    /// Type: 'request', 'quote_ack', 'quote_update', 'settlement_update', 'error',
    /// 'pong'
    #[prost(string, tag="1")]
    pub message_type: ::prost::alloc::string::String,
    /// RFQ request from taker
    #[prost(message, optional, tag="2")]
    pub request: ::core::option::Option<RfqRequestType>,
    /// Acknowledgment for quote submission
    #[prost(message, optional, tag="3")]
    pub quote_ack: ::core::option::Option<QuoteStreamAck>,
    /// Error message
    #[prost(message, optional, tag="4")]
    pub error: ::core::option::Option<StreamError>,
    /// Processed quote update for maker
    #[prost(message, optional, tag="5")]
    pub processed_quote: ::core::option::Option<RfqProcessedQuoteType>,
    /// Settlement update for maker
    #[prost(message, optional, tag="6")]
    pub settlement: ::core::option::Option<RfqSettlementMakerUpdate>,
}
/// Acknowledgment for stream operations
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuoteStreamAck {
    /// RFQ ID
    #[prost(uint64, tag="1")]
    pub rfq_id: u64,
    /// Status of the operation
    #[prost(string, tag="2")]
    pub status: ::prost::alloc::string::String,
}
/// RFQ settlement update streamed to maker in real-time
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementMakerUpdate {
    /// List of quotes considered for settlement
    #[prost(message, repeated, tag="50")]
    pub quotes: ::prost::alloc::vec::Vec<RfqSettlementQuote>,
    /// RFQ ID
    #[prost(uint64, tag="1")]
    pub rfq_id: u64,
    /// Market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Taker address
    #[prost(string, tag="3")]
    pub taker: ::prost::alloc::string::String,
    /// Direction (long/short)
    #[prost(string, tag="4")]
    pub direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="5")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="6")]
    pub quantity: ::prost::alloc::string::String,
    /// Worst acceptable price
    #[prost(string, tag="7")]
    pub worst_price: ::prost::alloc::string::String,
    /// Unfilled action details
    #[prost(message, optional, tag="8")]
    pub unfilled_action: ::core::option::Option<RfqSettlementUnfilledActionType>,
    /// Fallback quantity
    #[prost(string, tag="9")]
    pub fallback_quantity: ::prost::alloc::string::String,
    /// Fallback margin
    #[prost(string, tag="10")]
    pub fallback_margin: ::prost::alloc::string::String,
    /// Transaction time timestamp
    #[prost(uint64, tag="11")]
    pub transaction_time: u64,
    /// Creation timestamp
    #[prost(sint64, tag="12")]
    pub created_at: i64,
    /// Last update timestamp
    #[prost(sint64, tag="13")]
    pub updated_at: i64,
    /// Event time timestamp
    #[prost(uint64, tag="14")]
    pub event_time: u64,
    /// Block height
    #[prost(uint64, tag="15")]
    pub height: u64,
    /// Settlement CID
    #[prost(string, tag="16")]
    pub cid: ::prost::alloc::string::String,
}
/// Quote data embedded in settlement
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementQuote {
    /// Maker address
    #[prost(string, tag="1")]
    pub maker: ::prost::alloc::string::String,
    /// Price
    #[prost(string, tag="2")]
    pub price: ::prost::alloc::string::String,
    /// Quoted margin amount
    #[prost(string, tag="3")]
    pub quoted_margin: ::prost::alloc::string::String,
    /// Quoted quantity
    #[prost(string, tag="4")]
    pub quoted_quantity: ::prost::alloc::string::String,
    /// Executed margin amount
    #[prost(string, tag="5")]
    pub executed_margin: ::prost::alloc::string::String,
    /// Executed quantity
    #[prost(string, tag="6")]
    pub executed_quantity: ::prost::alloc::string::String,
    /// Expiry timestamp and height
    #[prost(message, optional, tag="7")]
    pub expiry: ::core::option::Option<RfqExpiryType>,
    /// Signature
    #[prost(string, tag="8")]
    pub signature: ::prost::alloc::string::String,
    /// Nonce
    #[prost(uint64, tag="9")]
    pub nonce: u64,
    /// Quote status (accepted, rejected, expired)
    #[prost(string, tag="10")]
    pub status: ::prost::alloc::string::String,
}
include!("injective_rfq_rpc.tonic.rs");
// @@protoc_insertion_point(module)

// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RequestRequest {
    /// RFQ request to create
    #[prost(message, optional, tag="1")]
    pub request: ::core::option::Option<RfqRequestType>,
}
/// RFQ request
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqRequestType {
    /// RFQ ID
    #[prost(uint64, tag="1")]
    pub rfq_id: u64,
    /// Market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Direction (long/short)
    #[prost(string, tag="3")]
    pub direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="4")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="5")]
    pub quantity: ::prost::alloc::string::String,
    /// Worst acceptable price
    #[prost(string, tag="6")]
    pub worst_price: ::prost::alloc::string::String,
    /// Requester address
    #[prost(string, tag="7")]
    pub request_address: ::prost::alloc::string::String,
    /// Expiry timestamp
    #[prost(uint64, tag="8")]
    pub expiry: u64,
    /// Status (open, cancelled, completed)
    #[prost(string, tag="9")]
    pub status: ::prost::alloc::string::String,
    /// Creation timestamp
    #[prost(sint64, tag="10")]
    pub created_at: i64,
    /// Last update timestamp
    #[prost(sint64, tag="11")]
    pub updated_at: i64,
    /// Transaction time timestamp
    #[prost(uint64, tag="12")]
    pub transaction_time: u64,
    /// Block height
    #[prost(uint64, tag="13")]
    pub height: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RequestResponse {
    /// Status of the operation
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamRequestRequest {
    /// Filter by market IDs
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamRequestResponse {
    /// RFQ request update
    #[prost(message, optional, tag="1")]
    pub request: ::core::option::Option<RfqRequestType>,
    /// Operation type (insert, update, delete)
    #[prost(string, tag="2")]
    pub stream_operation: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuoteRequest {
    /// RFQ quote to create
    #[prost(message, optional, tag="1")]
    pub quote: ::core::option::Option<RfqQuoteType>,
}
/// RFQ quote
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqQuoteType {
    /// Chain ID
    #[prost(string, tag="1")]
    pub chain_id: ::prost::alloc::string::String,
    /// Contract address
    #[prost(string, tag="2")]
    pub contract_address: ::prost::alloc::string::String,
    /// Market ID
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// RFQ ID
    #[prost(uint64, tag="4")]
    pub rfq_id: u64,
    /// Taker direction (long/short)
    #[prost(string, tag="5")]
    pub taker_direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="6")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="7")]
    pub quantity: ::prost::alloc::string::String,
    /// Price
    #[prost(string, tag="8")]
    pub price: ::prost::alloc::string::String,
    /// Expiry timestamp
    #[prost(uint64, tag="9")]
    pub expiry: u64,
    /// Maker address
    #[prost(string, tag="10")]
    pub maker: ::prost::alloc::string::String,
    /// Taker address
    #[prost(string, tag="11")]
    pub taker: ::prost::alloc::string::String,
    /// Signature
    #[prost(string, tag="12")]
    pub signature: ::prost::alloc::string::String,
    /// Status (pending, accepted, rejected, expired)
    #[prost(string, tag="13")]
    pub status: ::prost::alloc::string::String,
    /// Creation timestamp
    #[prost(sint64, tag="14")]
    pub created_at: i64,
    /// Last update timestamp
    #[prost(sint64, tag="15")]
    pub updated_at: i64,
    /// Block height
    #[prost(uint64, tag="16")]
    pub height: u64,
    /// Event time timestamp
    #[prost(uint64, tag="17")]
    pub event_time: u64,
    /// Transaction time timestamp
    #[prost(uint64, tag="18")]
    pub transaction_time: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QuoteResponse {
    /// Status of the operation
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamQuoteRequest {
    /// Filter by addresses
    #[prost(string, repeated, tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamQuoteResponse {
    /// RFQ quote update
    #[prost(message, optional, tag="1")]
    pub quote: ::core::option::Option<RfqQuoteType>,
    /// Operation type (insert, update, delete)
    #[prost(string, tag="2")]
    pub stream_operation: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetOpenRequestsRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetOpenRequestsResponse {
    /// List of open requests
    #[prost(message, repeated, tag="1")]
    pub requests: ::prost::alloc::vec::Vec<RfqRequestType>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPendingQuotesRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPendingQuotesResponse {
    /// List of pending quotes
    #[prost(message, repeated, tag="1")]
    pub quotes: ::prost::alloc::vec::Vec<RfqQuoteType>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSettlementRequest {
    /// Filter by taker addresses
    #[prost(string, repeated, tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// Skip records for pagination
    #[prost(sint64, tag="2")]
    pub skip: i64,
    /// Limit records for pagination
    #[prost(sint64, tag="3")]
    pub limit: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListSettlementResponse {
    /// List of RFQ settlements
    #[prost(message, repeated, tag="1")]
    pub settlements: ::prost::alloc::vec::Vec<RfqSettlementType>,
    /// Total count of records
    #[prost(sint64, tag="2")]
    pub total: i64,
}
/// RFQ settlement
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementType {
    /// RFQ ID
    #[prost(uint64, tag="1")]
    pub rfq_id: u64,
    /// Market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Taker address
    #[prost(string, tag="3")]
    pub taker: ::prost::alloc::string::String,
    /// Direction (long/short)
    #[prost(string, tag="4")]
    pub direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="5")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="6")]
    pub quantity: ::prost::alloc::string::String,
    /// Worst acceptable price
    #[prost(string, tag="7")]
    pub worst_price: ::prost::alloc::string::String,
    /// Unfilled action details
    #[prost(message, optional, tag="8")]
    pub unfilled_action: ::core::option::Option<RfqSettlementUnfilledActionType>,
    /// Fallback quantity
    #[prost(string, tag="9")]
    pub fallback_quantity: ::prost::alloc::string::String,
    /// Fallback margin
    #[prost(string, tag="10")]
    pub fallback_margin: ::prost::alloc::string::String,
    /// Transaction time timestamp
    #[prost(uint64, tag="11")]
    pub transaction_time: u64,
    /// Creation timestamp
    #[prost(sint64, tag="12")]
    pub created_at: i64,
    /// Last update timestamp
    #[prost(sint64, tag="13")]
    pub updated_at: i64,
    /// Event time timestamp
    #[prost(uint64, tag="14")]
    pub event_time: u64,
    /// Block height
    #[prost(uint64, tag="15")]
    pub height: u64,
}
/// Action to take for unfilled quantity - only one field should be set
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementUnfilledActionType {
    /// Limit order action
    #[prost(message, optional, tag="1")]
    pub limit: ::core::option::Option<RfqSettlementLimitActionType>,
    /// Market order action
    #[prost(message, optional, tag="2")]
    pub market: ::core::option::Option<RfqSettlementMarketActionType>,
}
/// Limit order action for unfilled quantity
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementLimitActionType {
    /// Limit price
    #[prost(string, tag="1")]
    pub price: ::prost::alloc::string::String,
}
/// Market order action for unfilled quantity
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RfqSettlementMarketActionType {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamSettlementRequest {
    /// Filter by addresses
    #[prost(string, repeated, tag="1")]
    pub addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamSettlementResponse {
    /// RFQ settlement update
    #[prost(message, optional, tag="1")]
    pub settlement: ::core::option::Option<RfqSettlementType>,
    /// Operation type (insert, update, delete)
    #[prost(string, tag="2")]
    pub stream_operation: ::prost::alloc::string::String,
}
/// Message sent by taker in bidirectional stream
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TakerStreamStreamingRequest {
    /// Type: 'request', 'ping'
    #[prost(string, tag="1")]
    pub message_type: ::prost::alloc::string::String,
    /// RFQ request to create
    #[prost(message, optional, tag="2")]
    pub request: ::core::option::Option<CreateRfqRequestType>,
}
/// RFQ request
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CreateRfqRequestType {
    /// RFQ ID
    #[prost(uint64, tag="1")]
    pub rfq_id: u64,
    /// Market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Direction (long/short)
    #[prost(string, tag="3")]
    pub direction: ::prost::alloc::string::String,
    /// Margin amount
    #[prost(string, tag="4")]
    pub margin: ::prost::alloc::string::String,
    /// Quantity
    #[prost(string, tag="5")]
    pub quantity: ::prost::alloc::string::String,
    /// Worst acceptable price
    #[prost(string, tag="6")]
    pub worst_price: ::prost::alloc::string::String,
    /// Expiry timestamp
    #[prost(uint64, tag="7")]
    pub expiry: u64,
    /// Status (open, cancelled, completed)
    #[prost(string, tag="8")]
    pub status: ::prost::alloc::string::String,
    /// Creation timestamp
    #[prost(sint64, tag="9")]
    pub created_at: i64,
    /// Last update timestamp
    #[prost(sint64, tag="10")]
    pub updated_at: i64,
    /// Transaction time timestamp
    #[prost(uint64, tag="11")]
    pub transaction_time: u64,
    /// Block height
    #[prost(uint64, tag="12")]
    pub height: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TakerStreamResponse {
    /// Type: 'quote', 'request_ack', 'error', 'pong'
    #[prost(string, tag="1")]
    pub message_type: ::prost::alloc::string::String,
    /// Quote from market maker
    #[prost(message, optional, tag="2")]
    pub quote: ::core::option::Option<RfqQuoteType>,
    /// Acknowledgment for request creation
    #[prost(message, optional, tag="3")]
    pub request_ack: ::core::option::Option<StreamAck>,
    /// Error message
    #[prost(message, optional, tag="4")]
    pub error: ::core::option::Option<StreamError>,
}
/// Acknowledgment for stream operations
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamAck {
    /// RFQ ID
    #[prost(uint64, tag="1")]
    pub rfq_id: u64,
    /// Status of the operation
    #[prost(string, tag="2")]
    pub status: ::prost::alloc::string::String,
}
/// Error message in stream
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamError {
    /// Error code
    #[prost(string, tag="1")]
    pub code: ::prost::alloc::string::String,
    /// Error message
    #[prost(string, tag="2")]
    pub message: ::prost::alloc::string::String,
}
/// Message sent by maker in bidirectional stream
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MakerStreamStreamingRequest {
    /// Type: 'quote', 'ping'
    #[prost(string, tag="1")]
    pub message_type: ::prost::alloc::string::String,
    /// Quote to submit
    #[prost(message, optional, tag="2")]
    pub quote: ::core::option::Option<RfqQuoteType>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MakerStreamResponse {
    /// Type: 'request', 'quote_ack', 'error', 'pong'
    #[prost(string, tag="1")]
    pub message_type: ::prost::alloc::string::String,
    /// RFQ request from taker
    #[prost(message, optional, tag="2")]
    pub request: ::core::option::Option<RfqRequestType>,
    /// Acknowledgment for quote submission
    #[prost(message, optional, tag="3")]
    pub quote_ack: ::core::option::Option<StreamAck>,
    /// Error message
    #[prost(message, optional, tag="4")]
    pub error: ::core::option::Option<StreamError>,
}
include!("injective_rfqrpc.tonic.rs");
// @@protoc_insertion_point(module)

// @generated
/// Generated client implementations.
pub mod injective_tc_derivatives_rpc_client {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    #[derive(Debug, Clone)]
    pub struct InjectiveTcDerivativesRpcClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl InjectiveTcDerivativesRpcClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> InjectiveTcDerivativesRpcClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::Body>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + std::marker::Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + std::marker::Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InjectiveTcDerivativesRpcClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::Body>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::Body>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::Body>,
            >>::Error: Into<StdError> + std::marker::Send + std::marker::Sync,
        {
            InjectiveTcDerivativesRpcClient::new(
                InterceptedService::new(inner, interceptor),
            )
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        pub async fn orders_history(
            &mut self,
            request: impl tonic::IntoRequest<super::OrdersHistoryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::OrdersHistoryResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/OrdersHistory",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC",
                        "OrdersHistory",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn stream_orders_history(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamOrdersHistoryRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamOrdersHistoryResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/StreamOrdersHistory",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC",
                        "StreamOrdersHistory",
                    ),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn orders(
            &mut self,
            request: impl tonic::IntoRequest<super::OrdersRequest>,
        ) -> std::result::Result<tonic::Response<super::OrdersResponse>, tonic::Status> {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/Orders",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC",
                        "Orders",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn stream_orders(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamOrdersRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamOrdersResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/StreamOrders",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC",
                        "StreamOrders",
                    ),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn trades(
            &mut self,
            request: impl tonic::IntoRequest<super::TradesRequest>,
        ) -> std::result::Result<tonic::Response<super::TradesResponse>, tonic::Status> {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/Trades",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC",
                        "Trades",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn stream_trades(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamTradesRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamTradesResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/StreamTrades",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC",
                        "StreamTrades",
                    ),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn positions(
            &mut self,
            request: impl tonic::IntoRequest<super::PositionsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PositionsResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/Positions",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC",
                        "Positions",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn stream_positions(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamPositionsRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamPositionsResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/StreamPositions",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC",
                        "StreamPositions",
                    ),
                );
            self.inner.server_streaming(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod injective_tc_derivatives_rpc_server {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with InjectiveTcDerivativesRpcServer.
    #[async_trait]
    pub trait InjectiveTcDerivativesRpc: std::marker::Send + std::marker::Sync + 'static {
        async fn orders_history(
            &self,
            request: tonic::Request<super::OrdersHistoryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::OrdersHistoryResponse>,
            tonic::Status,
        >;
        /// Server streaming response type for the StreamOrdersHistory method.
        type StreamOrdersHistoryStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<
                    super::StreamOrdersHistoryResponse,
                    tonic::Status,
                >,
            >
            + std::marker::Send
            + 'static;
        async fn stream_orders_history(
            &self,
            request: tonic::Request<super::StreamOrdersHistoryRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamOrdersHistoryStream>,
            tonic::Status,
        >;
        async fn orders(
            &self,
            request: tonic::Request<super::OrdersRequest>,
        ) -> std::result::Result<tonic::Response<super::OrdersResponse>, tonic::Status>;
        /// Server streaming response type for the StreamOrders method.
        type StreamOrdersStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<super::StreamOrdersResponse, tonic::Status>,
            >
            + std::marker::Send
            + 'static;
        async fn stream_orders(
            &self,
            request: tonic::Request<super::StreamOrdersRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamOrdersStream>,
            tonic::Status,
        >;
        async fn trades(
            &self,
            request: tonic::Request<super::TradesRequest>,
        ) -> std::result::Result<tonic::Response<super::TradesResponse>, tonic::Status>;
        /// Server streaming response type for the StreamTrades method.
        type StreamTradesStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<super::StreamTradesResponse, tonic::Status>,
            >
            + std::marker::Send
            + 'static;
        async fn stream_trades(
            &self,
            request: tonic::Request<super::StreamTradesRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamTradesStream>,
            tonic::Status,
        >;
        async fn positions(
            &self,
            request: tonic::Request<super::PositionsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PositionsResponse>,
            tonic::Status,
        >;
        /// Server streaming response type for the StreamPositions method.
        type StreamPositionsStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<super::StreamPositionsResponse, tonic::Status>,
            >
            + std::marker::Send
            + 'static;
        async fn stream_positions(
            &self,
            request: tonic::Request<super::StreamPositionsRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamPositionsStream>,
            tonic::Status,
        >;
    }
    #[derive(Debug)]
    pub struct InjectiveTcDerivativesRpcServer<T> {
        inner: Arc<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    impl<T> InjectiveTcDerivativesRpcServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>>
    for InjectiveTcDerivativesRpcServer<T>
    where
        T: InjectiveTcDerivativesRpc,
        B: Body + std::marker::Send + 'static,
        B::Error: Into<StdError> + std::marker::Send + 'static,
    {
        type Response = http::Response<tonic::body::Body>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            match req.uri().path() {
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/OrdersHistory" => {
                    #[allow(non_camel_case_types)]
                    struct OrdersHistorySvc<T: InjectiveTcDerivativesRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveTcDerivativesRpc,
                    > tonic::server::UnaryService<super::OrdersHistoryRequest>
                    for OrdersHistorySvc<T> {
                        type Response = super::OrdersHistoryResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::OrdersHistoryRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveTcDerivativesRpc>::orders_history(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = OrdersHistorySvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/StreamOrdersHistory" => {
                    #[allow(non_camel_case_types)]
                    struct StreamOrdersHistorySvc<T: InjectiveTcDerivativesRpc>(
                        pub Arc<T>,
                    );
                    impl<
                        T: InjectiveTcDerivativesRpc,
                    > tonic::server::ServerStreamingService<
                        super::StreamOrdersHistoryRequest,
                    > for StreamOrdersHistorySvc<T> {
                        type Response = super::StreamOrdersHistoryResponse;
                        type ResponseStream = T::StreamOrdersHistoryStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamOrdersHistoryRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveTcDerivativesRpc>::stream_orders_history(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = StreamOrdersHistorySvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/Orders" => {
                    #[allow(non_camel_case_types)]
                    struct OrdersSvc<T: InjectiveTcDerivativesRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveTcDerivativesRpc,
                    > tonic::server::UnaryService<super::OrdersRequest>
                    for OrdersSvc<T> {
                        type Response = super::OrdersResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::OrdersRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveTcDerivativesRpc>::orders(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = OrdersSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/StreamOrders" => {
                    #[allow(non_camel_case_types)]
                    struct StreamOrdersSvc<T: InjectiveTcDerivativesRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveTcDerivativesRpc,
                    > tonic::server::ServerStreamingService<super::StreamOrdersRequest>
                    for StreamOrdersSvc<T> {
                        type Response = super::StreamOrdersResponse;
                        type ResponseStream = T::StreamOrdersStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamOrdersRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveTcDerivativesRpc>::stream_orders(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = StreamOrdersSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/Trades" => {
                    #[allow(non_camel_case_types)]
                    struct TradesSvc<T: InjectiveTcDerivativesRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveTcDerivativesRpc,
                    > tonic::server::UnaryService<super::TradesRequest>
                    for TradesSvc<T> {
                        type Response = super::TradesResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::TradesRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveTcDerivativesRpc>::trades(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = TradesSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/StreamTrades" => {
                    #[allow(non_camel_case_types)]
                    struct StreamTradesSvc<T: InjectiveTcDerivativesRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveTcDerivativesRpc,
                    > tonic::server::ServerStreamingService<super::StreamTradesRequest>
                    for StreamTradesSvc<T> {
                        type Response = super::StreamTradesResponse;
                        type ResponseStream = T::StreamTradesStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamTradesRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveTcDerivativesRpc>::stream_trades(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = StreamTradesSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/Positions" => {
                    #[allow(non_camel_case_types)]
                    struct PositionsSvc<T: InjectiveTcDerivativesRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveTcDerivativesRpc,
                    > tonic::server::UnaryService<super::PositionsRequest>
                    for PositionsSvc<T> {
                        type Response = super::PositionsResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::PositionsRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveTcDerivativesRpc>::positions(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = PositionsSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC/StreamPositions" => {
                    #[allow(non_camel_case_types)]
                    struct StreamPositionsSvc<T: InjectiveTcDerivativesRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveTcDerivativesRpc,
                    > tonic::server::ServerStreamingService<
                        super::StreamPositionsRequest,
                    > for StreamPositionsSvc<T> {
                        type Response = super::StreamPositionsResponse;
                        type ResponseStream = T::StreamPositionsStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamPositionsRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveTcDerivativesRpc>::stream_positions(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = StreamPositionsSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        let mut response = http::Response::new(
                            tonic::body::Body::default(),
                        );
                        let headers = response.headers_mut();
                        headers
                            .insert(
                                tonic::Status::GRPC_STATUS,
                                (tonic::Code::Unimplemented as i32).into(),
                            );
                        headers
                            .insert(
                                http::header::CONTENT_TYPE,
                                tonic::metadata::GRPC_CONTENT_TYPE,
                            );
                        Ok(response)
                    })
                }
            }
        }
    }
    impl<T> Clone for InjectiveTcDerivativesRpcServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    /// Generated gRPC service name
    pub const SERVICE_NAME: &str = "injective_tc_derivatives_rpc.InjectiveTCDerivativesRPC";
    impl<T> tonic::server::NamedService for InjectiveTcDerivativesRpcServer<T> {
        const NAME: &'static str = SERVICE_NAME;
    }
}

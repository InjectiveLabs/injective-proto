// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetReferrerDetailsRequest {
    /// Address of the referrer
    #[prost(string, tag="1")]
    pub referrer_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetReferrerDetailsResponse {
    /// List of invitees
    #[prost(message, repeated, tag="1")]
    pub invitees: ::prost::alloc::vec::Vec<ReferralInvitee>,
    /// Total commission earned
    #[prost(string, tag="2")]
    pub total_commission: ::prost::alloc::string::String,
    /// Total trading volume
    #[prost(string, tag="3")]
    pub total_trading_volume: ::prost::alloc::string::String,
    /// Referrer code
    #[prost(string, tag="4")]
    pub referrer_code: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ReferralInvitee {
    /// Address of the invitee
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    /// Commission earned from this invitee
    #[prost(string, tag="2")]
    pub commission: ::prost::alloc::string::String,
    /// Trading volume of this invitee
    #[prost(string, tag="3")]
    pub trading_volume: ::prost::alloc::string::String,
    /// Join date in ISO 8601 format
    #[prost(string, tag="4")]
    pub join_date: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetInviteeDetailsRequest {
    /// Address of the invitee
    #[prost(string, tag="1")]
    pub invitee_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetInviteeDetailsResponse {
    /// Address of the referrer
    #[prost(string, tag="1")]
    pub referrer: ::prost::alloc::string::String,
    /// Referral code used
    #[prost(string, tag="2")]
    pub used_code: ::prost::alloc::string::String,
    /// Total trading volume
    #[prost(string, tag="3")]
    pub trading_volume: ::prost::alloc::string::String,
    /// Join date in ISO 8601 format
    #[prost(string, tag="4")]
    pub joined_at: ::prost::alloc::string::String,
    /// Whether the referral is still active
    #[prost(bool, tag="5")]
    pub active: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetReferrerByCodeRequest {
    /// Referral code to look up
    #[prost(string, tag="1")]
    pub referral_code: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetReferrerByCodeResponse {
    /// Address of the referrer
    #[prost(string, tag="1")]
    pub referrer_address: ::prost::alloc::string::String,
}
include!("injective_referral_rpc.tonic.rs");
// @@protoc_insertion_point(module)

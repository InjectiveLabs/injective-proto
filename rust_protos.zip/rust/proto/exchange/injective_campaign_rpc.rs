// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RankingRequest {
    /// Campaign ID
    #[prost(string, tag="1")]
    pub campaign_id: ::prost::alloc::string::String,
    /// MarketId of the campaign
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Account address
    #[prost(string, tag="3")]
    pub account_address: ::prost::alloc::string::String,
    #[prost(sint32, tag="4")]
    pub limit: i32,
    #[prost(uint64, tag="5")]
    pub skip: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RankingResponse {
    /// The campaign information
    #[prost(message, optional, tag="1")]
    pub campaign: ::core::option::Option<Campaign>,
    /// The campaign users
    #[prost(message, repeated, tag="2")]
    pub users: ::prost::alloc::vec::Vec<CampaignUser>,
    #[prost(message, optional, tag="3")]
    pub paging: ::core::option::Option<Paging>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Campaign {
    #[prost(string, tag="1")]
    pub campaign_id: ::prost::alloc::string::String,
    /// MarketId of the trading strategy
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Total campaign score
    #[prost(string, tag="4")]
    pub total_score: ::prost::alloc::string::String,
    /// Last time the campaign score has been updated.
    #[prost(sint64, tag="5")]
    pub last_updated: i64,
    /// Campaign start date in UNIX millis.
    #[prost(sint64, tag="6")]
    pub start_date: i64,
    /// Campaign end date in UNIX millis.
    #[prost(sint64, tag="7")]
    pub end_date: i64,
    /// Whether the campaign rewards can be claimed.
    #[prost(bool, tag="8")]
    pub is_claimable: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CampaignUser {
    #[prost(string, tag="1")]
    pub campaign_id: ::prost::alloc::string::String,
    /// MarketId of the trading strategy
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// Account address
    #[prost(string, tag="3")]
    pub account_address: ::prost::alloc::string::String,
    /// Campaign score
    #[prost(string, tag="4")]
    pub score: ::prost::alloc::string::String,
    /// Whether the distribution contract has been updated with the latest score
    #[prost(bool, tag="5")]
    pub contract_updated: bool,
    /// Block height when the score has been updated.
    #[prost(sint64, tag="6")]
    pub block_height: i64,
    /// Block time timestamp in UNIX millis.
    #[prost(sint64, tag="7")]
    pub block_time: i64,
    /// Amount swapped but only count base denom of the market
    #[prost(string, tag="8")]
    pub purchased_amount: ::prost::alloc::string::String,
    /// True if this user is updated to be in Galxe Campain list, only eligible
    /// address are added
    #[prost(bool, tag="9")]
    pub galxe_updated: bool,
}
/// Paging defines the structure for required params for handling pagination
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Paging {
    /// total number of txs saved in database
    #[prost(sint64, tag="1")]
    pub total: i64,
    /// can be either block height or index num
    #[prost(sint32, tag="2")]
    pub from: i32,
    /// can be either block height or index num
    #[prost(sint32, tag="3")]
    pub to: i32,
    /// count entries by subaccount, serving some places on helix
    #[prost(sint64, tag="4")]
    pub count_by_subaccount: i64,
    /// array of tokens to navigate to the next pages
    #[prost(string, repeated, tag="5")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
include!("injective_campaign_rpc.tonic.rs");
// @@protoc_insertion_point(module)

// @generated
/// Generated client implementations.
pub mod injective_auction_rpc_client {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    #[derive(Debug, Clone)]
    pub struct InjectiveAuctionRpcClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl InjectiveAuctionRpcClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> InjectiveAuctionRpcClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::Body>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + std::marker::Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + std::marker::Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InjectiveAuctionRpcClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::Body>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::Body>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::Body>,
            >>::Error: Into<StdError> + std::marker::Send + std::marker::Sync,
        {
            InjectiveAuctionRpcClient::new(InterceptedService::new(inner, interceptor))
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        pub async fn auction_endpoint(
            &mut self,
            request: impl tonic::IntoRequest<super::AuctionEndpointRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionEndpointResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionEndpoint",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_auction_rpc.InjectiveAuctionRPC",
                        "AuctionEndpoint",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn auctions(
            &mut self,
            request: impl tonic::IntoRequest<super::AuctionsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionsResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_auction_rpc.InjectiveAuctionRPC/Auctions",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_auction_rpc.InjectiveAuctionRPC",
                        "Auctions",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn auctions_history_v2(
            &mut self,
            request: impl tonic::IntoRequest<super::AuctionsHistoryV2Request>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionsHistoryV2Response>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionsHistoryV2",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_auction_rpc.InjectiveAuctionRPC",
                        "AuctionsHistoryV2",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn auction_v2(
            &mut self,
            request: impl tonic::IntoRequest<super::AuctionV2Request>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionV2Response>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionV2",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_auction_rpc.InjectiveAuctionRPC",
                        "AuctionV2",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn account_auctions_v2(
            &mut self,
            request: impl tonic::IntoRequest<super::AccountAuctionsV2Request>,
        ) -> std::result::Result<
            tonic::Response<super::AccountAuctionsV2Response>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_auction_rpc.InjectiveAuctionRPC/AccountAuctionsV2",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_auction_rpc.InjectiveAuctionRPC",
                        "AccountAuctionsV2",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn auction_account_status(
            &mut self,
            request: impl tonic::IntoRequest<super::AuctionAccountStatusRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionAccountStatusResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionAccountStatus",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_auction_rpc.InjectiveAuctionRPC",
                        "AuctionAccountStatus",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn stream_bids(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamBidsRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamBidsResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_auction_rpc.InjectiveAuctionRPC/StreamBids",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_auction_rpc.InjectiveAuctionRPC",
                        "StreamBids",
                    ),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn inj_burnt_endpoint(
            &mut self,
            request: impl tonic::IntoRequest<super::InjBurntEndpointRequest>,
        ) -> std::result::Result<
            tonic::Response<super::InjBurntEndpointResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_auction_rpc.InjectiveAuctionRPC/InjBurntEndpoint",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_auction_rpc.InjectiveAuctionRPC",
                        "InjBurntEndpoint",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn auctions_stats(
            &mut self,
            request: impl tonic::IntoRequest<super::AuctionsStatsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionsStatsResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionsStats",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_auction_rpc.InjectiveAuctionRPC",
                        "AuctionsStats",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod injective_auction_rpc_server {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with InjectiveAuctionRpcServer.
    #[async_trait]
    pub trait InjectiveAuctionRpc: std::marker::Send + std::marker::Sync + 'static {
        async fn auction_endpoint(
            &self,
            request: tonic::Request<super::AuctionEndpointRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionEndpointResponse>,
            tonic::Status,
        >;
        async fn auctions(
            &self,
            request: tonic::Request<super::AuctionsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionsResponse>,
            tonic::Status,
        >;
        async fn auctions_history_v2(
            &self,
            request: tonic::Request<super::AuctionsHistoryV2Request>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionsHistoryV2Response>,
            tonic::Status,
        >;
        async fn auction_v2(
            &self,
            request: tonic::Request<super::AuctionV2Request>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionV2Response>,
            tonic::Status,
        >;
        async fn account_auctions_v2(
            &self,
            request: tonic::Request<super::AccountAuctionsV2Request>,
        ) -> std::result::Result<
            tonic::Response<super::AccountAuctionsV2Response>,
            tonic::Status,
        >;
        async fn auction_account_status(
            &self,
            request: tonic::Request<super::AuctionAccountStatusRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionAccountStatusResponse>,
            tonic::Status,
        >;
        /// Server streaming response type for the StreamBids method.
        type StreamBidsStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<super::StreamBidsResponse, tonic::Status>,
            >
            + std::marker::Send
            + 'static;
        async fn stream_bids(
            &self,
            request: tonic::Request<super::StreamBidsRequest>,
        ) -> std::result::Result<tonic::Response<Self::StreamBidsStream>, tonic::Status>;
        async fn inj_burnt_endpoint(
            &self,
            request: tonic::Request<super::InjBurntEndpointRequest>,
        ) -> std::result::Result<
            tonic::Response<super::InjBurntEndpointResponse>,
            tonic::Status,
        >;
        async fn auctions_stats(
            &self,
            request: tonic::Request<super::AuctionsStatsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AuctionsStatsResponse>,
            tonic::Status,
        >;
    }
    #[derive(Debug)]
    pub struct InjectiveAuctionRpcServer<T> {
        inner: Arc<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    impl<T> InjectiveAuctionRpcServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>> for InjectiveAuctionRpcServer<T>
    where
        T: InjectiveAuctionRpc,
        B: Body + std::marker::Send + 'static,
        B::Error: Into<StdError> + std::marker::Send + 'static,
    {
        type Response = http::Response<tonic::body::Body>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            match req.uri().path() {
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionEndpoint" => {
                    #[allow(non_camel_case_types)]
                    struct AuctionEndpointSvc<T: InjectiveAuctionRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveAuctionRpc,
                    > tonic::server::UnaryService<super::AuctionEndpointRequest>
                    for AuctionEndpointSvc<T> {
                        type Response = super::AuctionEndpointResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::AuctionEndpointRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveAuctionRpc>::auction_endpoint(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = AuctionEndpointSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_auction_rpc.InjectiveAuctionRPC/Auctions" => {
                    #[allow(non_camel_case_types)]
                    struct AuctionsSvc<T: InjectiveAuctionRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveAuctionRpc,
                    > tonic::server::UnaryService<super::AuctionsRequest>
                    for AuctionsSvc<T> {
                        type Response = super::AuctionsResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::AuctionsRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveAuctionRpc>::auctions(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = AuctionsSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionsHistoryV2" => {
                    #[allow(non_camel_case_types)]
                    struct AuctionsHistoryV2Svc<T: InjectiveAuctionRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveAuctionRpc,
                    > tonic::server::UnaryService<super::AuctionsHistoryV2Request>
                    for AuctionsHistoryV2Svc<T> {
                        type Response = super::AuctionsHistoryV2Response;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::AuctionsHistoryV2Request>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveAuctionRpc>::auctions_history_v2(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = AuctionsHistoryV2Svc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionV2" => {
                    #[allow(non_camel_case_types)]
                    struct AuctionV2Svc<T: InjectiveAuctionRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveAuctionRpc,
                    > tonic::server::UnaryService<super::AuctionV2Request>
                    for AuctionV2Svc<T> {
                        type Response = super::AuctionV2Response;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::AuctionV2Request>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveAuctionRpc>::auction_v2(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = AuctionV2Svc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_auction_rpc.InjectiveAuctionRPC/AccountAuctionsV2" => {
                    #[allow(non_camel_case_types)]
                    struct AccountAuctionsV2Svc<T: InjectiveAuctionRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveAuctionRpc,
                    > tonic::server::UnaryService<super::AccountAuctionsV2Request>
                    for AccountAuctionsV2Svc<T> {
                        type Response = super::AccountAuctionsV2Response;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::AccountAuctionsV2Request>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveAuctionRpc>::account_auctions_v2(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = AccountAuctionsV2Svc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionAccountStatus" => {
                    #[allow(non_camel_case_types)]
                    struct AuctionAccountStatusSvc<T: InjectiveAuctionRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveAuctionRpc,
                    > tonic::server::UnaryService<super::AuctionAccountStatusRequest>
                    for AuctionAccountStatusSvc<T> {
                        type Response = super::AuctionAccountStatusResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::AuctionAccountStatusRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveAuctionRpc>::auction_account_status(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = AuctionAccountStatusSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_auction_rpc.InjectiveAuctionRPC/StreamBids" => {
                    #[allow(non_camel_case_types)]
                    struct StreamBidsSvc<T: InjectiveAuctionRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveAuctionRpc,
                    > tonic::server::ServerStreamingService<super::StreamBidsRequest>
                    for StreamBidsSvc<T> {
                        type Response = super::StreamBidsResponse;
                        type ResponseStream = T::StreamBidsStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamBidsRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveAuctionRpc>::stream_bids(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = StreamBidsSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_auction_rpc.InjectiveAuctionRPC/InjBurntEndpoint" => {
                    #[allow(non_camel_case_types)]
                    struct InjBurntEndpointSvc<T: InjectiveAuctionRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveAuctionRpc,
                    > tonic::server::UnaryService<super::InjBurntEndpointRequest>
                    for InjBurntEndpointSvc<T> {
                        type Response = super::InjBurntEndpointResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::InjBurntEndpointRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveAuctionRpc>::inj_burnt_endpoint(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = InjBurntEndpointSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_auction_rpc.InjectiveAuctionRPC/AuctionsStats" => {
                    #[allow(non_camel_case_types)]
                    struct AuctionsStatsSvc<T: InjectiveAuctionRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveAuctionRpc,
                    > tonic::server::UnaryService<super::AuctionsStatsRequest>
                    for AuctionsStatsSvc<T> {
                        type Response = super::AuctionsStatsResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::AuctionsStatsRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveAuctionRpc>::auctions_stats(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = AuctionsStatsSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        let mut response = http::Response::new(
                            tonic::body::Body::default(),
                        );
                        let headers = response.headers_mut();
                        headers
                            .insert(
                                tonic::Status::GRPC_STATUS,
                                (tonic::Code::Unimplemented as i32).into(),
                            );
                        headers
                            .insert(
                                http::header::CONTENT_TYPE,
                                tonic::metadata::GRPC_CONTENT_TYPE,
                            );
                        Ok(response)
                    })
                }
            }
        }
    }
    impl<T> Clone for InjectiveAuctionRpcServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    /// Generated gRPC service name
    pub const SERVICE_NAME: &str = "injective_auction_rpc.InjectiveAuctionRPC";
    impl<T> tonic::server::NamedService for InjectiveAuctionRpcServer<T> {
        const NAME: &'static str = SERVICE_NAME;
    }
}

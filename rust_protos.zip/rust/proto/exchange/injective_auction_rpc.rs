// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionEndpointRequest {
    /// The auction round number. -1 for latest.
    #[prost(sint64, tag="1")]
    pub round: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionEndpointResponse {
    /// The auction
    #[prost(message, optional, tag="1")]
    pub auction: ::core::option::Option<Auction>,
    /// Bids of the auction
    #[prost(message, repeated, tag="2")]
    pub bids: ::prost::alloc::vec::Vec<Bid>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Auction {
    /// Account address of the auction winner
    #[prost(string, tag="1")]
    pub winner: ::prost::alloc::string::String,
    /// Coins in the basket
    #[prost(message, repeated, tag="2")]
    pub basket: ::prost::alloc::vec::Vec<Coin>,
    #[prost(string, tag="3")]
    pub winning_bid_amount: ::prost::alloc::string::String,
    #[prost(uint64, tag="4")]
    pub round: u64,
    /// Auction end timestamp in UNIX millis.
    #[prost(sint64, tag="5")]
    pub end_timestamp: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="6")]
    pub updated_at: i64,
    #[prost(message, optional, tag="7")]
    pub contract: ::core::option::Option<AuctionContract>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Coin {
    /// Denom of the coin
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub usd_value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionContract {
    #[prost(uint64, tag="1")]
    pub id: u64,
    /// Bid target of the auction
    #[prost(string, tag="2")]
    pub bid_target: ::prost::alloc::string::String,
    /// Total slots of the auction
    #[prost(uint64, tag="3")]
    pub current_slots: u64,
    /// Total slots of the auction
    #[prost(uint64, tag="4")]
    pub total_slots: u64,
    /// Max user allocation of the auction
    #[prost(string, tag="5")]
    pub max_user_allocation: ::prost::alloc::string::String,
    /// Total committed amount of the auction
    #[prost(string, tag="6")]
    pub total_committed: ::prost::alloc::string::String,
    /// Whitelist addresses for the auction
    #[prost(string, repeated, tag="7")]
    pub whitelist_addresses: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// Auction start timestamp in UNIX millis.
    #[prost(uint64, tag="8")]
    pub start_timestamp: u64,
    /// Auction end timestamp in UNIX millis.
    #[prost(uint64, tag="9")]
    pub end_timestamp: u64,
    /// Max round allocation of the auction
    #[prost(string, tag="10")]
    pub max_round_allocation: ::prost::alloc::string::String,
    /// Whether any bid has been placed in the auction.
    #[prost(bool, tag="11")]
    pub is_bid_placed: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Bid {
    /// Account address of the bidder
    #[prost(string, tag="1")]
    pub bidder: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
    /// Bid timestamp in UNIX millis.
    #[prost(sint64, tag="3")]
    pub timestamp: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionsRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionsResponse {
    /// The historical auctions
    #[prost(message, repeated, tag="1")]
    pub auctions: ::prost::alloc::vec::Vec<Auction>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionsHistoryV2Request {
    #[prost(sint32, tag="1")]
    pub per_page: i32,
    /// Pagination token
    #[prost(string, tag="2")]
    pub token: ::prost::alloc::string::String,
    /// The ending timestamp in UNIX milliseconds to filter the auctions
    #[prost(sint64, tag="3")]
    pub end_time: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionsHistoryV2Response {
    /// The historical auctions
    #[prost(message, repeated, tag="1")]
    pub auctions: ::prost::alloc::vec::Vec<AuctionV2Result>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionV2Result {
    /// Account address of the auction winner
    #[prost(string, tag="1")]
    pub winner: ::prost::alloc::string::String,
    /// Coins in the basket
    #[prost(message, repeated, tag="2")]
    pub basket: ::prost::alloc::vec::Vec<CoinPrices>,
    #[prost(string, tag="3")]
    pub winning_bid_amount: ::prost::alloc::string::String,
    #[prost(uint64, tag="4")]
    pub round: u64,
    /// Auction end timestamp in UNIX millis.
    #[prost(sint64, tag="5")]
    pub end_timestamp: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="6")]
    pub updated_at: i64,
    #[prost(message, optional, tag="7")]
    pub contract: ::core::option::Option<AuctionContract>,
    #[prost(string, tag="8")]
    pub winning_bid_amount_usd: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CoinPrices {
    /// Denom of the coin
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
    /// Map of historical prices.
    #[prost(map="string, string", tag="3")]
    pub prices: ::std::collections::HashMap<::prost::alloc::string::String, ::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionV2Request {
    /// The auction round number.
    #[prost(sint64, tag="1")]
    pub round: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionV2Response {
    /// Account address of the auction winner
    #[prost(string, tag="1")]
    pub winner: ::prost::alloc::string::String,
    /// Coins in the basket
    #[prost(message, repeated, tag="2")]
    pub basket: ::prost::alloc::vec::Vec<CoinPrices>,
    #[prost(string, tag="3")]
    pub winning_bid_amount: ::prost::alloc::string::String,
    #[prost(uint64, tag="4")]
    pub round: u64,
    /// Auction end timestamp in UNIX millis.
    #[prost(sint64, tag="5")]
    pub end_timestamp: i64,
    /// UpdatedAt timestamp in UNIX millis.
    #[prost(sint64, tag="6")]
    pub updated_at: i64,
    #[prost(message, optional, tag="7")]
    pub contract: ::core::option::Option<AuctionContract>,
    #[prost(string, tag="8")]
    pub winning_bid_amount_usd: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AccountAuctionsV2Request {
    /// Address of account
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    #[prost(sint32, tag="2")]
    pub per_page: i32,
    /// Pagination token
    #[prost(string, tag="3")]
    pub token: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AccountAuctionsV2Response {
    /// The historical auctions
    #[prost(message, repeated, tag="1")]
    pub auctions: ::prost::alloc::vec::Vec<AccountAuctionV2>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// Total number of auctions
    #[prost(sint64, tag="3")]
    pub total: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AccountAuctionV2 {
    #[prost(uint64, tag="1")]
    pub id: u64,
    #[prost(uint64, tag="2")]
    pub round: u64,
    #[prost(string, tag="3")]
    pub amount_deposited: ::prost::alloc::string::String,
    /// Whether the auction rewards can be claimed.
    #[prost(bool, tag="4")]
    pub is_claimable: bool,
    #[prost(message, repeated, tag="5")]
    pub claimed_assets: ::prost::alloc::vec::Vec<CoinPrices>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionAccountStatusRequest {
    /// The auction round number
    #[prost(sint64, tag="1")]
    pub round: i64,
    /// Address of account
    #[prost(string, tag="2")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionAccountStatusResponse {
    /// The allowlist status of the account
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamBidsRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamBidsResponse {
    /// Account address of the bidder
    #[prost(string, tag="1")]
    pub bidder: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub bid_amount: ::prost::alloc::string::String,
    #[prost(uint64, tag="3")]
    pub round: u64,
    /// Operation timestamp in UNIX millis.
    #[prost(sint64, tag="4")]
    pub timestamp: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct InjBurntEndpointRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct InjBurntEndpointResponse {
    #[prost(string, tag="1")]
    pub total_inj_burnt: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionsStatsRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct AuctionsStatsResponse {
    /// Total cumulative amount of INJ burnt in auctions
    #[prost(string, tag="1")]
    pub total_burnt: ::prost::alloc::string::String,
    /// Total cumulative historical basket value in USD of all auctions
    #[prost(string, tag="2")]
    pub total_usd_value: ::prost::alloc::string::String,
}
include!("injective_auction_rpc.tonic.rs");
// @@protoc_insertion_point(module)

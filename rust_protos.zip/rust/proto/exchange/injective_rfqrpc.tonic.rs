// @generated
/// Generated client implementations.
pub mod injective_rfqrpc_client {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    #[derive(Debug, Clone)]
    pub struct InjectiveRfqrpcClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl InjectiveRfqrpcClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> InjectiveRfqrpcClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::BoxBody>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InjectiveRfqrpcClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::BoxBody>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
            >>::Error: Into<StdError> + Send + Sync,
        {
            InjectiveRfqrpcClient::new(InterceptedService::new(inner, interceptor))
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        pub async fn request(
            &mut self,
            request: impl tonic::IntoRequest<super::RequestRequest>,
        ) -> std::result::Result<
            tonic::Response<super::RequestResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/Request",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("injective_rfqrpc.InjectiveRFQRPC", "Request"));
            self.inner.unary(req, path, codec).await
        }
        pub async fn stream_request(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamRequestRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamRequestResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/StreamRequest",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("injective_rfqrpc.InjectiveRFQRPC", "StreamRequest"),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn quote(
            &mut self,
            request: impl tonic::IntoRequest<super::QuoteRequest>,
        ) -> std::result::Result<tonic::Response<super::QuoteResponse>, tonic::Status> {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/Quote",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("injective_rfqrpc.InjectiveRFQRPC", "Quote"));
            self.inner.unary(req, path, codec).await
        }
        pub async fn stream_quote(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamQuoteRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamQuoteResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/StreamQuote",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("injective_rfqrpc.InjectiveRFQRPC", "StreamQuote"),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn get_open_requests(
            &mut self,
            request: impl tonic::IntoRequest<super::GetOpenRequestsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetOpenRequestsResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/GetOpenRequests",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_rfqrpc.InjectiveRFQRPC",
                        "GetOpenRequests",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn get_pending_quotes(
            &mut self,
            request: impl tonic::IntoRequest<super::GetPendingQuotesRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetPendingQuotesResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/GetPendingQuotes",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_rfqrpc.InjectiveRFQRPC",
                        "GetPendingQuotes",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn list_settlement(
            &mut self,
            request: impl tonic::IntoRequest<super::ListSettlementRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListSettlementResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/ListSettlement",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("injective_rfqrpc.InjectiveRFQRPC", "ListSettlement"),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn stream_settlement(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamSettlementRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamSettlementResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/StreamSettlement",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_rfqrpc.InjectiveRFQRPC",
                        "StreamSettlement",
                    ),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn taker_stream(
            &mut self,
            request: impl tonic::IntoStreamingRequest<
                Message = super::TakerStreamStreamingRequest,
            >,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::TakerStreamResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/TakerStream",
            );
            let mut req = request.into_streaming_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("injective_rfqrpc.InjectiveRFQRPC", "TakerStream"),
                );
            self.inner.streaming(req, path, codec).await
        }
        pub async fn maker_stream(
            &mut self,
            request: impl tonic::IntoStreamingRequest<
                Message = super::MakerStreamStreamingRequest,
            >,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::MakerStreamResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfqrpc.InjectiveRFQRPC/MakerStream",
            );
            let mut req = request.into_streaming_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("injective_rfqrpc.InjectiveRFQRPC", "MakerStream"),
                );
            self.inner.streaming(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod injective_rfqrpc_server {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with InjectiveRfqrpcServer.
    #[async_trait]
    pub trait InjectiveRfqrpc: Send + Sync + 'static {
        async fn request(
            &self,
            request: tonic::Request<super::RequestRequest>,
        ) -> std::result::Result<tonic::Response<super::RequestResponse>, tonic::Status>;
        /// Server streaming response type for the StreamRequest method.
        type StreamRequestStream: futures_core::Stream<
                Item = std::result::Result<super::StreamRequestResponse, tonic::Status>,
            >
            + Send
            + 'static;
        async fn stream_request(
            &self,
            request: tonic::Request<super::StreamRequestRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamRequestStream>,
            tonic::Status,
        >;
        async fn quote(
            &self,
            request: tonic::Request<super::QuoteRequest>,
        ) -> std::result::Result<tonic::Response<super::QuoteResponse>, tonic::Status>;
        /// Server streaming response type for the StreamQuote method.
        type StreamQuoteStream: futures_core::Stream<
                Item = std::result::Result<super::StreamQuoteResponse, tonic::Status>,
            >
            + Send
            + 'static;
        async fn stream_quote(
            &self,
            request: tonic::Request<super::StreamQuoteRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamQuoteStream>,
            tonic::Status,
        >;
        async fn get_open_requests(
            &self,
            request: tonic::Request<super::GetOpenRequestsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetOpenRequestsResponse>,
            tonic::Status,
        >;
        async fn get_pending_quotes(
            &self,
            request: tonic::Request<super::GetPendingQuotesRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetPendingQuotesResponse>,
            tonic::Status,
        >;
        async fn list_settlement(
            &self,
            request: tonic::Request<super::ListSettlementRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListSettlementResponse>,
            tonic::Status,
        >;
        /// Server streaming response type for the StreamSettlement method.
        type StreamSettlementStream: futures_core::Stream<
                Item = std::result::Result<
                    super::StreamSettlementResponse,
                    tonic::Status,
                >,
            >
            + Send
            + 'static;
        async fn stream_settlement(
            &self,
            request: tonic::Request<super::StreamSettlementRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamSettlementStream>,
            tonic::Status,
        >;
        /// Server streaming response type for the TakerStream method.
        type TakerStreamStream: futures_core::Stream<
                Item = std::result::Result<super::TakerStreamResponse, tonic::Status>,
            >
            + Send
            + 'static;
        async fn taker_stream(
            &self,
            request: tonic::Request<tonic::Streaming<super::TakerStreamStreamingRequest>>,
        ) -> std::result::Result<
            tonic::Response<Self::TakerStreamStream>,
            tonic::Status,
        >;
        /// Server streaming response type for the MakerStream method.
        type MakerStreamStream: futures_core::Stream<
                Item = std::result::Result<super::MakerStreamResponse, tonic::Status>,
            >
            + Send
            + 'static;
        async fn maker_stream(
            &self,
            request: tonic::Request<tonic::Streaming<super::MakerStreamStreamingRequest>>,
        ) -> std::result::Result<
            tonic::Response<Self::MakerStreamStream>,
            tonic::Status,
        >;
    }
    #[derive(Debug)]
    pub struct InjectiveRfqrpcServer<T: InjectiveRfqrpc> {
        inner: _Inner<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    struct _Inner<T>(Arc<T>);
    impl<T: InjectiveRfqrpc> InjectiveRfqrpcServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            let inner = _Inner(inner);
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>> for InjectiveRfqrpcServer<T>
    where
        T: InjectiveRfqrpc,
        B: Body + Send + 'static,
        B::Error: Into<StdError> + Send + 'static,
    {
        type Response = http::Response<tonic::body::BoxBody>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            let inner = self.inner.clone();
            match req.uri().path() {
                "/injective_rfqrpc.InjectiveRFQRPC/Request" => {
                    #[allow(non_camel_case_types)]
                    struct RequestSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::UnaryService<super::RequestRequest>
                    for RequestSvc<T> {
                        type Response = super::RequestResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::RequestRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move { (*inner).request(request).await };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = RequestSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfqrpc.InjectiveRFQRPC/StreamRequest" => {
                    #[allow(non_camel_case_types)]
                    struct StreamRequestSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::ServerStreamingService<super::StreamRequestRequest>
                    for StreamRequestSvc<T> {
                        type Response = super::StreamRequestResponse;
                        type ResponseStream = T::StreamRequestStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamRequestRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).stream_request(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = StreamRequestSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfqrpc.InjectiveRFQRPC/Quote" => {
                    #[allow(non_camel_case_types)]
                    struct QuoteSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::UnaryService<super::QuoteRequest> for QuoteSvc<T> {
                        type Response = super::QuoteResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::QuoteRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move { (*inner).quote(request).await };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = QuoteSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfqrpc.InjectiveRFQRPC/StreamQuote" => {
                    #[allow(non_camel_case_types)]
                    struct StreamQuoteSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::ServerStreamingService<super::StreamQuoteRequest>
                    for StreamQuoteSvc<T> {
                        type Response = super::StreamQuoteResponse;
                        type ResponseStream = T::StreamQuoteStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamQuoteRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).stream_quote(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = StreamQuoteSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfqrpc.InjectiveRFQRPC/GetOpenRequests" => {
                    #[allow(non_camel_case_types)]
                    struct GetOpenRequestsSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::UnaryService<super::GetOpenRequestsRequest>
                    for GetOpenRequestsSvc<T> {
                        type Response = super::GetOpenRequestsResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetOpenRequestsRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_open_requests(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetOpenRequestsSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfqrpc.InjectiveRFQRPC/GetPendingQuotes" => {
                    #[allow(non_camel_case_types)]
                    struct GetPendingQuotesSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::UnaryService<super::GetPendingQuotesRequest>
                    for GetPendingQuotesSvc<T> {
                        type Response = super::GetPendingQuotesResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetPendingQuotesRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).get_pending_quotes(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetPendingQuotesSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfqrpc.InjectiveRFQRPC/ListSettlement" => {
                    #[allow(non_camel_case_types)]
                    struct ListSettlementSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::UnaryService<super::ListSettlementRequest>
                    for ListSettlementSvc<T> {
                        type Response = super::ListSettlementResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ListSettlementRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).list_settlement(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ListSettlementSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfqrpc.InjectiveRFQRPC/StreamSettlement" => {
                    #[allow(non_camel_case_types)]
                    struct StreamSettlementSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::ServerStreamingService<
                        super::StreamSettlementRequest,
                    > for StreamSettlementSvc<T> {
                        type Response = super::StreamSettlementResponse;
                        type ResponseStream = T::StreamSettlementStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamSettlementRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).stream_settlement(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = StreamSettlementSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfqrpc.InjectiveRFQRPC/TakerStream" => {
                    #[allow(non_camel_case_types)]
                    struct TakerStreamSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::StreamingService<super::TakerStreamStreamingRequest>
                    for TakerStreamSvc<T> {
                        type Response = super::TakerStreamResponse;
                        type ResponseStream = T::TakerStreamStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                tonic::Streaming<super::TakerStreamStreamingRequest>,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).taker_stream(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = TakerStreamSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfqrpc.InjectiveRFQRPC/MakerStream" => {
                    #[allow(non_camel_case_types)]
                    struct MakerStreamSvc<T: InjectiveRfqrpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqrpc,
                    > tonic::server::StreamingService<super::MakerStreamStreamingRequest>
                    for MakerStreamSvc<T> {
                        type Response = super::MakerStreamResponse;
                        type ResponseStream = T::MakerStreamStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                tonic::Streaming<super::MakerStreamStreamingRequest>,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                (*inner).maker_stream(request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = MakerStreamSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        Ok(
                            http::Response::builder()
                                .status(200)
                                .header("grpc-status", "12")
                                .header("content-type", "application/grpc")
                                .body(empty_body())
                                .unwrap(),
                        )
                    })
                }
            }
        }
    }
    impl<T: InjectiveRfqrpc> Clone for InjectiveRfqrpcServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    impl<T: InjectiveRfqrpc> Clone for _Inner<T> {
        fn clone(&self) -> Self {
            Self(Arc::clone(&self.0))
        }
    }
    impl<T: std::fmt::Debug> std::fmt::Debug for _Inner<T> {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(f, "{:?}", self.0)
        }
    }
    impl<T: InjectiveRfqrpc> tonic::server::NamedService for InjectiveRfqrpcServer<T> {
        const NAME: &'static str = "injective_rfqrpc.InjectiveRFQRPC";
    }
}

// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrdersHistoryRequest {
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// order side filter
    #[prost(string, tag="2")]
    pub direction: ::prost::alloc::string::String,
    /// filter by account address
    #[prost(string, tag="3")]
    pub account_address: ::prost::alloc::string::String,
    /// Number of results per page
    #[prost(sint32, tag="4")]
    pub per_page: i32,
    /// Pagination token
    #[prost(string, tag="5")]
    pub token: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrdersHistoryResponse {
    /// List of TC order history entries
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<TcDerivativeOrderHistoryType>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// TC order history combining settlement request with on-chain order data
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TcDerivativeOrderHistoryType {
    /// Hash of the order
    #[prost(string, tag="1")]
    pub order_hash: ::prost::alloc::string::String,
    /// Derivative Market ID is keccak265(baseDenom + quoteDenom)
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// active state of the order
    #[prost(bool, tag="3")]
    pub is_active: bool,
    /// The subaccountId that this order belongs to
    #[prost(string, tag="4")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// The execution type
    #[prost(string, tag="5")]
    pub execution_type: ::prost::alloc::string::String,
    /// The side of the order
    #[prost(string, tag="6")]
    pub order_type: ::prost::alloc::string::String,
    /// Price of the order
    #[prost(string, tag="7")]
    pub price: ::prost::alloc::string::String,
    /// Trigger price
    #[prost(string, tag="8")]
    pub trigger_price: ::prost::alloc::string::String,
    /// Quantity of the order
    #[prost(string, tag="9")]
    pub quantity: ::prost::alloc::string::String,
    /// Filled amount
    #[prost(string, tag="10")]
    pub filled_quantity: ::prost::alloc::string::String,
    /// Order state
    #[prost(string, tag="11")]
    pub state: ::prost::alloc::string::String,
    /// Order committed timestamp in UNIX millis.
    #[prost(sint64, tag="12")]
    pub created_at: i64,
    /// Order updated timestamp in UNIX millis.
    #[prost(sint64, tag="13")]
    pub updated_at: i64,
    /// True if an order is reduce only
    #[prost(bool, tag="14")]
    pub is_reduce_only: bool,
    /// Order direction (order side)
    #[prost(string, tag="15")]
    pub direction: ::prost::alloc::string::String,
    /// True if this is conditional order, otherwise false
    #[prost(bool, tag="16")]
    pub is_conditional: bool,
    /// Trigger timestamp in unix milli
    #[prost(uint64, tag="17")]
    pub trigger_at: u64,
    /// Order hash placed when this triggers
    #[prost(string, tag="18")]
    pub placed_order_hash: ::prost::alloc::string::String,
    /// Order's margin
    #[prost(string, tag="19")]
    pub margin: ::prost::alloc::string::String,
    /// Transaction Hash where order is created. Not all orders have this field
    #[prost(string, tag="20")]
    pub tx_hash: ::prost::alloc::string::String,
    /// Custom client order ID
    #[prost(string, tag="21")]
    pub cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamOrdersHistoryRequest {
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// filter by account address
    #[prost(string, tag="2")]
    pub account_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamOrdersHistoryResponse {
    /// Updated TC order history entry
    #[prost(message, optional, tag="1")]
    pub order: ::core::option::Option<TcDerivativeOrderHistoryType>,
    /// Order update type
    #[prost(string, tag="2")]
    pub operation_type: ::prost::alloc::string::String,
    /// Operation timestamp in UNIX millis
    #[prost(sint64, tag="3")]
    pub timestamp: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrdersRequest {
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// order side filter
    #[prost(string, tag="2")]
    pub direction: ::prost::alloc::string::String,
    /// filter by account address
    #[prost(string, tag="3")]
    pub account_address: ::prost::alloc::string::String,
    /// Number of results per page
    #[prost(sint32, tag="4")]
    pub per_page: i32,
    /// Pagination token
    #[prost(string, tag="5")]
    pub token: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OrdersResponse {
    /// List of derivative limit orders
    #[prost(message, repeated, tag="1")]
    pub orders: ::prost::alloc::vec::Vec<DerivativeLimitOrder>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeLimitOrder {
    /// Hash of the order
    #[prost(string, tag="1")]
    pub order_hash: ::prost::alloc::string::String,
    /// The side of the order
    #[prost(string, tag="2")]
    pub order_side: ::prost::alloc::string::String,
    /// Derivative Market ID
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// The subaccountId that this order belongs to
    #[prost(string, tag="4")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// True if the order is a reduce-only order
    #[prost(bool, tag="5")]
    pub is_reduce_only: bool,
    /// Margin of the order
    #[prost(string, tag="6")]
    pub margin: ::prost::alloc::string::String,
    /// Price of the order
    #[prost(string, tag="7")]
    pub price: ::prost::alloc::string::String,
    /// Quantity of the order
    #[prost(string, tag="8")]
    pub quantity: ::prost::alloc::string::String,
    /// The amount of the quantity remaining unfilled
    #[prost(string, tag="9")]
    pub unfilled_quantity: ::prost::alloc::string::String,
    /// Trigger price is the trigger price used by stop/take orders
    #[prost(string, tag="10")]
    pub trigger_price: ::prost::alloc::string::String,
    /// Fee recipient address
    #[prost(string, tag="11")]
    pub fee_recipient: ::prost::alloc::string::String,
    /// Order state
    #[prost(string, tag="12")]
    pub state: ::prost::alloc::string::String,
    /// Order committed timestamp in UNIX millis.
    #[prost(sint64, tag="13")]
    pub created_at: i64,
    /// Order updated timestamp in UNIX millis.
    #[prost(sint64, tag="14")]
    pub updated_at: i64,
    /// Order number of subaccount
    #[prost(sint64, tag="15")]
    pub order_number: i64,
    /// Order type
    #[prost(string, tag="16")]
    pub order_type: ::prost::alloc::string::String,
    /// Order type
    #[prost(bool, tag="17")]
    pub is_conditional: bool,
    /// Trigger timestamp, only exists for conditional orders
    #[prost(uint64, tag="18")]
    pub trigger_at: u64,
    /// OrderHash of order that is triggered by this conditional order
    #[prost(string, tag="19")]
    pub placed_order_hash: ::prost::alloc::string::String,
    /// Execution type of conditional order
    #[prost(string, tag="20")]
    pub execution_type: ::prost::alloc::string::String,
    /// Transaction Hash where order is created. Not all orders have this field
    #[prost(string, tag="21")]
    pub tx_hash: ::prost::alloc::string::String,
    /// Custom client order ID
    #[prost(string, tag="22")]
    pub cid: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamOrdersRequest {
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// filter by account address
    #[prost(string, tag="2")]
    pub account_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamOrdersResponse {
    /// Updated derivative limit order
    #[prost(message, optional, tag="1")]
    pub order: ::core::option::Option<DerivativeLimitOrder>,
    /// Order update type
    #[prost(string, tag="2")]
    pub operation_type: ::prost::alloc::string::String,
    /// Operation timestamp in UNIX millis
    #[prost(sint64, tag="3")]
    pub timestamp: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradesRequest {
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// Filter by direction the trade
    #[prost(string, tag="2")]
    pub direction: ::prost::alloc::string::String,
    /// filter by account address
    #[prost(string, tag="3")]
    pub account_address: ::prost::alloc::string::String,
    /// Number of results per page
    #[prost(sint32, tag="4")]
    pub per_page: i32,
    /// Pagination token
    #[prost(string, tag="5")]
    pub token: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct TradesResponse {
    /// Trades of TC Derivative Markets
    #[prost(message, repeated, tag="1")]
    pub trades: ::prost::alloc::vec::Vec<DerivativeTrade>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativeTrade {
    /// Order hash.
    #[prost(string, tag="1")]
    pub order_hash: ::prost::alloc::string::String,
    /// The subaccountId that executed the trade
    #[prost(string, tag="2")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// The ID of the market that this trade is in
    #[prost(string, tag="3")]
    pub market_id: ::prost::alloc::string::String,
    /// The execution type of the trade
    #[prost(string, tag="4")]
    pub trade_execution_type: ::prost::alloc::string::String,
    /// True if the trade is a liquidation
    #[prost(bool, tag="5")]
    pub is_liquidation: bool,
    /// Position Delta from the trade
    #[prost(message, optional, tag="6")]
    pub position_delta: ::core::option::Option<PositionDelta>,
    /// The payout associated with the trade
    #[prost(string, tag="7")]
    pub payout: ::prost::alloc::string::String,
    /// The fee associated with the trade
    #[prost(string, tag="8")]
    pub fee: ::prost::alloc::string::String,
    /// Timestamp of trade execution in UNIX millis
    #[prost(sint64, tag="9")]
    pub executed_at: i64,
    /// Fee recipient address
    #[prost(string, tag="10")]
    pub fee_recipient: ::prost::alloc::string::String,
    /// A unique string that helps differentiate between trades
    #[prost(string, tag="11")]
    pub trade_id: ::prost::alloc::string::String,
    /// Trade's execution side, maker,taker,n/a (n/a = not applicable)
    #[prost(string, tag="12")]
    pub execution_side: ::prost::alloc::string::String,
    /// Custom client order ID
    #[prost(string, tag="13")]
    pub cid: ::prost::alloc::string::String,
    /// Profit and loss of the trade
    #[prost(string, tag="14")]
    pub pnl: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PositionDelta {
    /// The direction the trade
    #[prost(string, tag="1")]
    pub trade_direction: ::prost::alloc::string::String,
    /// Execution Price of the trade.
    #[prost(string, tag="2")]
    pub execution_price: ::prost::alloc::string::String,
    /// Execution Quantity of the trade.
    #[prost(string, tag="3")]
    pub execution_quantity: ::prost::alloc::string::String,
    /// Execution Margin of the trade.
    #[prost(string, tag="4")]
    pub execution_margin: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamTradesRequest {
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// filter by account address
    #[prost(string, tag="2")]
    pub account_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamTradesResponse {
    /// New TC derivative market trade
    #[prost(message, optional, tag="1")]
    pub trade: ::core::option::Option<DerivativeTrade>,
    /// Executed trades update type
    #[prost(string, tag="2")]
    pub operation_type: ::prost::alloc::string::String,
    /// Operation timestamp in UNIX millis
    #[prost(sint64, tag="3")]
    pub timestamp: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PositionsRequest {
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// order side filter
    #[prost(string, tag="2")]
    pub direction: ::prost::alloc::string::String,
    /// filter by account address
    #[prost(string, tag="3")]
    pub account_address: ::prost::alloc::string::String,
    /// Return the total number of matching records alongside results
    #[prost(bool, tag="4")]
    pub with_count: bool,
    /// Number of results per page
    #[prost(sint32, tag="5")]
    pub per_page: i32,
    /// Pagination token
    #[prost(string, tag="6")]
    pub token: ::prost::alloc::string::String,
    /// Include unrealized PnL in the response
    #[prost(bool, tag="7")]
    pub with_upnl: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PositionsResponse {
    /// List of derivative positions
    #[prost(message, repeated, tag="1")]
    pub positions: ::prost::alloc::vec::Vec<DerivativePositionV2>,
    /// Next tokens for pagination
    #[prost(string, repeated, tag="2")]
    pub next: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    #[prost(uint64, tag="3")]
    pub total: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DerivativePositionV2 {
    /// Ticker of the derivative market
    #[prost(string, tag="1")]
    pub ticker: ::prost::alloc::string::String,
    /// Derivative Market ID
    #[prost(string, tag="2")]
    pub market_id: ::prost::alloc::string::String,
    /// The subaccountId that the position belongs to
    #[prost(string, tag="3")]
    pub subaccount_id: ::prost::alloc::string::String,
    /// Direction of the position
    #[prost(string, tag="4")]
    pub direction: ::prost::alloc::string::String,
    /// Quantity of the position
    #[prost(string, tag="5")]
    pub quantity: ::prost::alloc::string::String,
    /// Price of the position
    #[prost(string, tag="6")]
    pub entry_price: ::prost::alloc::string::String,
    /// Margin of the position
    #[prost(string, tag="7")]
    pub margin: ::prost::alloc::string::String,
    /// LiquidationPrice of the position
    #[prost(string, tag="8")]
    pub liquidation_price: ::prost::alloc::string::String,
    /// MarkPrice of the position
    #[prost(string, tag="9")]
    pub mark_price: ::prost::alloc::string::String,
    /// Position updated timestamp in UNIX millis.
    #[prost(sint64, tag="11")]
    pub updated_at: i64,
    /// Market quote denom
    #[prost(string, tag="12")]
    pub denom: ::prost::alloc::string::String,
    /// Last funding fees since position opened
    #[prost(string, tag="13")]
    pub funding_last: ::prost::alloc::string::String,
    /// Net funding fees since position opened
    #[prost(string, tag="14")]
    pub funding_sum: ::prost::alloc::string::String,
    /// Cumulative funding entry of the position
    #[prost(string, tag="15")]
    pub cumulative_funding_entry: ::prost::alloc::string::String,
    /// Effective cumulative funding entry of the position
    #[prost(string, tag="16")]
    pub effective_cumulative_funding_entry: ::prost::alloc::string::String,
    /// Unrealized profit and loss of the position (only present when requested with
    /// with_upnl=true)
    #[prost(string, tag="17")]
    pub upnl: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamPositionsRequest {
    /// List of market IDs of the positions we want to stream
    #[prost(string, repeated, tag="1")]
    pub market_ids: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
    /// filter by account address
    #[prost(string, tag="2")]
    pub account_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StreamPositionsResponse {
    /// Updated derivative Position
    #[prost(message, optional, tag="1")]
    pub position: ::core::option::Option<DerivativePositionV2>,
    /// Operation timestamp in UNIX millis.
    #[prost(sint64, tag="2")]
    pub timestamp: i64,
}
include!("injective_tc_derivatives_rpc.tonic.rs");
// @@protoc_insertion_point(module)

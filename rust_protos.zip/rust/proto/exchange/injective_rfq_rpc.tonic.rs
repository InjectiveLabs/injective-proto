// @generated
/// Generated client implementations.
pub mod injective_rfq_rpc_client {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    #[derive(Debug, Clone)]
    pub struct InjectiveRfqRpcClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl InjectiveRfqRpcClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> InjectiveRfqRpcClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::Body>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + std::marker::Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + std::marker::Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InjectiveRfqRpcClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::Body>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::Body>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::Body>,
            >>::Error: Into<StdError> + std::marker::Send + std::marker::Sync,
        {
            InjectiveRfqRpcClient::new(InterceptedService::new(inner, interceptor))
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        pub async fn stream_request(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamRequestRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamRequestResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfq_rpc.InjectiveRfqRPC/StreamRequest",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("injective_rfq_rpc.InjectiveRfqRPC", "StreamRequest"),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn stream_quote(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamQuoteRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamQuoteResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfq_rpc.InjectiveRfqRPC/StreamQuote",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("injective_rfq_rpc.InjectiveRfqRPC", "StreamQuote"),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn list_settlement(
            &mut self,
            request: impl tonic::IntoRequest<super::ListSettlementRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListSettlementResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfq_rpc.InjectiveRfqRPC/ListSettlement",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_rfq_rpc.InjectiveRfqRPC",
                        "ListSettlement",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn stream_settlement(
            &mut self,
            request: impl tonic::IntoRequest<super::StreamSettlementRequest>,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::StreamSettlementResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfq_rpc.InjectiveRfqRPC/StreamSettlement",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_rfq_rpc.InjectiveRfqRPC",
                        "StreamSettlement",
                    ),
                );
            self.inner.server_streaming(req, path, codec).await
        }
        pub async fn create_conditional_order(
            &mut self,
            request: impl tonic::IntoRequest<super::CreateConditionalOrderRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CreateConditionalOrderResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfq_rpc.InjectiveRfqRPC/CreateConditionalOrder",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_rfq_rpc.InjectiveRfqRPC",
                        "CreateConditionalOrder",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn list_conditional_orders(
            &mut self,
            request: impl tonic::IntoRequest<super::ListConditionalOrdersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListConditionalOrdersResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfq_rpc.InjectiveRfqRPC/ListConditionalOrders",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_rfq_rpc.InjectiveRfqRPC",
                        "ListConditionalOrders",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn taker_stream(
            &mut self,
            request: impl tonic::IntoStreamingRequest<
                Message = super::TakerStreamStreamingRequest,
            >,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::TakerStreamResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfq_rpc.InjectiveRfqRPC/TakerStream",
            );
            let mut req = request.into_streaming_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("injective_rfq_rpc.InjectiveRfqRPC", "TakerStream"),
                );
            self.inner.streaming(req, path, codec).await
        }
        pub async fn maker_stream(
            &mut self,
            request: impl tonic::IntoStreamingRequest<
                Message = super::MakerStreamStreamingRequest,
            >,
        ) -> std::result::Result<
            tonic::Response<tonic::codec::Streaming<super::MakerStreamResponse>>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_rfq_rpc.InjectiveRfqRPC/MakerStream",
            );
            let mut req = request.into_streaming_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("injective_rfq_rpc.InjectiveRfqRPC", "MakerStream"),
                );
            self.inner.streaming(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod injective_rfq_rpc_server {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with InjectiveRfqRpcServer.
    #[async_trait]
    pub trait InjectiveRfqRpc: std::marker::Send + std::marker::Sync + 'static {
        /// Server streaming response type for the StreamRequest method.
        type StreamRequestStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<super::StreamRequestResponse, tonic::Status>,
            >
            + std::marker::Send
            + 'static;
        async fn stream_request(
            &self,
            request: tonic::Request<super::StreamRequestRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamRequestStream>,
            tonic::Status,
        >;
        /// Server streaming response type for the StreamQuote method.
        type StreamQuoteStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<super::StreamQuoteResponse, tonic::Status>,
            >
            + std::marker::Send
            + 'static;
        async fn stream_quote(
            &self,
            request: tonic::Request<super::StreamQuoteRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamQuoteStream>,
            tonic::Status,
        >;
        async fn list_settlement(
            &self,
            request: tonic::Request<super::ListSettlementRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListSettlementResponse>,
            tonic::Status,
        >;
        /// Server streaming response type for the StreamSettlement method.
        type StreamSettlementStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<
                    super::StreamSettlementResponse,
                    tonic::Status,
                >,
            >
            + std::marker::Send
            + 'static;
        async fn stream_settlement(
            &self,
            request: tonic::Request<super::StreamSettlementRequest>,
        ) -> std::result::Result<
            tonic::Response<Self::StreamSettlementStream>,
            tonic::Status,
        >;
        async fn create_conditional_order(
            &self,
            request: tonic::Request<super::CreateConditionalOrderRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CreateConditionalOrderResponse>,
            tonic::Status,
        >;
        async fn list_conditional_orders(
            &self,
            request: tonic::Request<super::ListConditionalOrdersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ListConditionalOrdersResponse>,
            tonic::Status,
        >;
        /// Server streaming response type for the TakerStream method.
        type TakerStreamStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<super::TakerStreamResponse, tonic::Status>,
            >
            + std::marker::Send
            + 'static;
        async fn taker_stream(
            &self,
            request: tonic::Request<tonic::Streaming<super::TakerStreamStreamingRequest>>,
        ) -> std::result::Result<
            tonic::Response<Self::TakerStreamStream>,
            tonic::Status,
        >;
        /// Server streaming response type for the MakerStream method.
        type MakerStreamStream: tonic::codegen::tokio_stream::Stream<
                Item = std::result::Result<super::MakerStreamResponse, tonic::Status>,
            >
            + std::marker::Send
            + 'static;
        async fn maker_stream(
            &self,
            request: tonic::Request<tonic::Streaming<super::MakerStreamStreamingRequest>>,
        ) -> std::result::Result<
            tonic::Response<Self::MakerStreamStream>,
            tonic::Status,
        >;
    }
    #[derive(Debug)]
    pub struct InjectiveRfqRpcServer<T> {
        inner: Arc<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    impl<T> InjectiveRfqRpcServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>> for InjectiveRfqRpcServer<T>
    where
        T: InjectiveRfqRpc,
        B: Body + std::marker::Send + 'static,
        B::Error: Into<StdError> + std::marker::Send + 'static,
    {
        type Response = http::Response<tonic::body::Body>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            match req.uri().path() {
                "/injective_rfq_rpc.InjectiveRfqRPC/StreamRequest" => {
                    #[allow(non_camel_case_types)]
                    struct StreamRequestSvc<T: InjectiveRfqRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqRpc,
                    > tonic::server::ServerStreamingService<super::StreamRequestRequest>
                    for StreamRequestSvc<T> {
                        type Response = super::StreamRequestResponse;
                        type ResponseStream = T::StreamRequestStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamRequestRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveRfqRpc>::stream_request(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = StreamRequestSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfq_rpc.InjectiveRfqRPC/StreamQuote" => {
                    #[allow(non_camel_case_types)]
                    struct StreamQuoteSvc<T: InjectiveRfqRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqRpc,
                    > tonic::server::ServerStreamingService<super::StreamQuoteRequest>
                    for StreamQuoteSvc<T> {
                        type Response = super::StreamQuoteResponse;
                        type ResponseStream = T::StreamQuoteStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamQuoteRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveRfqRpc>::stream_quote(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = StreamQuoteSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfq_rpc.InjectiveRfqRPC/ListSettlement" => {
                    #[allow(non_camel_case_types)]
                    struct ListSettlementSvc<T: InjectiveRfqRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqRpc,
                    > tonic::server::UnaryService<super::ListSettlementRequest>
                    for ListSettlementSvc<T> {
                        type Response = super::ListSettlementResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ListSettlementRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveRfqRpc>::list_settlement(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = ListSettlementSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfq_rpc.InjectiveRfqRPC/StreamSettlement" => {
                    #[allow(non_camel_case_types)]
                    struct StreamSettlementSvc<T: InjectiveRfqRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqRpc,
                    > tonic::server::ServerStreamingService<
                        super::StreamSettlementRequest,
                    > for StreamSettlementSvc<T> {
                        type Response = super::StreamSettlementResponse;
                        type ResponseStream = T::StreamSettlementStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StreamSettlementRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveRfqRpc>::stream_settlement(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = StreamSettlementSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.server_streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfq_rpc.InjectiveRfqRPC/CreateConditionalOrder" => {
                    #[allow(non_camel_case_types)]
                    struct CreateConditionalOrderSvc<T: InjectiveRfqRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqRpc,
                    > tonic::server::UnaryService<super::CreateConditionalOrderRequest>
                    for CreateConditionalOrderSvc<T> {
                        type Response = super::CreateConditionalOrderResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::CreateConditionalOrderRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveRfqRpc>::create_conditional_order(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = CreateConditionalOrderSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfq_rpc.InjectiveRfqRPC/ListConditionalOrders" => {
                    #[allow(non_camel_case_types)]
                    struct ListConditionalOrdersSvc<T: InjectiveRfqRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqRpc,
                    > tonic::server::UnaryService<super::ListConditionalOrdersRequest>
                    for ListConditionalOrdersSvc<T> {
                        type Response = super::ListConditionalOrdersResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ListConditionalOrdersRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveRfqRpc>::list_conditional_orders(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = ListConditionalOrdersSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfq_rpc.InjectiveRfqRPC/TakerStream" => {
                    #[allow(non_camel_case_types)]
                    struct TakerStreamSvc<T: InjectiveRfqRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqRpc,
                    > tonic::server::StreamingService<super::TakerStreamStreamingRequest>
                    for TakerStreamSvc<T> {
                        type Response = super::TakerStreamResponse;
                        type ResponseStream = T::TakerStreamStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                tonic::Streaming<super::TakerStreamStreamingRequest>,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveRfqRpc>::taker_stream(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = TakerStreamSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_rfq_rpc.InjectiveRfqRPC/MakerStream" => {
                    #[allow(non_camel_case_types)]
                    struct MakerStreamSvc<T: InjectiveRfqRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveRfqRpc,
                    > tonic::server::StreamingService<super::MakerStreamStreamingRequest>
                    for MakerStreamSvc<T> {
                        type Response = super::MakerStreamResponse;
                        type ResponseStream = T::MakerStreamStream;
                        type Future = BoxFuture<
                            tonic::Response<Self::ResponseStream>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                tonic::Streaming<super::MakerStreamStreamingRequest>,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveRfqRpc>::maker_stream(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = MakerStreamSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.streaming(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        let mut response = http::Response::new(
                            tonic::body::Body::default(),
                        );
                        let headers = response.headers_mut();
                        headers
                            .insert(
                                tonic::Status::GRPC_STATUS,
                                (tonic::Code::Unimplemented as i32).into(),
                            );
                        headers
                            .insert(
                                http::header::CONTENT_TYPE,
                                tonic::metadata::GRPC_CONTENT_TYPE,
                            );
                        Ok(response)
                    })
                }
            }
        }
    }
    impl<T> Clone for InjectiveRfqRpcServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    /// Generated gRPC service name
    pub const SERVICE_NAME: &str = "injective_rfq_rpc.InjectiveRfqRPC";
    impl<T> tonic::server::NamedService for InjectiveRfqRpcServer<T> {
        const NAME: &'static str = SERVICE_NAME;
    }
}

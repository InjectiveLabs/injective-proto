// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BalanceRequest {
    /// Account address
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
    /// Symbol resolution. Possible resolutions are 1D,1W,1M
    #[prost(string, tag="2")]
    pub resolution: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BalanceResponse {
    #[prost(message, optional, tag="1")]
    pub historical_balance: ::core::option::Option<HistoricalBalance>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct HistoricalBalance {
    /// Time, Unix timestamp (UTC)
    #[prost(sint32, repeated, tag="1")]
    pub t: ::prost::alloc::vec::Vec<i32>,
    /// Balance value
    #[prost(double, repeated, tag="2")]
    pub v: ::prost::alloc::vec::Vec<f64>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RpnlRequest {
    /// Account address
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
    /// Symbol resolution. Possible resolutions are 1D,1W,1M
    #[prost(string, tag="2")]
    pub resolution: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RpnlResponse {
    #[prost(message, optional, tag="1")]
    pub historical_rpnl: ::core::option::Option<HistoricalRpnl>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct HistoricalRpnl {
    /// Time, Unix timestamp (UTC)
    #[prost(sint32, repeated, tag="1")]
    pub t: ::prost::alloc::vec::Vec<i32>,
    /// Realized Profit and Loss value
    #[prost(double, repeated, tag="2")]
    pub v: ::prost::alloc::vec::Vec<f64>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct VolumesRequest {
    /// Account address
    #[prost(string, tag="1")]
    pub account: ::prost::alloc::string::String,
    /// Symbol resolution. Possible resolutions are 1D,1W,1M
    #[prost(string, tag="2")]
    pub resolution: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct VolumesResponse {
    #[prost(message, optional, tag="1")]
    pub historical_volumes: ::core::option::Option<HistoricalVolumes>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct HistoricalVolumes {
    /// Time, Unix timestamp (UTC)
    #[prost(sint32, repeated, tag="1")]
    pub t: ::prost::alloc::vec::Vec<i32>,
    /// Volume value
    #[prost(double, repeated, tag="2")]
    pub v: ::prost::alloc::vec::Vec<f64>,
}
include!("injective_archiver_rpc.tonic.rs");
// @@protoc_insertion_point(module)

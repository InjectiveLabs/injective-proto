// @generated
/// Generated client implementations.
pub mod injective_chart_rpc_client {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    #[derive(Debug, Clone)]
    pub struct InjectiveChartRpcClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl InjectiveChartRpcClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> InjectiveChartRpcClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::Body>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + std::marker::Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + std::marker::Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InjectiveChartRpcClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::Body>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::Body>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::Body>,
            >>::Error: Into<StdError> + std::marker::Send + std::marker::Sync,
        {
            InjectiveChartRpcClient::new(InterceptedService::new(inner, interceptor))
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        pub async fn spot_market_history(
            &mut self,
            request: impl tonic::IntoRequest<super::SpotMarketHistoryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SpotMarketHistoryResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_chart_rpc.InjectiveChartRPC/SpotMarketHistory",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_chart_rpc.InjectiveChartRPC",
                        "SpotMarketHistory",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn derivative_market_history(
            &mut self,
            request: impl tonic::IntoRequest<super::DerivativeMarketHistoryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::DerivativeMarketHistoryResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_chart_rpc.InjectiveChartRPC/DerivativeMarketHistory",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_chart_rpc.InjectiveChartRPC",
                        "DerivativeMarketHistory",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn spot_market_summary(
            &mut self,
            request: impl tonic::IntoRequest<super::SpotMarketSummaryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SpotMarketSummaryResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_chart_rpc.InjectiveChartRPC/SpotMarketSummary",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_chart_rpc.InjectiveChartRPC",
                        "SpotMarketSummary",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn all_spot_market_summary(
            &mut self,
            request: impl tonic::IntoRequest<super::AllSpotMarketSummaryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AllSpotMarketSummaryResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_chart_rpc.InjectiveChartRPC/AllSpotMarketSummary",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_chart_rpc.InjectiveChartRPC",
                        "AllSpotMarketSummary",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn derivative_market_summary(
            &mut self,
            request: impl tonic::IntoRequest<super::DerivativeMarketSummaryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::DerivativeMarketSummaryResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_chart_rpc.InjectiveChartRPC/DerivativeMarketSummary",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_chart_rpc.InjectiveChartRPC",
                        "DerivativeMarketSummary",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn all_derivative_market_summary(
            &mut self,
            request: impl tonic::IntoRequest<super::AllDerivativeMarketSummaryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AllDerivativeMarketSummaryResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_chart_rpc.InjectiveChartRPC/AllDerivativeMarketSummary",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_chart_rpc.InjectiveChartRPC",
                        "AllDerivativeMarketSummary",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        pub async fn market_snapshot(
            &mut self,
            request: impl tonic::IntoRequest<super::MarketSnapshotRequest>,
        ) -> std::result::Result<
            tonic::Response<super::MarketSnapshotResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/injective_chart_rpc.InjectiveChartRPC/MarketSnapshot",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "injective_chart_rpc.InjectiveChartRPC",
                        "MarketSnapshot",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod injective_chart_rpc_server {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with InjectiveChartRpcServer.
    #[async_trait]
    pub trait InjectiveChartRpc: std::marker::Send + std::marker::Sync + 'static {
        async fn spot_market_history(
            &self,
            request: tonic::Request<super::SpotMarketHistoryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SpotMarketHistoryResponse>,
            tonic::Status,
        >;
        async fn derivative_market_history(
            &self,
            request: tonic::Request<super::DerivativeMarketHistoryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::DerivativeMarketHistoryResponse>,
            tonic::Status,
        >;
        async fn spot_market_summary(
            &self,
            request: tonic::Request<super::SpotMarketSummaryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SpotMarketSummaryResponse>,
            tonic::Status,
        >;
        async fn all_spot_market_summary(
            &self,
            request: tonic::Request<super::AllSpotMarketSummaryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AllSpotMarketSummaryResponse>,
            tonic::Status,
        >;
        async fn derivative_market_summary(
            &self,
            request: tonic::Request<super::DerivativeMarketSummaryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::DerivativeMarketSummaryResponse>,
            tonic::Status,
        >;
        async fn all_derivative_market_summary(
            &self,
            request: tonic::Request<super::AllDerivativeMarketSummaryRequest>,
        ) -> std::result::Result<
            tonic::Response<super::AllDerivativeMarketSummaryResponse>,
            tonic::Status,
        >;
        async fn market_snapshot(
            &self,
            request: tonic::Request<super::MarketSnapshotRequest>,
        ) -> std::result::Result<
            tonic::Response<super::MarketSnapshotResponse>,
            tonic::Status,
        >;
    }
    #[derive(Debug)]
    pub struct InjectiveChartRpcServer<T> {
        inner: Arc<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    impl<T> InjectiveChartRpcServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>> for InjectiveChartRpcServer<T>
    where
        T: InjectiveChartRpc,
        B: Body + std::marker::Send + 'static,
        B::Error: Into<StdError> + std::marker::Send + 'static,
    {
        type Response = http::Response<tonic::body::Body>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            match req.uri().path() {
                "/injective_chart_rpc.InjectiveChartRPC/SpotMarketHistory" => {
                    #[allow(non_camel_case_types)]
                    struct SpotMarketHistorySvc<T: InjectiveChartRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveChartRpc,
                    > tonic::server::UnaryService<super::SpotMarketHistoryRequest>
                    for SpotMarketHistorySvc<T> {
                        type Response = super::SpotMarketHistoryResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::SpotMarketHistoryRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveChartRpc>::spot_market_history(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = SpotMarketHistorySvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_chart_rpc.InjectiveChartRPC/DerivativeMarketHistory" => {
                    #[allow(non_camel_case_types)]
                    struct DerivativeMarketHistorySvc<T: InjectiveChartRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveChartRpc,
                    > tonic::server::UnaryService<super::DerivativeMarketHistoryRequest>
                    for DerivativeMarketHistorySvc<T> {
                        type Response = super::DerivativeMarketHistoryResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::DerivativeMarketHistoryRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveChartRpc>::derivative_market_history(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = DerivativeMarketHistorySvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_chart_rpc.InjectiveChartRPC/SpotMarketSummary" => {
                    #[allow(non_camel_case_types)]
                    struct SpotMarketSummarySvc<T: InjectiveChartRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveChartRpc,
                    > tonic::server::UnaryService<super::SpotMarketSummaryRequest>
                    for SpotMarketSummarySvc<T> {
                        type Response = super::SpotMarketSummaryResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::SpotMarketSummaryRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveChartRpc>::spot_market_summary(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = SpotMarketSummarySvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_chart_rpc.InjectiveChartRPC/AllSpotMarketSummary" => {
                    #[allow(non_camel_case_types)]
                    struct AllSpotMarketSummarySvc<T: InjectiveChartRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveChartRpc,
                    > tonic::server::UnaryService<super::AllSpotMarketSummaryRequest>
                    for AllSpotMarketSummarySvc<T> {
                        type Response = super::AllSpotMarketSummaryResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::AllSpotMarketSummaryRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveChartRpc>::all_spot_market_summary(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = AllSpotMarketSummarySvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_chart_rpc.InjectiveChartRPC/DerivativeMarketSummary" => {
                    #[allow(non_camel_case_types)]
                    struct DerivativeMarketSummarySvc<T: InjectiveChartRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveChartRpc,
                    > tonic::server::UnaryService<super::DerivativeMarketSummaryRequest>
                    for DerivativeMarketSummarySvc<T> {
                        type Response = super::DerivativeMarketSummaryResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::DerivativeMarketSummaryRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveChartRpc>::derivative_market_summary(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = DerivativeMarketSummarySvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_chart_rpc.InjectiveChartRPC/AllDerivativeMarketSummary" => {
                    #[allow(non_camel_case_types)]
                    struct AllDerivativeMarketSummarySvc<T: InjectiveChartRpc>(
                        pub Arc<T>,
                    );
                    impl<
                        T: InjectiveChartRpc,
                    > tonic::server::UnaryService<
                        super::AllDerivativeMarketSummaryRequest,
                    > for AllDerivativeMarketSummarySvc<T> {
                        type Response = super::AllDerivativeMarketSummaryResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::AllDerivativeMarketSummaryRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveChartRpc>::all_derivative_market_summary(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = AllDerivativeMarketSummarySvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/injective_chart_rpc.InjectiveChartRPC/MarketSnapshot" => {
                    #[allow(non_camel_case_types)]
                    struct MarketSnapshotSvc<T: InjectiveChartRpc>(pub Arc<T>);
                    impl<
                        T: InjectiveChartRpc,
                    > tonic::server::UnaryService<super::MarketSnapshotRequest>
                    for MarketSnapshotSvc<T> {
                        type Response = super::MarketSnapshotResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::MarketSnapshotRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as InjectiveChartRpc>::market_snapshot(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = MarketSnapshotSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        let mut response = http::Response::new(
                            tonic::body::Body::default(),
                        );
                        let headers = response.headers_mut();
                        headers
                            .insert(
                                tonic::Status::GRPC_STATUS,
                                (tonic::Code::Unimplemented as i32).into(),
                            );
                        headers
                            .insert(
                                http::header::CONTENT_TYPE,
                                tonic::metadata::GRPC_CONTENT_TYPE,
                            );
                        Ok(response)
                    })
                }
            }
        }
    }
    impl<T> Clone for InjectiveChartRpcServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    /// Generated gRPC service name
    pub const SERVICE_NAME: &str = "injective_chart_rpc.InjectiveChartRPC";
    impl<T> tonic::server::NamedService for InjectiveChartRpcServer<T> {
        const NAME: &'static str = SERVICE_NAME;
    }
}

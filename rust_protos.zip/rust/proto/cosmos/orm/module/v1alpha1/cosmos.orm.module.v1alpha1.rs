// @generated
/// Module defines the ORM module which adds providers to the app container for
/// ORM ModuleDB's and in the future will automatically register query
/// services for modules that use the ORM.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Module {
}
// @@protoc_insertion_point(module)

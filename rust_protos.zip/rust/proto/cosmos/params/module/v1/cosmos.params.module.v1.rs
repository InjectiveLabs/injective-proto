// @generated
/// Module is the config object of the params module.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Module {
}
// @@protoc_insertion_point(module)

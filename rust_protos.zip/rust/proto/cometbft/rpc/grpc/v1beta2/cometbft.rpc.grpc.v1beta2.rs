// @generated
/// ResponseBroadcastTx is a response of broadcasting the transaction.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ResponseBroadcastTx {
    #[prost(message, optional, tag="1")]
    pub check_tx: ::core::option::Option<super::super::super::abci::v1beta2::ResponseCheckTx>,
    #[prost(message, optional, tag="2")]
    pub deliver_tx: ::core::option::Option<super::super::super::abci::v1beta2::ResponseDeliverTx>,
}
include!("cometbft.rpc.grpc.v1beta2.tonic.rs");
// @@protoc_insertion_point(module)

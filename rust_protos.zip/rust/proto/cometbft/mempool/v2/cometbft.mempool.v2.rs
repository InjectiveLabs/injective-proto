// @generated
/// Txs contains a list of transaction from the mempool.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Txs {
    #[prost(bytes="vec", repeated, tag="1")]
    pub txs: ::prost::alloc::vec::Vec<::prost::alloc::vec::Vec<u8>>,
}
/// HaveTx is sent by the DOG protocol to signal a peer that the sender already
/// has a transaction.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct HaveTx {
    #[prost(bytes="vec", tag="1")]
    pub tx_key: ::prost::alloc::vec::Vec<u8>,
}
/// ResetRoute is sent by the DOG protocol to signal a peer to reset a (random)
/// route to the sender.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ResetRoute {
}
/// Message is an abstract mempool message.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Message {
    /// Sum of all possible messages.
    #[prost(oneof="message::Sum", tags="1, 2, 3")]
    pub sum: ::core::option::Option<message::Sum>,
}
/// Nested message and enum types in `Message`.
pub mod message {
    /// Sum of all possible messages.
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Sum {
        #[prost(message, tag="1")]
        Txs(super::Txs),
        #[prost(message, tag="2")]
        HaveTx(super::HaveTx),
        #[prost(message, tag="3")]
        ResetRoute(super::ResetRoute),
    }
}
// @@protoc_insertion_point(module)

// @generated
/// GetByHeightRequest is a request for a block at the specified height.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetByHeightRequest {
    /// The height of the block requested.
    #[prost(int64, tag="1")]
    pub height: i64,
}
/// GetByHeightResponse contains the block ID and the block at the specified height.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetByHeightResponse {
    #[prost(message, optional, tag="1")]
    pub block_id: ::core::option::Option<super::super::super::types::v1::BlockId>,
    #[prost(message, optional, tag="2")]
    pub block: ::core::option::Option<super::super::super::types::v1::Block>,
}
/// GetLatestHeightRequest - empty message since no parameter is required
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetLatestHeightRequest {
}
/// GetLatestHeightResponse provides the height of the latest committed block.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetLatestHeightResponse {
    /// The height of the latest committed block. Will be 0 if no data has been
    /// committed yet.
    #[prost(int64, tag="1")]
    pub height: i64,
}
include!("cometbft.services.block.v1.tonic.rs");
// @@protoc_insertion_point(module)

// @generated
/// SetBlockRetainHeightRequest sets the retain height for blocks.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetBlockRetainHeightRequest {
    #[prost(uint64, tag="1")]
    pub height: u64,
}
/// SetBlockRetainHeightResponse is empty.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetBlockRetainHeightResponse {
}
/// GetBlockRetainHeightRequest is a request for the retain height.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlockRetainHeightRequest {
}
/// GetBlockRetainHeightResponse returns the retain height for blocks.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlockRetainHeightResponse {
    /// The retain height set by the application.
    #[prost(uint64, tag="1")]
    pub app_retain_height: u64,
    /// The retain height set via the pruning service (e.g. by the data
    /// companion) specifically for blocks.
    #[prost(uint64, tag="2")]
    pub pruning_service_retain_height: u64,
}
/// SetBlockResultsRetainHeightRequest sets the retain height for block results.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetBlockResultsRetainHeightRequest {
    #[prost(uint64, tag="1")]
    pub height: u64,
}
/// SetBlockResultsRetainHeightResponse is empty.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetBlockResultsRetainHeightResponse {
}
/// GetBlockResultsRetainHeightRequest is a request for the retain height.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlockResultsRetainHeightRequest {
}
/// GetBlockResultsRetainHeightResponse returns the retain height for block results.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlockResultsRetainHeightResponse {
    /// The retain height set by the pruning service (e.g. by the data
    /// companion) specifically for block results.
    #[prost(uint64, tag="1")]
    pub pruning_service_retain_height: u64,
}
/// SetTxIndexerRetainHeightRequest sets the retain height for the tx indexer.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetTxIndexerRetainHeightRequest {
    #[prost(uint64, tag="1")]
    pub height: u64,
}
/// SetTxIndexerRetainHeightResponse is empty.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetTxIndexerRetainHeightResponse {
}
/// GetTxIndexerRetainHeightRequest is a request for the retain height.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetTxIndexerRetainHeightRequest {
}
/// GetTxIndexerRetainHeightResponse returns the retain height for the tx indexer.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetTxIndexerRetainHeightResponse {
    #[prost(uint64, tag="1")]
    pub height: u64,
}
/// SetBlockIndexerRetainHeightRequest sets the retain height for the block indexer.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetBlockIndexerRetainHeightRequest {
    #[prost(uint64, tag="1")]
    pub height: u64,
}
/// SetBlockIndexerRetainHeightResponse is empty.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetBlockIndexerRetainHeightResponse {
}
/// GetBlockIndexerRetainHeightRequest is a request for the retain height.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlockIndexerRetainHeightRequest {
}
/// GetBlockIndexerRetainHeightResponse returns the retain height for the block indexer.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlockIndexerRetainHeightResponse {
    #[prost(uint64, tag="1")]
    pub height: u64,
}
include!("cometbft.services.pruning.v1.tonic.rs");
// @@protoc_insertion_point(module)

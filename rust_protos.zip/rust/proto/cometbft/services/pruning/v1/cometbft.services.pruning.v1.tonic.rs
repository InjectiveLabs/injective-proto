// @generated
/// Generated client implementations.
pub mod pruning_service_client {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    /** PruningService provides privileged access to specialized pruning
 functionality on the CometBFT node to help control node storage.
*/
    #[derive(Debug, Clone)]
    pub struct PruningServiceClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl PruningServiceClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> PruningServiceClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::Body>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + std::marker::Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + std::marker::Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> PruningServiceClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::Body>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::Body>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::Body>,
            >>::Error: Into<StdError> + std::marker::Send + std::marker::Sync,
        {
            PruningServiceClient::new(InterceptedService::new(inner, interceptor))
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        /** SetBlockRetainHeightRequest indicates to the node that it can safely
 prune all block data up to the specified retain height.

 The lower of this retain height and that set by the application in its
 Commit response will be used by the node to determine which heights' data
 can be pruned.
*/
        pub async fn set_block_retain_height(
            &mut self,
            request: impl tonic::IntoRequest<super::SetBlockRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetBlockRetainHeightResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/cometbft.services.pruning.v1.PruningService/SetBlockRetainHeight",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "cometbft.services.pruning.v1.PruningService",
                        "SetBlockRetainHeight",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        /** GetBlockRetainHeight returns information about the retain height
 parameters used by the node to influence block retention/pruning.
*/
        pub async fn get_block_retain_height(
            &mut self,
            request: impl tonic::IntoRequest<super::GetBlockRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlockRetainHeightResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/cometbft.services.pruning.v1.PruningService/GetBlockRetainHeight",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "cometbft.services.pruning.v1.PruningService",
                        "GetBlockRetainHeight",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        /** SetBlockResultsRetainHeightRequest indicates to the node that it can
 safely prune all block results data up to the specified height.

 The node will always store the block results for the latest height to
 help facilitate crash recovery.
*/
        pub async fn set_block_results_retain_height(
            &mut self,
            request: impl tonic::IntoRequest<super::SetBlockResultsRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetBlockResultsRetainHeightResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/cometbft.services.pruning.v1.PruningService/SetBlockResultsRetainHeight",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "cometbft.services.pruning.v1.PruningService",
                        "SetBlockResultsRetainHeight",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        /** GetBlockResultsRetainHeight returns information about the retain height
 parameters used by the node to influence block results retention/pruning.
*/
        pub async fn get_block_results_retain_height(
            &mut self,
            request: impl tonic::IntoRequest<super::GetBlockResultsRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlockResultsRetainHeightResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/cometbft.services.pruning.v1.PruningService/GetBlockResultsRetainHeight",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "cometbft.services.pruning.v1.PruningService",
                        "GetBlockResultsRetainHeight",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        /** SetTxIndexerRetainHeightRequest indicates to the node that it can safely
 prune all tx indices up to the specified retain height.
*/
        pub async fn set_tx_indexer_retain_height(
            &mut self,
            request: impl tonic::IntoRequest<super::SetTxIndexerRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetTxIndexerRetainHeightResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/cometbft.services.pruning.v1.PruningService/SetTxIndexerRetainHeight",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "cometbft.services.pruning.v1.PruningService",
                        "SetTxIndexerRetainHeight",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        /** GetTxIndexerRetainHeight returns information about the retain height
 parameters used by the node to influence TxIndexer pruning
*/
        pub async fn get_tx_indexer_retain_height(
            &mut self,
            request: impl tonic::IntoRequest<super::GetTxIndexerRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetTxIndexerRetainHeightResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/cometbft.services.pruning.v1.PruningService/GetTxIndexerRetainHeight",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "cometbft.services.pruning.v1.PruningService",
                        "GetTxIndexerRetainHeight",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        /** SetBlockIndexerRetainHeightRequest indicates to the node that it can safely
 prune all block indices up to the specified retain height.
*/
        pub async fn set_block_indexer_retain_height(
            &mut self,
            request: impl tonic::IntoRequest<super::SetBlockIndexerRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetBlockIndexerRetainHeightResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/cometbft.services.pruning.v1.PruningService/SetBlockIndexerRetainHeight",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "cometbft.services.pruning.v1.PruningService",
                        "SetBlockIndexerRetainHeight",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        /** GetBlockIndexerRetainHeight returns information about the retain height
 parameters used by the node to influence BlockIndexer pruning
*/
        pub async fn get_block_indexer_retain_height(
            &mut self,
            request: impl tonic::IntoRequest<super::GetBlockIndexerRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlockIndexerRetainHeightResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::unknown(
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic_prost::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/cometbft.services.pruning.v1.PruningService/GetBlockIndexerRetainHeight",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "cometbft.services.pruning.v1.PruningService",
                        "GetBlockIndexerRetainHeight",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod pruning_service_server {
    #![allow(
        unused_variables,
        dead_code,
        missing_docs,
        clippy::wildcard_imports,
        clippy::let_unit_value,
    )]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with PruningServiceServer.
    #[async_trait]
    pub trait PruningService: std::marker::Send + std::marker::Sync + 'static {
        /** SetBlockRetainHeightRequest indicates to the node that it can safely
 prune all block data up to the specified retain height.

 The lower of this retain height and that set by the application in its
 Commit response will be used by the node to determine which heights' data
 can be pruned.
*/
        async fn set_block_retain_height(
            &self,
            request: tonic::Request<super::SetBlockRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetBlockRetainHeightResponse>,
            tonic::Status,
        >;
        /** GetBlockRetainHeight returns information about the retain height
 parameters used by the node to influence block retention/pruning.
*/
        async fn get_block_retain_height(
            &self,
            request: tonic::Request<super::GetBlockRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlockRetainHeightResponse>,
            tonic::Status,
        >;
        /** SetBlockResultsRetainHeightRequest indicates to the node that it can
 safely prune all block results data up to the specified height.

 The node will always store the block results for the latest height to
 help facilitate crash recovery.
*/
        async fn set_block_results_retain_height(
            &self,
            request: tonic::Request<super::SetBlockResultsRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetBlockResultsRetainHeightResponse>,
            tonic::Status,
        >;
        /** GetBlockResultsRetainHeight returns information about the retain height
 parameters used by the node to influence block results retention/pruning.
*/
        async fn get_block_results_retain_height(
            &self,
            request: tonic::Request<super::GetBlockResultsRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlockResultsRetainHeightResponse>,
            tonic::Status,
        >;
        /** SetTxIndexerRetainHeightRequest indicates to the node that it can safely
 prune all tx indices up to the specified retain height.
*/
        async fn set_tx_indexer_retain_height(
            &self,
            request: tonic::Request<super::SetTxIndexerRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetTxIndexerRetainHeightResponse>,
            tonic::Status,
        >;
        /** GetTxIndexerRetainHeight returns information about the retain height
 parameters used by the node to influence TxIndexer pruning
*/
        async fn get_tx_indexer_retain_height(
            &self,
            request: tonic::Request<super::GetTxIndexerRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetTxIndexerRetainHeightResponse>,
            tonic::Status,
        >;
        /** SetBlockIndexerRetainHeightRequest indicates to the node that it can safely
 prune all block indices up to the specified retain height.
*/
        async fn set_block_indexer_retain_height(
            &self,
            request: tonic::Request<super::SetBlockIndexerRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetBlockIndexerRetainHeightResponse>,
            tonic::Status,
        >;
        /** GetBlockIndexerRetainHeight returns information about the retain height
 parameters used by the node to influence BlockIndexer pruning
*/
        async fn get_block_indexer_retain_height(
            &self,
            request: tonic::Request<super::GetBlockIndexerRetainHeightRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlockIndexerRetainHeightResponse>,
            tonic::Status,
        >;
    }
    /** PruningService provides privileged access to specialized pruning
 functionality on the CometBFT node to help control node storage.
*/
    #[derive(Debug)]
    pub struct PruningServiceServer<T> {
        inner: Arc<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    impl<T> PruningServiceServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>> for PruningServiceServer<T>
    where
        T: PruningService,
        B: Body + std::marker::Send + 'static,
        B::Error: Into<StdError> + std::marker::Send + 'static,
    {
        type Response = http::Response<tonic::body::Body>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            match req.uri().path() {
                "/cometbft.services.pruning.v1.PruningService/SetBlockRetainHeight" => {
                    #[allow(non_camel_case_types)]
                    struct SetBlockRetainHeightSvc<T: PruningService>(pub Arc<T>);
                    impl<
                        T: PruningService,
                    > tonic::server::UnaryService<super::SetBlockRetainHeightRequest>
                    for SetBlockRetainHeightSvc<T> {
                        type Response = super::SetBlockRetainHeightResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::SetBlockRetainHeightRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as PruningService>::set_block_retain_height(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = SetBlockRetainHeightSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/cometbft.services.pruning.v1.PruningService/GetBlockRetainHeight" => {
                    #[allow(non_camel_case_types)]
                    struct GetBlockRetainHeightSvc<T: PruningService>(pub Arc<T>);
                    impl<
                        T: PruningService,
                    > tonic::server::UnaryService<super::GetBlockRetainHeightRequest>
                    for GetBlockRetainHeightSvc<T> {
                        type Response = super::GetBlockRetainHeightResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetBlockRetainHeightRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as PruningService>::get_block_retain_height(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = GetBlockRetainHeightSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/cometbft.services.pruning.v1.PruningService/SetBlockResultsRetainHeight" => {
                    #[allow(non_camel_case_types)]
                    struct SetBlockResultsRetainHeightSvc<T: PruningService>(pub Arc<T>);
                    impl<
                        T: PruningService,
                    > tonic::server::UnaryService<
                        super::SetBlockResultsRetainHeightRequest,
                    > for SetBlockResultsRetainHeightSvc<T> {
                        type Response = super::SetBlockResultsRetainHeightResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::SetBlockResultsRetainHeightRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as PruningService>::set_block_results_retain_height(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = SetBlockResultsRetainHeightSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/cometbft.services.pruning.v1.PruningService/GetBlockResultsRetainHeight" => {
                    #[allow(non_camel_case_types)]
                    struct GetBlockResultsRetainHeightSvc<T: PruningService>(pub Arc<T>);
                    impl<
                        T: PruningService,
                    > tonic::server::UnaryService<
                        super::GetBlockResultsRetainHeightRequest,
                    > for GetBlockResultsRetainHeightSvc<T> {
                        type Response = super::GetBlockResultsRetainHeightResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::GetBlockResultsRetainHeightRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as PruningService>::get_block_results_retain_height(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = GetBlockResultsRetainHeightSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/cometbft.services.pruning.v1.PruningService/SetTxIndexerRetainHeight" => {
                    #[allow(non_camel_case_types)]
                    struct SetTxIndexerRetainHeightSvc<T: PruningService>(pub Arc<T>);
                    impl<
                        T: PruningService,
                    > tonic::server::UnaryService<super::SetTxIndexerRetainHeightRequest>
                    for SetTxIndexerRetainHeightSvc<T> {
                        type Response = super::SetTxIndexerRetainHeightResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::SetTxIndexerRetainHeightRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as PruningService>::set_tx_indexer_retain_height(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = SetTxIndexerRetainHeightSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/cometbft.services.pruning.v1.PruningService/GetTxIndexerRetainHeight" => {
                    #[allow(non_camel_case_types)]
                    struct GetTxIndexerRetainHeightSvc<T: PruningService>(pub Arc<T>);
                    impl<
                        T: PruningService,
                    > tonic::server::UnaryService<super::GetTxIndexerRetainHeightRequest>
                    for GetTxIndexerRetainHeightSvc<T> {
                        type Response = super::GetTxIndexerRetainHeightResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::GetTxIndexerRetainHeightRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as PruningService>::get_tx_indexer_retain_height(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = GetTxIndexerRetainHeightSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/cometbft.services.pruning.v1.PruningService/SetBlockIndexerRetainHeight" => {
                    #[allow(non_camel_case_types)]
                    struct SetBlockIndexerRetainHeightSvc<T: PruningService>(pub Arc<T>);
                    impl<
                        T: PruningService,
                    > tonic::server::UnaryService<
                        super::SetBlockIndexerRetainHeightRequest,
                    > for SetBlockIndexerRetainHeightSvc<T> {
                        type Response = super::SetBlockIndexerRetainHeightResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::SetBlockIndexerRetainHeightRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as PruningService>::set_block_indexer_retain_height(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = SetBlockIndexerRetainHeightSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/cometbft.services.pruning.v1.PruningService/GetBlockIndexerRetainHeight" => {
                    #[allow(non_camel_case_types)]
                    struct GetBlockIndexerRetainHeightSvc<T: PruningService>(pub Arc<T>);
                    impl<
                        T: PruningService,
                    > tonic::server::UnaryService<
                        super::GetBlockIndexerRetainHeightRequest,
                    > for GetBlockIndexerRetainHeightSvc<T> {
                        type Response = super::GetBlockIndexerRetainHeightResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::GetBlockIndexerRetainHeightRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as PruningService>::get_block_indexer_retain_height(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let method = GetBlockIndexerRetainHeightSvc(inner);
                        let codec = tonic_prost::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        let mut response = http::Response::new(
                            tonic::body::Body::default(),
                        );
                        let headers = response.headers_mut();
                        headers
                            .insert(
                                tonic::Status::GRPC_STATUS,
                                (tonic::Code::Unimplemented as i32).into(),
                            );
                        headers
                            .insert(
                                http::header::CONTENT_TYPE,
                                tonic::metadata::GRPC_CONTENT_TYPE,
                            );
                        Ok(response)
                    })
                }
            }
        }
    }
    impl<T> Clone for PruningServiceServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    /// Generated gRPC service name
    pub const SERVICE_NAME: &str = "cometbft.services.pruning.v1.PruningService";
    impl<T> tonic::server::NamedService for PruningServiceServer<T> {
        const NAME: &'static str = SERVICE_NAME;
    }
}

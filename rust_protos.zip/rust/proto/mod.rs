// @generated
// @@protoc_insertion_point(attribute:amino)
pub mod amino {
    include!("amino/amino.rs");
    // @@protoc_insertion_point(amino)
}
pub mod capability {
    // @@protoc_insertion_point(attribute:capability.v1)
    pub mod v1 {
        include!("capability/v1/capability.v1.rs");
        // @@protoc_insertion_point(capability.v1)
    }
}
pub mod cometbft {
    pub mod abci {
        // @@protoc_insertion_point(attribute:cometbft.abci.v1)
        pub mod v1 {
            include!("cometbft/abci/v1/cometbft.abci.v1.rs");
            // @@protoc_insertion_point(cometbft.abci.v1)
        }
        // @@protoc_insertion_point(attribute:cometbft.abci.v1beta1)
        pub mod v1beta1 {
            include!("cometbft/abci/v1beta1/cometbft.abci.v1beta1.rs");
            // @@protoc_insertion_point(cometbft.abci.v1beta1)
        }
        // @@protoc_insertion_point(attribute:cometbft.abci.v1beta2)
        pub mod v1beta2 {
            include!("cometbft/abci/v1beta2/cometbft.abci.v1beta2.rs");
            // @@protoc_insertion_point(cometbft.abci.v1beta2)
        }
        // @@protoc_insertion_point(attribute:cometbft.abci.v1beta3)
        pub mod v1beta3 {
            include!("cometbft/abci/v1beta3/cometbft.abci.v1beta3.rs");
            // @@protoc_insertion_point(cometbft.abci.v1beta3)
        }
    }
    pub mod blocksync {
        // @@protoc_insertion_point(attribute:cometbft.blocksync.v1)
        pub mod v1 {
            include!("cometbft/blocksync/v1/cometbft.blocksync.v1.rs");
            // @@protoc_insertion_point(cometbft.blocksync.v1)
        }
        // @@protoc_insertion_point(attribute:cometbft.blocksync.v1beta1)
        pub mod v1beta1 {
            include!("cometbft/blocksync/v1beta1/cometbft.blocksync.v1beta1.rs");
            // @@protoc_insertion_point(cometbft.blocksync.v1beta1)
        }
    }
    pub mod consensus {
        // @@protoc_insertion_point(attribute:cometbft.consensus.v1)
        pub mod v1 {
            include!("cometbft/consensus/v1/cometbft.consensus.v1.rs");
            // @@protoc_insertion_point(cometbft.consensus.v1)
        }
        // @@protoc_insertion_point(attribute:cometbft.consensus.v1beta1)
        pub mod v1beta1 {
            include!("cometbft/consensus/v1beta1/cometbft.consensus.v1beta1.rs");
            // @@protoc_insertion_point(cometbft.consensus.v1beta1)
        }
    }
    pub mod crypto {
        // @@protoc_insertion_point(attribute:cometbft.crypto.v1)
        pub mod v1 {
            include!("cometbft/crypto/v1/cometbft.crypto.v1.rs");
            // @@protoc_insertion_point(cometbft.crypto.v1)
        }
    }
    pub mod libs {
        pub mod bits {
            // @@protoc_insertion_point(attribute:cometbft.libs.bits.v1)
            pub mod v1 {
                include!("cometbft/libs/bits/v1/cometbft.libs.bits.v1.rs");
                // @@protoc_insertion_point(cometbft.libs.bits.v1)
            }
        }
    }
    pub mod mempool {
        // @@protoc_insertion_point(attribute:cometbft.mempool.v1)
        pub mod v1 {
            include!("cometbft/mempool/v1/cometbft.mempool.v1.rs");
            // @@protoc_insertion_point(cometbft.mempool.v1)
        }
        // @@protoc_insertion_point(attribute:cometbft.mempool.v2)
        pub mod v2 {
            include!("cometbft/mempool/v2/cometbft.mempool.v2.rs");
            // @@protoc_insertion_point(cometbft.mempool.v2)
        }
    }
    pub mod p2p {
        // @@protoc_insertion_point(attribute:cometbft.p2p.v1)
        pub mod v1 {
            include!("cometbft/p2p/v1/cometbft.p2p.v1.rs");
            // @@protoc_insertion_point(cometbft.p2p.v1)
        }
    }
    pub mod privval {
        // @@protoc_insertion_point(attribute:cometbft.privval.v1)
        pub mod v1 {
            include!("cometbft/privval/v1/cometbft.privval.v1.rs");
            // @@protoc_insertion_point(cometbft.privval.v1)
        }
        // @@protoc_insertion_point(attribute:cometbft.privval.v1beta1)
        pub mod v1beta1 {
            include!("cometbft/privval/v1beta1/cometbft.privval.v1beta1.rs");
            // @@protoc_insertion_point(cometbft.privval.v1beta1)
        }
        // @@protoc_insertion_point(attribute:cometbft.privval.v1beta2)
        pub mod v1beta2 {
            include!("cometbft/privval/v1beta2/cometbft.privval.v1beta2.rs");
            // @@protoc_insertion_point(cometbft.privval.v1beta2)
        }
    }
    pub mod rpc {
        pub mod grpc {
            // @@protoc_insertion_point(attribute:cometbft.rpc.grpc.v1beta1)
            pub mod v1beta1 {
                include!("cometbft/rpc/grpc/v1beta1/cometbft.rpc.grpc.v1beta1.rs");
                // @@protoc_insertion_point(cometbft.rpc.grpc.v1beta1)
            }
            // @@protoc_insertion_point(attribute:cometbft.rpc.grpc.v1beta2)
            pub mod v1beta2 {
                include!("cometbft/rpc/grpc/v1beta2/cometbft.rpc.grpc.v1beta2.rs");
                // @@protoc_insertion_point(cometbft.rpc.grpc.v1beta2)
            }
            // @@protoc_insertion_point(attribute:cometbft.rpc.grpc.v1beta3)
            pub mod v1beta3 {
                include!("cometbft/rpc/grpc/v1beta3/cometbft.rpc.grpc.v1beta3.rs");
                // @@protoc_insertion_point(cometbft.rpc.grpc.v1beta3)
            }
        }
    }
    pub mod services {
        pub mod block {
            // @@protoc_insertion_point(attribute:cometbft.services.block.v1)
            pub mod v1 {
                include!("cometbft/services/block/v1/cometbft.services.block.v1.rs");
                // @@protoc_insertion_point(cometbft.services.block.v1)
            }
        }
        pub mod block_results {
            // @@protoc_insertion_point(attribute:cometbft.services.block_results.v1)
            pub mod v1 {
                include!("cometbft/services/block_results/v1/cometbft.services.block_results.v1.rs");
                // @@protoc_insertion_point(cometbft.services.block_results.v1)
            }
        }
        pub mod pruning {
            // @@protoc_insertion_point(attribute:cometbft.services.pruning.v1)
            pub mod v1 {
                include!("cometbft/services/pruning/v1/cometbft.services.pruning.v1.rs");
                // @@protoc_insertion_point(cometbft.services.pruning.v1)
            }
        }
        pub mod version {
            // @@protoc_insertion_point(attribute:cometbft.services.version.v1)
            pub mod v1 {
                include!("cometbft/services/version/v1/cometbft.services.version.v1.rs");
                // @@protoc_insertion_point(cometbft.services.version.v1)
            }
        }
    }
    pub mod state {
        // @@protoc_insertion_point(attribute:cometbft.state.v1)
        pub mod v1 {
            include!("cometbft/state/v1/cometbft.state.v1.rs");
            // @@protoc_insertion_point(cometbft.state.v1)
        }
        // @@protoc_insertion_point(attribute:cometbft.state.v1beta1)
        pub mod v1beta1 {
            include!("cometbft/state/v1beta1/cometbft.state.v1beta1.rs");
            // @@protoc_insertion_point(cometbft.state.v1beta1)
        }
        // @@protoc_insertion_point(attribute:cometbft.state.v1beta2)
        pub mod v1beta2 {
            include!("cometbft/state/v1beta2/cometbft.state.v1beta2.rs");
            // @@protoc_insertion_point(cometbft.state.v1beta2)
        }
        // @@protoc_insertion_point(attribute:cometbft.state.v1beta3)
        pub mod v1beta3 {
            include!("cometbft/state/v1beta3/cometbft.state.v1beta3.rs");
            // @@protoc_insertion_point(cometbft.state.v1beta3)
        }
    }
    pub mod statesync {
        // @@protoc_insertion_point(attribute:cometbft.statesync.v1)
        pub mod v1 {
            include!("cometbft/statesync/v1/cometbft.statesync.v1.rs");
            // @@protoc_insertion_point(cometbft.statesync.v1)
        }
    }
    pub mod store {
        // @@protoc_insertion_point(attribute:cometbft.store.v1)
        pub mod v1 {
            include!("cometbft/store/v1/cometbft.store.v1.rs");
            // @@protoc_insertion_point(cometbft.store.v1)
        }
    }
    pub mod types {
        // @@protoc_insertion_point(attribute:cometbft.types.v1)
        pub mod v1 {
            include!("cometbft/types/v1/cometbft.types.v1.rs");
            // @@protoc_insertion_point(cometbft.types.v1)
        }
        // @@protoc_insertion_point(attribute:cometbft.types.v1beta1)
        pub mod v1beta1 {
            include!("cometbft/types/v1beta1/cometbft.types.v1beta1.rs");
            // @@protoc_insertion_point(cometbft.types.v1beta1)
        }
        // @@protoc_insertion_point(attribute:cometbft.types.v1beta2)
        pub mod v1beta2 {
            include!("cometbft/types/v1beta2/cometbft.types.v1beta2.rs");
            // @@protoc_insertion_point(cometbft.types.v1beta2)
        }
    }
    pub mod version {
        // @@protoc_insertion_point(attribute:cometbft.version.v1)
        pub mod v1 {
            include!("cometbft/version/v1/cometbft.version.v1.rs");
            // @@protoc_insertion_point(cometbft.version.v1)
        }
    }
}
pub mod cosmos {
    pub mod app {
        pub mod runtime {
            // @@protoc_insertion_point(attribute:cosmos.app.runtime.v1alpha1)
            pub mod v1alpha1 {
                include!("cosmos/app/runtime/v1alpha1/cosmos.app.runtime.v1alpha1.rs");
                // @@protoc_insertion_point(cosmos.app.runtime.v1alpha1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.app.v1alpha1)
        pub mod v1alpha1 {
            include!("cosmos/app/v1alpha1/cosmos.app.v1alpha1.rs");
            // @@protoc_insertion_point(cosmos.app.v1alpha1)
        }
    }
    pub mod auth {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.auth.module.v1)
            pub mod v1 {
                include!("cosmos/auth/module/v1/cosmos.auth.module.v1.rs");
                // @@protoc_insertion_point(cosmos.auth.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.auth.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/auth/v1beta1/cosmos.auth.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.auth.v1beta1)
        }
    }
    pub mod authz {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.authz.module.v1)
            pub mod v1 {
                include!("cosmos/authz/module/v1/cosmos.authz.module.v1.rs");
                // @@protoc_insertion_point(cosmos.authz.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.authz.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/authz/v1beta1/cosmos.authz.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.authz.v1beta1)
        }
    }
    pub mod autocli {
        // @@protoc_insertion_point(attribute:cosmos.autocli.v1)
        pub mod v1 {
            include!("cosmos/autocli/v1/cosmos.autocli.v1.rs");
            // @@protoc_insertion_point(cosmos.autocli.v1)
        }
    }
    pub mod bank {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.bank.module.v1)
            pub mod v1 {
                include!("cosmos/bank/module/v1/cosmos.bank.module.v1.rs");
                // @@protoc_insertion_point(cosmos.bank.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.bank.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/bank/v1beta1/cosmos.bank.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.bank.v1beta1)
        }
    }
    pub mod base {
        pub mod abci {
            // @@protoc_insertion_point(attribute:cosmos.base.abci.v1beta1)
            pub mod v1beta1 {
                include!("cosmos/base/abci/v1beta1/cosmos.base.abci.v1beta1.rs");
                // @@protoc_insertion_point(cosmos.base.abci.v1beta1)
            }
        }
        pub mod node {
            // @@protoc_insertion_point(attribute:cosmos.base.node.v1beta1)
            pub mod v1beta1 {
                include!("cosmos/base/node/v1beta1/cosmos.base.node.v1beta1.rs");
                // @@protoc_insertion_point(cosmos.base.node.v1beta1)
            }
        }
        pub mod query {
            // @@protoc_insertion_point(attribute:cosmos.base.query.v1beta1)
            pub mod v1beta1 {
                include!("cosmos/base/query/v1beta1/cosmos.base.query.v1beta1.rs");
                // @@protoc_insertion_point(cosmos.base.query.v1beta1)
            }
        }
        pub mod reflection {
            // @@protoc_insertion_point(attribute:cosmos.base.reflection.v1beta1)
            pub mod v1beta1 {
                include!("cosmos/base/reflection/v1beta1/cosmos.base.reflection.v1beta1.rs");
                // @@protoc_insertion_point(cosmos.base.reflection.v1beta1)
            }
            // @@protoc_insertion_point(attribute:cosmos.base.reflection.v2alpha1)
            pub mod v2alpha1 {
                include!("cosmos/base/reflection/v2alpha1/cosmos.base.reflection.v2alpha1.rs");
                // @@protoc_insertion_point(cosmos.base.reflection.v2alpha1)
            }
        }
        pub mod tendermint {
            // @@protoc_insertion_point(attribute:cosmos.base.tendermint.v1beta1)
            pub mod v1beta1 {
                include!("cosmos/base/tendermint/v1beta1/cosmos.base.tendermint.v1beta1.rs");
                // @@protoc_insertion_point(cosmos.base.tendermint.v1beta1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.base.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/base/v1beta1/cosmos.base.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.base.v1beta1)
        }
    }
    pub mod circuit {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.circuit.module.v1)
            pub mod v1 {
                include!("cosmos/circuit/module/v1/cosmos.circuit.module.v1.rs");
                // @@protoc_insertion_point(cosmos.circuit.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.circuit.v1)
        pub mod v1 {
            include!("cosmos/circuit/v1/cosmos.circuit.v1.rs");
            // @@protoc_insertion_point(cosmos.circuit.v1)
        }
    }
    pub mod consensus {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.consensus.module.v1)
            pub mod v1 {
                include!("cosmos/consensus/module/v1/cosmos.consensus.module.v1.rs");
                // @@protoc_insertion_point(cosmos.consensus.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.consensus.v1)
        pub mod v1 {
            include!("cosmos/consensus/v1/cosmos.consensus.v1.rs");
            // @@protoc_insertion_point(cosmos.consensus.v1)
        }
    }
    pub mod crisis {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.crisis.module.v1)
            pub mod v1 {
                include!("cosmos/crisis/module/v1/cosmos.crisis.module.v1.rs");
                // @@protoc_insertion_point(cosmos.crisis.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.crisis.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/crisis/v1beta1/cosmos.crisis.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.crisis.v1beta1)
        }
    }
    pub mod crypto {
        // @@protoc_insertion_point(attribute:cosmos.crypto.ed25519)
        pub mod ed25519 {
            include!("cosmos/crypto/ed25519/cosmos.crypto.ed25519.rs");
            // @@protoc_insertion_point(cosmos.crypto.ed25519)
        }
        pub mod hd {
            // @@protoc_insertion_point(attribute:cosmos.crypto.hd.v1)
            pub mod v1 {
                include!("cosmos/crypto/hd/v1/cosmos.crypto.hd.v1.rs");
                // @@protoc_insertion_point(cosmos.crypto.hd.v1)
            }
        }
        pub mod keyring {
            // @@protoc_insertion_point(attribute:cosmos.crypto.keyring.v1)
            pub mod v1 {
                include!("cosmos/crypto/keyring/v1/cosmos.crypto.keyring.v1.rs");
                // @@protoc_insertion_point(cosmos.crypto.keyring.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.crypto.multisig)
        pub mod multisig {
            include!("cosmos/crypto/multisig/cosmos.crypto.multisig.rs");
            // @@protoc_insertion_point(cosmos.crypto.multisig)
            // @@protoc_insertion_point(attribute:cosmos.crypto.multisig.v1beta1)
            pub mod v1beta1 {
                include!("cosmos/crypto/multisig/v1beta1/cosmos.crypto.multisig.v1beta1.rs");
                // @@protoc_insertion_point(cosmos.crypto.multisig.v1beta1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.crypto.secp256k1)
        pub mod secp256k1 {
            include!("cosmos/crypto/secp256k1/cosmos.crypto.secp256k1.rs");
            // @@protoc_insertion_point(cosmos.crypto.secp256k1)
        }
        // @@protoc_insertion_point(attribute:cosmos.crypto.secp256r1)
        pub mod secp256r1 {
            include!("cosmos/crypto/secp256r1/cosmos.crypto.secp256r1.rs");
            // @@protoc_insertion_point(cosmos.crypto.secp256r1)
        }
    }
    pub mod distribution {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.distribution.module.v1)
            pub mod v1 {
                include!("cosmos/distribution/module/v1/cosmos.distribution.module.v1.rs");
                // @@protoc_insertion_point(cosmos.distribution.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.distribution.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/distribution/v1beta1/cosmos.distribution.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.distribution.v1beta1)
        }
    }
    pub mod evidence {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.evidence.module.v1)
            pub mod v1 {
                include!("cosmos/evidence/module/v1/cosmos.evidence.module.v1.rs");
                // @@protoc_insertion_point(cosmos.evidence.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.evidence.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/evidence/v1beta1/cosmos.evidence.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.evidence.v1beta1)
        }
    }
    pub mod feegrant {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.feegrant.module.v1)
            pub mod v1 {
                include!("cosmos/feegrant/module/v1/cosmos.feegrant.module.v1.rs");
                // @@protoc_insertion_point(cosmos.feegrant.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.feegrant.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/feegrant/v1beta1/cosmos.feegrant.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.feegrant.v1beta1)
        }
    }
    pub mod genutil {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.genutil.module.v1)
            pub mod v1 {
                include!("cosmos/genutil/module/v1/cosmos.genutil.module.v1.rs");
                // @@protoc_insertion_point(cosmos.genutil.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.genutil.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/genutil/v1beta1/cosmos.genutil.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.genutil.v1beta1)
        }
    }
    pub mod gov {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.gov.module.v1)
            pub mod v1 {
                include!("cosmos/gov/module/v1/cosmos.gov.module.v1.rs");
                // @@protoc_insertion_point(cosmos.gov.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.gov.v1)
        pub mod v1 {
            include!("cosmos/gov/v1/cosmos.gov.v1.rs");
            // @@protoc_insertion_point(cosmos.gov.v1)
        }
        // @@protoc_insertion_point(attribute:cosmos.gov.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/gov/v1beta1/cosmos.gov.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.gov.v1beta1)
        }
    }
    pub mod group {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.group.module.v1)
            pub mod v1 {
                include!("cosmos/group/module/v1/cosmos.group.module.v1.rs");
                // @@protoc_insertion_point(cosmos.group.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.group.v1)
        pub mod v1 {
            include!("cosmos/group/v1/cosmos.group.v1.rs");
            // @@protoc_insertion_point(cosmos.group.v1)
        }
    }
    pub mod ics23 {
        // @@protoc_insertion_point(attribute:cosmos.ics23.v1)
        pub mod v1 {
            include!("cosmos/ics23/v1/cosmos.ics23.v1.rs");
            // @@protoc_insertion_point(cosmos.ics23.v1)
        }
    }
    pub mod mint {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.mint.module.v1)
            pub mod v1 {
                include!("cosmos/mint/module/v1/cosmos.mint.module.v1.rs");
                // @@protoc_insertion_point(cosmos.mint.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.mint.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/mint/v1beta1/cosmos.mint.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.mint.v1beta1)
        }
    }
    pub mod msg {
        pub mod textual {
            // @@protoc_insertion_point(attribute:cosmos.msg.textual.v1)
            pub mod v1 {
                include!("cosmos/msg/textual/v1/cosmos.msg.textual.v1.rs");
                // @@protoc_insertion_point(cosmos.msg.textual.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.msg.v1)
        pub mod v1 {
            include!("cosmos/msg/v1/cosmos.msg.v1.rs");
            // @@protoc_insertion_point(cosmos.msg.v1)
        }
    }
    pub mod nft {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.nft.module.v1)
            pub mod v1 {
                include!("cosmos/nft/module/v1/cosmos.nft.module.v1.rs");
                // @@protoc_insertion_point(cosmos.nft.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.nft.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/nft/v1beta1/cosmos.nft.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.nft.v1beta1)
        }
    }
    pub mod params {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.params.module.v1)
            pub mod v1 {
                include!("cosmos/params/module/v1/cosmos.params.module.v1.rs");
                // @@protoc_insertion_point(cosmos.params.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.params.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/params/v1beta1/cosmos.params.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.params.v1beta1)
        }
    }
    pub mod query {
        // @@protoc_insertion_point(attribute:cosmos.query.v1)
        pub mod v1 {
            include!("cosmos/query/v1/cosmos.query.v1.rs");
            // @@protoc_insertion_point(cosmos.query.v1)
        }
    }
    pub mod reflection {
        // @@protoc_insertion_point(attribute:cosmos.reflection.v1)
        pub mod v1 {
            include!("cosmos/reflection/v1/cosmos.reflection.v1.rs");
            // @@protoc_insertion_point(cosmos.reflection.v1)
        }
    }
    pub mod slashing {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.slashing.module.v1)
            pub mod v1 {
                include!("cosmos/slashing/module/v1/cosmos.slashing.module.v1.rs");
                // @@protoc_insertion_point(cosmos.slashing.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.slashing.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/slashing/v1beta1/cosmos.slashing.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.slashing.v1beta1)
        }
    }
    pub mod staking {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.staking.module.v1)
            pub mod v1 {
                include!("cosmos/staking/module/v1/cosmos.staking.module.v1.rs");
                // @@protoc_insertion_point(cosmos.staking.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.staking.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/staking/v1beta1/cosmos.staking.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.staking.v1beta1)
        }
    }
    pub mod store {
        pub mod internal {
            pub mod kv {
                // @@protoc_insertion_point(attribute:cosmos.store.internal.kv.v1beta1)
                pub mod v1beta1 {
                    include!("cosmos/store/internal/kv/v1beta1/cosmos.store.internal.kv.v1beta1.rs");
                    // @@protoc_insertion_point(cosmos.store.internal.kv.v1beta1)
                }
            }
        }
        pub mod snapshots {
            // @@protoc_insertion_point(attribute:cosmos.store.snapshots.v1)
            pub mod v1 {
                include!("cosmos/store/snapshots/v1/cosmos.store.snapshots.v1.rs");
                // @@protoc_insertion_point(cosmos.store.snapshots.v1)
            }
        }
        pub mod streaming {
            // @@protoc_insertion_point(attribute:cosmos.store.streaming.abci)
            pub mod abci {
                include!("cosmos/store/streaming/abci/cosmos.store.streaming.abci.rs");
                // @@protoc_insertion_point(cosmos.store.streaming.abci)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.store.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/store/v1beta1/cosmos.store.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.store.v1beta1)
        }
    }
    pub mod tx {
        pub mod config {
            // @@protoc_insertion_point(attribute:cosmos.tx.config.v1)
            pub mod v1 {
                include!("cosmos/tx/config/v1/cosmos.tx.config.v1.rs");
                // @@protoc_insertion_point(cosmos.tx.config.v1)
            }
        }
        pub mod signing {
            // @@protoc_insertion_point(attribute:cosmos.tx.signing.v1beta1)
            pub mod v1beta1 {
                include!("cosmos/tx/signing/v1beta1/cosmos.tx.signing.v1beta1.rs");
                // @@protoc_insertion_point(cosmos.tx.signing.v1beta1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.tx.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/tx/v1beta1/cosmos.tx.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.tx.v1beta1)
        }
    }
    pub mod upgrade {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.upgrade.module.v1)
            pub mod v1 {
                include!("cosmos/upgrade/module/v1/cosmos.upgrade.module.v1.rs");
                // @@protoc_insertion_point(cosmos.upgrade.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.upgrade.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/upgrade/v1beta1/cosmos.upgrade.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.upgrade.v1beta1)
        }
    }
    pub mod vesting {
        pub mod module {
            // @@protoc_insertion_point(attribute:cosmos.vesting.module.v1)
            pub mod v1 {
                include!("cosmos/vesting/module/v1/cosmos.vesting.module.v1.rs");
                // @@protoc_insertion_point(cosmos.vesting.module.v1)
            }
        }
        // @@protoc_insertion_point(attribute:cosmos.vesting.v1beta1)
        pub mod v1beta1 {
            include!("cosmos/vesting/v1beta1/cosmos.vesting.v1beta1.rs");
            // @@protoc_insertion_point(cosmos.vesting.v1beta1)
        }
    }
}
// @@protoc_insertion_point(attribute:cosmos_proto)
pub mod cosmos_proto {
    include!("cosmos_proto/cosmos_proto.rs");
    // @@protoc_insertion_point(cosmos_proto)
}
pub mod cosmwasm {
    pub mod wasm {
        // @@protoc_insertion_point(attribute:cosmwasm.wasm.v1)
        pub mod v1 {
            include!("cosmwasm/wasm/v1/cosmwasm.wasm.v1.rs");
            // @@protoc_insertion_point(cosmwasm.wasm.v1)
        }
    }
}
// @@protoc_insertion_point(attribute:gogoproto)
pub mod gogoproto {
    include!("gogoproto/gogoproto.rs");
    // @@protoc_insertion_point(gogoproto)
}
pub mod google {
    // @@protoc_insertion_point(attribute:google.api)
    pub mod api {
        include!("google/api/google.api.rs");
        // @@protoc_insertion_point(google.api)
    }
}
pub mod ibc {
    pub mod applications {
        pub mod fee {
            // @@protoc_insertion_point(attribute:ibc.applications.fee.v1)
            pub mod v1 {
                include!("ibc/applications/fee/v1/ibc.applications.fee.v1.rs");
                // @@protoc_insertion_point(ibc.applications.fee.v1)
            }
        }
        pub mod interchain_accounts {
            pub mod controller {
                // @@protoc_insertion_point(attribute:ibc.applications.interchain_accounts.controller.v1)
                pub mod v1 {
                    include!("ibc/applications/interchain_accounts/controller/v1/ibc.applications.interchain_accounts.controller.v1.rs");
                    // @@protoc_insertion_point(ibc.applications.interchain_accounts.controller.v1)
                }
            }
            pub mod genesis {
                // @@protoc_insertion_point(attribute:ibc.applications.interchain_accounts.genesis.v1)
                pub mod v1 {
                    include!("ibc/applications/interchain_accounts/genesis/v1/ibc.applications.interchain_accounts.genesis.v1.rs");
                    // @@protoc_insertion_point(ibc.applications.interchain_accounts.genesis.v1)
                }
            }
            pub mod host {
                // @@protoc_insertion_point(attribute:ibc.applications.interchain_accounts.host.v1)
                pub mod v1 {
                    include!("ibc/applications/interchain_accounts/host/v1/ibc.applications.interchain_accounts.host.v1.rs");
                    // @@protoc_insertion_point(ibc.applications.interchain_accounts.host.v1)
                }
            }
            // @@protoc_insertion_point(attribute:ibc.applications.interchain_accounts.v1)
            pub mod v1 {
                include!("ibc/applications/interchain_accounts/v1/ibc.applications.interchain_accounts.v1.rs");
                // @@protoc_insertion_point(ibc.applications.interchain_accounts.v1)
            }
        }
        pub mod transfer {
            // @@protoc_insertion_point(attribute:ibc.applications.transfer.v1)
            pub mod v1 {
                include!("ibc/applications/transfer/v1/ibc.applications.transfer.v1.rs");
                // @@protoc_insertion_point(ibc.applications.transfer.v1)
            }
            // @@protoc_insertion_point(attribute:ibc.applications.transfer.v2)
            pub mod v2 {
                include!("ibc/applications/transfer/v2/ibc.applications.transfer.v2.rs");
                // @@protoc_insertion_point(ibc.applications.transfer.v2)
            }
        }
    }
    pub mod core {
        pub mod channel {
            // @@protoc_insertion_point(attribute:ibc.core.channel.v1)
            pub mod v1 {
                include!("ibc/core/channel/v1/ibc.core.channel.v1.rs");
                // @@protoc_insertion_point(ibc.core.channel.v1)
            }
        }
        pub mod client {
            // @@protoc_insertion_point(attribute:ibc.core.client.v1)
            pub mod v1 {
                include!("ibc/core/client/v1/ibc.core.client.v1.rs");
                // @@protoc_insertion_point(ibc.core.client.v1)
            }
        }
        pub mod commitment {
            // @@protoc_insertion_point(attribute:ibc.core.commitment.v1)
            pub mod v1 {
                include!("ibc/core/commitment/v1/ibc.core.commitment.v1.rs");
                // @@protoc_insertion_point(ibc.core.commitment.v1)
            }
        }
        pub mod connection {
            // @@protoc_insertion_point(attribute:ibc.core.connection.v1)
            pub mod v1 {
                include!("ibc/core/connection/v1/ibc.core.connection.v1.rs");
                // @@protoc_insertion_point(ibc.core.connection.v1)
            }
        }
        pub mod types {
            // @@protoc_insertion_point(attribute:ibc.core.types.v1)
            pub mod v1 {
                include!("ibc/core/types/v1/ibc.core.types.v1.rs");
                // @@protoc_insertion_point(ibc.core.types.v1)
            }
        }
    }
    pub mod lightclients {
        pub mod localhost {
            // @@protoc_insertion_point(attribute:ibc.lightclients.localhost.v2)
            pub mod v2 {
                include!("ibc/lightclients/localhost/v2/ibc.lightclients.localhost.v2.rs");
                // @@protoc_insertion_point(ibc.lightclients.localhost.v2)
            }
        }
        pub mod solomachine {
            // @@protoc_insertion_point(attribute:ibc.lightclients.solomachine.v2)
            pub mod v2 {
                include!("ibc/lightclients/solomachine/v2/ibc.lightclients.solomachine.v2.rs");
                // @@protoc_insertion_point(ibc.lightclients.solomachine.v2)
            }
            // @@protoc_insertion_point(attribute:ibc.lightclients.solomachine.v3)
            pub mod v3 {
                include!("ibc/lightclients/solomachine/v3/ibc.lightclients.solomachine.v3.rs");
                // @@protoc_insertion_point(ibc.lightclients.solomachine.v3)
            }
        }
        pub mod tendermint {
            // @@protoc_insertion_point(attribute:ibc.lightclients.tendermint.v1)
            pub mod v1 {
                include!("ibc/lightclients/tendermint/v1/ibc.lightclients.tendermint.v1.rs");
                // @@protoc_insertion_point(ibc.lightclients.tendermint.v1)
            }
        }
        pub mod wasm {
            // @@protoc_insertion_point(attribute:ibc.lightclients.wasm.v1)
            pub mod v1 {
                include!("ibc/lightclients/wasm/v1/ibc.lightclients.wasm.v1.rs");
                // @@protoc_insertion_point(ibc.lightclients.wasm.v1)
            }
        }
    }
}
pub mod injective {
    pub mod auction {
        // @@protoc_insertion_point(attribute:injective.auction.v1beta1)
        pub mod v1beta1 {
            include!("injective/auction/v1beta1/injective.auction.v1beta1.rs");
            // @@protoc_insertion_point(injective.auction.v1beta1)
        }
    }
    pub mod common {
        pub mod vouchers {
            // @@protoc_insertion_point(attribute:injective.common.vouchers.v1)
            pub mod v1 {
                include!("injective/common/vouchers/v1/injective.common.vouchers.v1.rs");
                // @@protoc_insertion_point(injective.common.vouchers.v1)
            }
        }
    }
    pub mod crypto {
        pub mod v1beta1 {
            // @@protoc_insertion_point(attribute:injective.crypto.v1beta1.ethsecp256k1)
            pub mod ethsecp256k1 {
                include!("injective/crypto/v1beta1/ethsecp256k1/injective.crypto.v1beta1.ethsecp256k1.rs");
                // @@protoc_insertion_point(injective.crypto.v1beta1.ethsecp256k1)
            }
        }
    }
    pub mod downtimedetector {
        // @@protoc_insertion_point(attribute:injective.downtimedetector.v1beta1)
        pub mod v1beta1 {
            include!("injective/downtimedetector/v1beta1/injective.downtimedetector.v1beta1.rs");
            // @@protoc_insertion_point(injective.downtimedetector.v1beta1)
        }
    }
    pub mod erc20 {
        // @@protoc_insertion_point(attribute:injective.erc20.v1beta1)
        pub mod v1beta1 {
            include!("injective/erc20/v1beta1/injective.erc20.v1beta1.rs");
            // @@protoc_insertion_point(injective.erc20.v1beta1)
        }
    }
    pub mod evm {
        // @@protoc_insertion_point(attribute:injective.evm.v1)
        pub mod v1 {
            include!("injective/evm/v1/injective.evm.v1.rs");
            // @@protoc_insertion_point(injective.evm.v1)
        }
    }
    pub mod exchange {
        // @@protoc_insertion_point(attribute:injective.exchange.v1beta1)
        pub mod v1beta1 {
            include!("injective/exchange/v1beta1/injective.exchange.v1beta1.rs");
            // @@protoc_insertion_point(injective.exchange.v1beta1)
        }
        // @@protoc_insertion_point(attribute:injective.exchange.v2)
        pub mod v2 {
            include!("injective/exchange/v2/injective.exchange.v2.rs");
            // @@protoc_insertion_point(injective.exchange.v2)
        }
    }
    pub mod insurance {
        // @@protoc_insertion_point(attribute:injective.insurance.v1beta1)
        pub mod v1beta1 {
            include!("injective/insurance/v1beta1/injective.insurance.v1beta1.rs");
            // @@protoc_insertion_point(injective.insurance.v1beta1)
        }
    }
    pub mod oracle {
        // @@protoc_insertion_point(attribute:injective.oracle.v1beta1)
        pub mod v1beta1 {
            include!("injective/oracle/v1beta1/injective.oracle.v1beta1.rs");
            // @@protoc_insertion_point(injective.oracle.v1beta1)
        }
    }
    pub mod peggy {
        // @@protoc_insertion_point(attribute:injective.peggy.v1)
        pub mod v1 {
            include!("injective/peggy/v1/injective.peggy.v1.rs");
            // @@protoc_insertion_point(injective.peggy.v1)
        }
    }
    pub mod permissions {
        // @@protoc_insertion_point(attribute:injective.permissions.v1beta1)
        pub mod v1beta1 {
            include!("injective/permissions/v1beta1/injective.permissions.v1beta1.rs");
            // @@protoc_insertion_point(injective.permissions.v1beta1)
        }
    }
    pub mod stream {
        // @@protoc_insertion_point(attribute:injective.stream.v1beta1)
        pub mod v1beta1 {
            include!("injective/stream/v1beta1/injective.stream.v1beta1.rs");
            // @@protoc_insertion_point(injective.stream.v1beta1)
        }
        // @@protoc_insertion_point(attribute:injective.stream.v2)
        pub mod v2 {
            include!("injective/stream/v2/injective.stream.v2.rs");
            // @@protoc_insertion_point(injective.stream.v2)
        }
    }
    pub mod tokenfactory {
        // @@protoc_insertion_point(attribute:injective.tokenfactory.v1beta1)
        pub mod v1beta1 {
            include!("injective/tokenfactory/v1beta1/injective.tokenfactory.v1beta1.rs");
            // @@protoc_insertion_point(injective.tokenfactory.v1beta1)
        }
    }
    pub mod txfees {
        // @@protoc_insertion_point(attribute:injective.txfees.v1beta1)
        pub mod v1beta1 {
            include!("injective/txfees/v1beta1/injective.txfees.v1beta1.rs");
            // @@protoc_insertion_point(injective.txfees.v1beta1)
        }
    }
    pub mod types {
        // @@protoc_insertion_point(attribute:injective.types.v1beta1)
        pub mod v1beta1 {
            include!("injective/types/v1beta1/injective.types.v1beta1.rs");
            // @@protoc_insertion_point(injective.types.v1beta1)
        }
    }
    pub mod wasmx {
        // @@protoc_insertion_point(attribute:injective.wasmx.v1)
        pub mod v1 {
            include!("injective/wasmx/v1/injective.wasmx.v1.rs");
            // @@protoc_insertion_point(injective.wasmx.v1)
        }
    }
}
